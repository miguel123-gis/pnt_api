--
-- PostgreSQL database dump
--

-- Dumped from database version 14.13 (Postgres.app)
-- Dumped by pg_dump version 16.4 (Postgres.app)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: binhi_priority_species_cleaned; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.binhi_priority_species_cleaned (
    common_name character varying,
    scientific_name character varying,
    id integer
);


ALTER TABLE staging.binhi_priority_species_cleaned OWNER TO postgres;

--
-- Data for Name: binhi_priority_species_cleaned; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.binhi_priority_species_cleaned (common_name, scientific_name, id) FROM stdin;
Almaciga	Agathis philippinensis	1
Almon	Shorea almon	2
Alupag	Litchi chinensis ssp. philippinensis	3
Amugis	Koordersiodendron pinnatum	4
Anang	Diospyros pyrrhocarpa	5
Antipolo	Artocarpus blancoi	6
Apitong	Dipterocarpus grandiflorus	7
Apunan	Diospyros cauliflora	8
Ata-ata	Diospyros mindanaensis	9
Bagauak-morado	Clerodendrum quadriloculare	10
Bagoadlau 	Xanthostemon philippinensis	11
Bagtikan	Parashorea malaanonan	12
Baguilumbang	Reutealis trisperma	13
Balakat-gubat	Balakata luzonica (Sapium luzonicum)	14
Banuyo	Wallaceodendron celebicum	15
Basilan-yakal	Hopea basilanica	17
Batete	Kingiodendron alternifolium	18
Batikuling	Litsea leytensis	19
Betis	Madhuca betis	20
Bolong-eta	Diospyros pilosanthera var. pilosanthera	21
Broad-winged apitong	Dipterocarpus kunstleri	22
Dalingdingan	Hopea foxworthyi	23
Dao	Dracontomelon dao	24
Duguan	Myristica philippensis 	25
Ebony	Diospyros ferrea	26
Gisok-gisok	Hopea philippinensis	27
Guijo	Shorea guiso	28
Hagakhak	Dipterocarpus validus	29
Hairy-leaf Apitong	Dipterocarpus alatus	30
Igem-dagat	Podocarpus costalis	32
Ipil	Intsia bijuga	33
Itom-itom	Diospyros longiciliata	34
Kaladis Narig	Vatica elliptica	35
Kalantas	Toona calantas	36
Kalingag	Cinnamomum mercadoi	37
Kalunti	Shorea hopeifolia	38
Kamagong	Diospyros blancoi	39
Kamagong ponce	Diospyros poncei forma poncei	40
Kamatog	Sympetalandra densiflora	41
Kanining-peneras	Aglaia pyriformis	42
Katmon	Dillenia philippinensis	43
Katmon bayani	Dillenia megalantha	44
Lamio	Dracontomelon edule	45
Magabuyo	Celtis luzonica	46
Makaasim	Syzygium nitidum	47
Malabayabas	Tristaniopsis decorticata	48
Malagaitmon	Diospyros curranii	49
Malak-malak	Palaquium philippense	50
Malakatmon	Dillenia luzonienses	51
Malapanau	Dipterocarpus kerrii	52
Malasaging	Aglaia edulis	53
Malayakal	Shorea seminis	54
Malinoag	Diospyros brideliifolia	55
Manggachapui	Hopea acuminata	56
Manggis	Koompassia excelsa	57
Mangkono	Xanthostemon verdugonianus	58
Mapilig 	Xanthostemon bracteatus	59
Mayapis	Shorea palosapis	60
Mindanao Narek	Hopea brachyptera	61
Mindanao Narig	Vatica mindanensis	62
Mindanao Palosapis	Anisoptera costata	63
Molave	Vitex parviflora	64
Narek	Hopea cagayanensis	65
Narig	Vatica mangachapoi ssp. mangachapoi	66
Narig-laot	Vatica maritima	67
Narra	Pterocarpus indicus	68
Nato/Red Nato	Palaquium luzoniense	69
O-oi	Diospyros philippinensis	70
Pahutan	Mangifera altissima	71
Palawan Mangkono	Xanthostemon speciosus	72
Palawan Narig	Vatica mangachapoi Blanco ssp. obtusifolia	73
Philippine Teak	Tectona philippinensis	74
Pianga	Ganua obovatifolia	75
Pili	Canarium ovatum	76
Piling-liitan	Canarium luzonicum	77
Pinulog	Palaquium mindanaense	78
Quisumbing-gisok	Hopea quisumbingiana	79
Red Lauan	Shorea negrosensis	80
Samar-gisok	Hopea samarensis	81
Sierra Madre Mangkono	Xanthostemon fruticosus	82
Supa	Sindora supa	83
Taba	Tristaniopsis littoralis	84
Tangile	Shorea polysperma	85
Thick-leaf Narig	Vatica pachyphylla	86
Tiaong	Shorea ovata	87
Tindalo	Afzelia rhomboidea	88
White Lauan	Shorea contorta	90
Yakal	Shorea astylosa	91
Yakal-kaliot	Hopea malibato	92
Yakal-magasusu	Hopea mindanensis	93
Yakal-malibato	Shorea malibato	94
Yakal-saplungan	Hopea plagata	95
Yakal-yamban	Shorea falciferoides ssp. falciferoides	96
Basilan Apitong	Dipterocarpus eurhynchus	16
Hasselt's Panau	Dipterocarpus hasseltii	31
Villamil Nato	Pouteria villamilii	89
\.


--
-- PostgreSQL database dump complete
--

