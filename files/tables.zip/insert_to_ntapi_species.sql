--
-- PostgreSQL database dump
--

-- Dumped from database version 14.13 (Postgres.app)
-- Dumped by pg_dump version 16.4 (Postgres.app)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: insert_to_ntapi_species; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.insert_to_ntapi_species (
    common_name text,
    species text,
    family character varying,
    binhi_priority text,
    conservation_status character varying,
    ecological_classification character varying,
    id integer NOT NULL
);


ALTER TABLE staging.insert_to_ntapi_species OWNER TO postgres;

--
-- Name: insert_to_ntapi_species_id_seq; Type: SEQUENCE; Schema: staging; Owner: postgres
--

CREATE SEQUENCE staging.insert_to_ntapi_species_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE staging.insert_to_ntapi_species_id_seq OWNER TO postgres;

--
-- Name: insert_to_ntapi_species_id_seq; Type: SEQUENCE OWNED BY; Schema: staging; Owner: postgres
--

ALTER SEQUENCE staging.insert_to_ntapi_species_id_seq OWNED BY staging.insert_to_ntapi_species.id;


--
-- Name: insert_to_ntapi_species id; Type: DEFAULT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.insert_to_ntapi_species ALTER COLUMN id SET DEFAULT nextval('staging.insert_to_ntapi_species_id_seq'::regclass);


--
-- Data for Name: insert_to_ntapi_species; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.insert_to_ntapi_species (common_name, species, family, binhi_priority, conservation_status, ecological_classification, id) FROM stdin;
Malapasnit	Kibatalia longifolia Merr.	Apocynaceae	\N	Critically Endangered	Endemic	1
\N	Amorphophallus palawanensis Bogner & Hett.	Araceae	\N	Critically Endangered	Endemic	2
\N	Amorphophallus natolii Hett., A.Wistuba, V.B.Amoroso, M.Medecilo & C.Claudel	Araceae	\N	Critically Endangered	Endemic	3
Takobtob	Areca parens Becc.	Arecaceae	\N	Critically Endangered	Endemic	4
Valit	Calamus batanensis (Becc.) Baja-Lapis	Arecaceae	\N	Critically Endangered	Endemic	5
\N	Calamus jenningsianus Becc.	Arecaceae	\N	Critically Endangered	Endemic	6
\N	Calamus vinosus Becc.	Arecaceae	\N	Critically Endangered	Endemic	7
Bagbag	Calamus affinis Becc.	Arecaceae	\N	Critically Endangered	Endemic	8
Rogman	Calamus oligolepis Becc.	Arecaceae	\N	Critically Endangered	Endemic	9
Sabilog	Calamus pannosus Becc.	Arecaceae	\N	Critically Endangered	Endemic	10
Yanisi	Heterospathe califrons Fernando	Arecaceae	\N	Critically Endangered	Endemic	11
Dransfield Sanakti	Heterospathe dransfieldii Fernando	Arecaceae	\N	Critically Endangered	Endemic	12
Malasanakti	Heterospathe scitula Fernando	Arecaceae	\N	Critically Endangered	Endemic	13
Bilis	Heterospathe sibuyanensis Becc.	Arecaceae	\N	Critically Endangered	Endemic	14
Tatlong Bilisan	Heterospathe trispatha Fernando	Arecaceae	\N	Critically Endangered	Endemic	15
Palawan Banga	Orania paraguanensis Becc., Webbia	Arecaceae	\N	Critically Endangered	Indigenous	16
Dapiau	Pinanga batanensis Becc.	Arecaceae	\N	Critically Endangered	Endemic	17
Bicol Abiki	Pinanga bicolana Fernando	Arecaceae	\N	Critically Endangered	Endemic	18
Samar Abiki	Pinanga samarana Becc.	Arecaceae	\N	Critically Endangered	Endemic	19
Abiking-Tigas	Pinanga sclerophylla Becc.	Arecaceae	\N	Critically Endangered	Endemic	20
Tibangan	Pinanga sibuyanensis Becc.	Arecaceae	\N	Critically Endangered	Endemic	21
Ungang	Plectocomia elmeri Becc.	Arecaceae	\N	Critically Endangered	Endemic	22
\N	Buxbaumia javanica Muell. Hal.	Buxbaumiaceae	\N	Critically Endangered	Indigenous	23
Paróngpong	Ceuthostoma palawanense L.A.S.Johnson	Casuarinaceae	\N	Critically Endangered	Endemic	24
\N	Ceuthostoma terminale L.A.S.Johnson	Casuarinaceae	\N	Critically Endangered	Indigenous	25
\N	Cyathea curranii Copel.	Cyatheaceae	\N	Critically Endangered	Endemic	26
\N	Cyathea latipinnula Copel.	Cyatheaceae	\N	Critically Endangered	Endemic	27
\N	Cyathea microchlamys Holttum	Cyatheaceae	\N	Critically Endangered	Endemic	28
\N	Cyathea obliqua Copel.	Cyatheaceae	\N	Critically Endangered	Endemic	29
\N	Cyathea sibuyanensis Copel.	Cyatheaceae	\N	Critically Endangered	Endemic	30
\N	Cycas aenigma K.D.Hill & A.Lindstr	Cycadaceae	\N	Critically Endangered	Endemic	31
Curran Pitogo	Cycas curranii (J Schust.) KD Hill	Cycadaceae	\N	Critically Endangered	Endemic	32
\N	Cycas sancti-lasallei Agoo & Madulid	Cycadaceae	\N	Critically Endangered	Endemic	33
\N	Cycas saxatilis KD. Hill & Lindstr.	Cycadaceae	\N	Critically Endangered	Endemic	34
\N	Cycas zambalensis Madulid & Agoo	Cycadaceae	\N	Critically Endangered	Endemic	35
\N	Dipteris lobbiana (Hook.) Moore, Ind. Fil.	Dipteridaceae	\N	Critically Endangered	Indigenous	36
\N	Ctenitis paleolata Copel.	Dryopteridaceae	\N	Critically Endangered	Endemic	50
\N	Dryopteris zhuweimingii Li Bing Zhang	Dryopteridaceae	\N	Critically Endangered	Indigenous	51
\N	Rhododendron acrophilum Merr. & Quisumb.	Ericaceae	\N	Critically Endangered	Endemic	55
\N	Rhododendron mendumiae Argent	Ericaceae	\N	Critically Endangered	Endemic	56
\N	Rhododendron reynosoi Argent	Ericaceae	\N	Critically Endangered	Endemic	57
Yew-Leaf Rhododendron	Rhododendron taxifolium Merr.	Ericaceae	\N	Critically Endangered	Endemic	58
\N	Cynometra cebuensis Seidenschwarz	Fabaceae	\N	Critically Endangered	Endemic	59
\N	Macgregorella indica (Broth) W.R. Buck	Fabroniaceae	\N	Critically Endangered	Indigenous	60
\N	Merrilliobryum fabronioides Broth.	Fabroniaceae	\N	Critically Endangered	Endemic	61
\N	Hypericum pulogense Merr.	Hypericaceae	\N	Critically Endangered	Endemic	62
\N	Isoetes philippinensis Merr. & Perry	Isoetaceae	\N	Critically Endangered	Endemic	63
Mendoza Kalíngag	Cinnamomum mendozae Kosterm	Lauraceae	\N	Critically Endangered	Endemic	64
Oro Kalingag	Cinnamomum oroi Quisumb.	Lauraceae	\N	Critically Endangered	Endemic	65
Amutmagiso	Tricyrtis imeldae Gut.	Liliaceae	\N	Critically Endangered	Endemic	66
\N	Thaumasianthes amplifolia (Merr.) Danser	Loranthaceae	\N	Critically Endangered	Endemic	67
Salindugok	Phlegmariurus whitfordii (Herter)	Lycopodiaceae	\N	Critically Endangered	Endemic	68
\N	Phanerosorus major Diels	Matoniaceae	\N	Critically Endangered	Indigenous	69
\N	Medinilla dallciana Fernando & Balete	Melastomataceae	\N	Critically Endangered	Endemic	70
Kapa-Kapa	Medinilla magnifica Lindl.	Melastomataceae	\N	Critically Endangered	Endemic	71
Ridsdale Tambalau	Knema ridsdaleana de Wilde	Myristicaceae	\N	Critically Endangered	Endemic	73
Ridsdale Duguan	Myristica colinridsdalei de Wilde	Myristicaceae	\N	Critically Endangered	Endemic	74
\N	Nepenthes abalata Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	76
\N	Nepenthes abgracilis Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	77
\N	Nepenthes alzapan Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	78
\N	Nepenthes argentii M Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	79
\N	Porotrichodendron mahahaicum (Muell.Hal.) M.Fleisch.	Lembophyllaceae	\N	Critically Endangered	Endemic	81
\N	Nepenthes armin Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	82
\N	Nepenthes attenboroughii A.S. Robinson, McPherson & Heinrich	Nepenthaceae	\N	Critically Endangered	Endemic	83
\N	Nepenthes barcelonae Tandang & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	84
\N	Nepenthes cid Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	85
\N	Nepenthes deaniana Macfarl	Nepenthaceae	\N	Critically Endangered	Endemic	86
\N	Nepenthes extincta Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	87
\N	Nepenthes kitanglad Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	88
\N	Nepenthes kurata Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	89
\N	Nepenthes leonardoi S.McPherson et al	Nepenthaceae	\N	Critically Endangered	Endemic	90
\N	Nepenthes leyte Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	91
\N	Nepenthes merrilliana Macfarl.	Nepenthaceae	\N	Critically Endangered	Endemic	92
\N	Nepenthes micramphora Heinrich, et.al.	Nepenthaceae	\N	Critically Endangered	Endemic	93
\N	Nepenthes mira Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	94
\N	Nepenthes negros Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	95
\N	Nepenthes palawanensis S.McPherson et al.	Nepenthaceae	\N	Critically Endangered	Endemic	96
\N	Nepenthes peltata Sh. Kurata	Nepenthaceae	\N	Critically Endangered	Endemic	97
\N	Nepenthes pulchra Gronem. et al	Nepenthaceae	\N	Critically Endangered	Endemic	98
\N	Nepenthes ramos Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	99
\N	Nepenthes robcantleyi Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	100
\N	Nepenthes samar Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	101
\N	Nepenthes sibuyanensis J Nerz	Nepenthaceae	\N	Critically Endangered	Endemic	102
\N	Nepenthes tboli Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	103
\N	Nepenthes zygon Jebb & Cheek	Nepenthaceae	\N	Critically Endangered	Endemic	104
Kayantol	Chionanthus clementis (Quisumb. & Merr.) Kiew	Oleaceae	\N	Critically Endangered	Endemic	105
Pamoplasin	Chionanthus remotinervius (Merr.) Kiew	Oleaceae	\N	Critically Endangered	Endemic	106
Palawan Olive	Olea palawanensis Kiew	Oleaceae	\N	Critically Endangered	Endemic	107
Tungkod-Langit	Helminthostachys zeylanica (L.) Hook	Ophioglossaceae	\N	Critically Endangered	Indigenous	108
\N	Amesiella monticola J Cootes & DP Banks	Orchidaceae	\N	Critically Endangered	Endemic	109
\N	Bulbophyllum cootesii M.A.Clem	Orchidaceae	\N	Critically Endangered	Endemic	110
\N	Ceratocentron fesselii Senghas	Orchidaceae	\N	Critically Endangered	Endemic	111
\N	Dendrobium schuetzei Rolfe	Orchidaceae	\N	Critically Endangered	Endemic	112
\N	Gastrochilus calceolaris (Buch.-Ham. ex Sm.) D.Don	Orchidaceae	\N	Critically Endangered	Indigenous	113
\N	Grammatophyllum speciosum Blume	Orchidaceae	\N	Critically Endangered	Indigenous	114
\N	Grammatophyllum ravanii D.Tiu	Orchidaceae	\N	Critically Endangered	Endemic	115
\N	Grammatophyllum walisii Rchb.f	Orchidaceae	\N	Critically Endangered	Endemic	116
\N	Mycaranthes leonardoi Ferreras & Suarez	Orchidaceae	\N	Critically Endangered	Endemic	117
\N	Paphiopedilum acmodontum MW Wood	Orchidaceae	\N	Critically Endangered	Endemic	118
\N	Paphiopedilum adductum Asher	Orchidaceae	\N	Critically Endangered	Endemic	119
\N	Paphiopedilum argus (Reichb.f.) Stein	Orchidaceae	\N	Critically Endangered	Endemic	120
\N	Paphiopedilum ciliolare (Reichb.f.) Stein	Orchidaceae	\N	Critically Endangered	Endemic	121
\N	Paphiopedilum fowliei Birk	Orchidaceae	\N	Critically Endangered	Endemic	122
\N	Paphiopedilum haynaldianum (Reichb.f.) Stein	Orchidaceae	\N	Critically Endangered	Endemic	123
\N	Paphiopedilum hennisianum (MW Wood) Fowlie	Orchidaceae	\N	Critically Endangered	Endemic	124
\N	Paphiopedilum randsii Fowlie	Orchidaceae	\N	Critically Endangered	Endemic	125
\N	Paphiopedilum urbanianum Fowlie	Orchidaceae	\N	Critically Endangered	Endemic	126
\N	Paphiopedilum usitanum O.Gruss & Roeth	Orchidaceae	\N	Critically Endangered	Endemic	127
\N	Paphiopedilum barbatum (Lindl.) Pfitzer	Orchidaceae	\N	Critically Endangered	Indigenous	128
\N	Paphiopedilum lowii (Lindl.) Stein,	Orchidaceae	\N	Critically Endangered	Indigenous	129
\N	Phalaenopsis micholitzii Rolfe	Orchidaceae	\N	Critically Endangered	Endemic	130
\N	Phragmorchis teretifolia LO Williams	Orchidaceae	\N	Critically Endangered	Endemic	131
\N	Renanthera caloptera (Rchb.f.) Kocyan & Schuit.	Orchidaceae	\N	Critically Endangered	Indigenous	132
\N	Vanda lamellata Lindl.	Orchidaceae	\N	Critically Endangered	Endemic	133
Waling-Waling	Vanda sanderiana (Reichb.f) Schltr.	Orchidaceae	\N	Critically Endangered	Endemic	134
Palawan Malakauayan	Podocarpus palawanensis de Laub. & Silba	Podocarpaceae	\N	Critically Endangered	Endemic	135
\N	Goniophlebium terrestre Copel.	Polypodiaceae	\N	Critically Endangered	Endemic	136
Staghorn Fern	Platycerium coronarium (König ex Müller) Desv.	Polypodiaceae	\N	Critically Endangered	Indigenous	137
Giant Staghorn Fern	Platycerium grande (Fee) Kunze	Polypodiaceae	\N	Critically Endangered	Endemic	138
\N	Podosorus angustatus Holttum	Polypodiaceae	\N	Critically Endangered	Endemic	139
\N	Pteris calocarpa (Copel.) MG Price	Pteridaceae	\N	Critically Endangered	Endemic	140
\N	Pteris pachysora (Copel.) MG Price	Pteridaceae	\N	Critically Endangered	Endemic	141
\N	Euptychium setigerum (Sull.) Broth.	Pterobryaceae	\N	Critically Endangered	Indigenous	142
\N	Rafflesia aurantia Barcelona, Co & Balete	Rafflesiaceae	\N	Critically Endangered	Endemic	143
Boo	Rafflesia schadenbergiana Goeppert ex Hieron.	Rafflesiaceae	\N	Critically Endangered	Endemic	144
\N	Rafflesia verrucosa Balete et al.	Rafflesiaceae	\N	Critically Endangered	Endemic	145
Baler Bakauan	Kandelia candel Druce	Rhizophoraceae	\N	Critically Endangered	Indigenous	146
\N	Antherostele callophylla Bremek.	Rubiaceae	\N	Critically Endangered	Endemic	147
\N	Antherostele luzoniensis (Merr.) Bremek.	Rubiaceae	\N	Critically Endangered	Endemic	148
\N	Antherostele samarensis Obico & Alejandro	Rubiaceae	\N	Critically Endangered	Endemic	149
Kalinigi	Atractocarpus obscurinervius (Merr.)	Rubiaceae	\N	Critically Endangered	Endemic	150
Palawan Palak	Badusa palawanensis Ridsd.	Rubiaceae	\N	Critically Endangered	Endemic	151
\N	Bikkia montoyae Mejillano et al.	Rubiaceae	\N	Critically Endangered	Endemic	152
\N	Bikkia philippinensis Valeton	Rubiaceae	\N	Critically Endangered	Endemic	153
Pangalimanan	Greeniopsis discolor Merr.	Rubiaceae	\N	Critically Endangered	Endemic	154
Buhon-Buhon	Greeniopsis euphlebia Merr.	Rubiaceae	\N	Critically Endangered	Endemic	155
Humagos	Greeniopsis megalantha Merr.	Rubiaceae	\N	Critically Endangered	Endemic	156
Paluay-Mabolo	Greeniopsis pubescens Merr.	Rubiaceae	\N	Critically Endangered	Endemic	157
\N	Psydrax puberula Arriola & Alejandro	Rubiaceae	\N	Critically Endangered	Endemic	158
Tango	Villaria acutifolia (Elmer) Merr.	Rubiaceae	\N	Critically Endangered	Endemic	159
Otto	Villaria fasciculiflora Quisumb. & Merr.	Rubiaceae	\N	Critically Endangered	Endemic	160
\N	Villaria leytensis Alejandro & Meve	Rubiaceae	\N	Critically Endangered	Endemic	161
\N	Villaria uniflora Arriola & Alejandro	Rubiaceae	\N	Critically Endangered	Endemic	162
Kabuyok	Swinglea glutinosa (Blanco) Merr.	Rutaceae	\N	Critically Endangered	Endemic	163
\N	Medinilla calcicola Merr.	Melastomataceae	\N	Endangered	Endemic	164
Kasau-Kasau	Gongrospermum philippinense Radlk.	Sapindaceae	\N	Critically Endangered	Endemic	165
Palawan Alahan	Guioa palawanica Welzen	Sapindaceae	\N	Critically Endangered	Endemic	166
Angset	Guioa parvifoliola Merr.	Sapindaceae	\N	Critically Endangered	Endemic	167
Alahan-Sinima	Guioa reticulata Radlk.	Sapindaceae	\N	Critically Endangered	Endemic	168
\N	Gomphandra bracteata Schori	Stemonuraceae	\N	Critically Endangered	Endemic	169
Conklin Mabunót	Gomphandra conklinii Schori	Stemonuraceae	\N	Critically Endangered	Endemic	170
Dinagat Mabunót	Gomphandra dinagatensis Schori	Stemonuraceae	\N	Critically Endangered	Endemic	171
Halcon Mabunót	Gomphandra halconensis Schori	Stemonuraceae	\N	Critically Endangered	Endemic	172
\N	Heterogonium wenzelii (Copel.) Holttum	Tectariaceae	\N	Critically Endangered	Endemic	173
\N	Chingia urens Holttum	Thelypteridaceae	\N	Critically Endangered	Endemic	174
\N	Coryphopteris borealis Holttum	Thelypteridaceae	\N	Critically Endangered	Endemic	175
Pahong-Liitan	Mangifera merrillii Mukherji	Anacardiaceae	\N	Endangered	Endemic	176
Huani	Mangifera odorata Griff., Notul.	Anacardiaceae	\N	Endangered	Indigenous	177
\N	Hoya alagensis Kloppenb.	Apocynaceae	\N	Endangered	Endemic	178
\N	Hoya angustisepala CM Burton	Apocynaceae	\N	Endangered	Endemic	179
\N	Hoya burtoniae Kloppenb.	Apocynaceae	\N	Endangered	Endemic	180
\N	Hoya crassicaulis (Elmer) Kloppenb.	Apocynaceae	\N	Endangered	Endemic	181
\N	Hoya curtisii King &Gamble	Apocynaceae	\N	Endangered	Indigenous	182
\N	Hoya diversifolia Blume Kloppenb.	Apocynaceae	\N	Endangered	Endemic	183
\N	Hoya estrellaensis T.Green & Kloppenb	Apocynaceae	\N	Endangered	Endemic	184
\N	Hoya gigantanganensis Kloppenb.	Apocynaceae	\N	Endangered	Endemic	185
\N	Hoya greenii Kloppenb.	Apocynaceae	\N	Endangered	Endemic	186
\N	Hoya halconensis Kloppenb.	Apocynaceae	\N	Endangered	Endemic	187
\N	Hoya heuschkeliana Kloppenb.	Apocynaceae	\N	Endangered	Endemic	188
\N	Hoya imperialis Lindl.	Apocynaceae	\N	Endangered	Indigenous	189
\N	Hoya panchoi Kloppenb.	Apocynaceae	\N	Endangered	Endemic	190
\N	Hoya pulgarensis Elmer	Apocynaceae	\N	Endangered	Endemic	191
\N	Hoya quinquenervia Warb.	Apocynaceae	\N	Endangered	Endemic	192
\N	Hoya quisumbingii Kloppenb.	Apocynaceae	\N	Endangered	Endemic	193
\N	Hoya rizaliana Kloppenb.	Apocynaceae	\N	Endangered	Endemic	194
\N	Hoya wayetii Kloppenb.	Apocynaceae	\N	Endangered	Endemic	195
Paslit-Mabolo	Kibatalia puberula Merr.	Apocynaceae	\N	Endangered	Endemic	196
Paslit-Kitid	Kibatalia stenopetala Merr.	Apocynaceae	\N	Endangered	Endemic	197
\N	Marsdenia purpurella Fernando & Rodda	Apocynaceae	\N	Endangered	Endemic	198
Sander'S Alocasia	Alocasia sanderiana W Bull.	Araceae	\N	Endangered	Endemic	199
Agama Galamay-Amo	Schefflera agamae Merr.	Araliaceae	\N	Endangered	Endemic	200
Makinging	Schefflera albido-bracteata Elmer	Araliaceae	\N	Endangered	Endemic	201
Curran Galamay-Amo	Schefflera curranii Merr.	Araliaceae	\N	Endangered	Endemic	202
Foxworthy Galamay-Amo	Schefflera foxworthyi Merr.	Araliaceae	\N	Endangered	Endemic	203
Palawan Galamay-Amo	Schefflera palawanensis Merr.	Araliaceae	\N	Endangered	Endemic	204
Mono	Areca camarinensis Becc.	Arecaceae	\N	Endangered	Endemic	205
Malatandulang-Parang	Calamus balerensis Fernando	Arecaceae	\N	Endangered	Endemic	206
\N	Calamus flexilis W.J.Baker	Arecaceae	\N	Endangered	Endemic	207
\N	Calamus foxworthyi Becc.	Arecaceae	\N	Endangered	Endemic	208
Sika	Calamus caesius Blume	Arecaceae	\N	Endangered	Indigenous	209
Marighoi-Baba	Heterospathe brevicaulis Fernando	Arecaceae	\N	Endangered	Endemic	210
Anibong	Oncosperma platyphyllum Becc.	Arecaceae	\N	Endangered	Endemic	211
\N	Pinanga sobolifera Fernando, Kew Bull.	Arecaceae	\N	Endangered	Endemic	212
Abiking-Puti	Pinanga glaucifolia Fernando	Arecaceae	\N	Endangered	Endemic	213
Lakaúbi	Salacca clemensiana Becc.	Arecaceae	\N	Endangered	Endemic	214
Parutungun	Salacca ramosiana Mogea	Arecaceae	\N	Endangered	Indigenous	215
\N	Diplazium costulisorum (Copel.) C.Chr.	Athyriaceae	\N	Endangered	Endemic	216
\N	Diplazium egenolfioides M.G.Price	Athyriaceae	\N	Endangered	Endemic	217
\N	Diplazium propinquum (Copel.) Alderw.	Athyriaceae	\N	Endangered	Endemic	218
\N	Begonia acclivis C.Coyle	Begoniaceae	\N	Endangered	Endemic	219
\N	Begonia aequata A.Gray	Begoniaceae	\N	Endangered	Endemic	220
\N	Begonia androturba C.Coyle	Begoniaceae	\N	Endangered	Endemic	221
\N	Begonia apayaoensis Merr.	Begoniaceae	\N	Endangered	Endemic	222
\N	Begonia brevipes Merr.	Begoniaceae	\N	Endangered	Endemic	223
\N	Begonia casiguranensis Merr.	Begoniaceae	\N	Endangered	Endemic	224
\N	Begonia gracilipes Merr.	Begoniaceae	\N	Endangered	Endemic	225
\N	Begonia macgregorii Merr.	Begoniaceae	\N	Endangered	Endemic	226
\N	Begonia megalantha Merr.	Begoniaceae	\N	Endangered	Endemic	227
\N	Begonia palawanensis Merr.	Begoniaceae	\N	Endangered	Endemic	228
\N	Begonia platyphlla Merr.	Begoniaceae	\N	Endangered	Endemic	229
\N	Begonia ramosii Merr.	Begoniaceae	\N	Endangered	Endemic	230
\N	Begonia rubiteae M.Hughes	Begoniaceae	\N	Endangered	Endemic	231
Cycad Fern	Brainea insignis (Hook.) J.Sm	Blechnaceae	\N	Endangered	Indigenous	232
\N	Centrolepis philippinensis Merr.	Centrolepidaceae	\N	Endangered	Indigenous	233
Golden Fern	Cibotium barometz (L.) J.Sm., London J. Bot.	Cibotiaceae	\N	Endangered	Indigenous	234
Golden Fern	Cibotium cumingii Kunze, Farrnkräuter	Cibotiaceae	\N	Endangered	Indigenous	235
Malaputat	Terminalia darlingii Merr.	Combretaceae	\N	Endangered	Endemic	236
\N	Cyathea acuminata Copel.	Cyatheaceae	\N	Endangered	Endemic	237
\N	Cyathea apoensis Copel.	Cyatheaceae	\N	Endangered	Endemic	238
\N	Cyathea atropurpurea Copel.	Cyatheaceae	\N	Endangered	Endemic	239
\N	Cyathea binuangensis Alderw.	Cyatheaceae	\N	Endangered	Endemic	240
\N	Cyathea christii Copel.	Cyatheaceae	\N	Endangered	Endemic	241
\N	Cyathea contaminans (Wall. ex Hook.) Copel.	Cyatheaceae	\N	Endangered	Indigenous	242
\N	Cyathea edanoi Copel.	Cyatheaceae	\N	Endangered	Endemic	243
\N	Cyathea ferruginea Christ	Cyatheaceae	\N	Endangered	Endemic	244
\N	Cyathea lepifera (J.Sm. ex Hook.) Copel.	Cyatheaceae	\N	Endangered	Indigenous	245
\N	Cyathea masapilidensis Copel.	Cyatheaceae	\N	Endangered	Endemic	246
\N	Cyathea rufopannosa Christ	Cyatheaceae	\N	Endangered	Endemic	247
\N	Cyathea zamboangana Copel.	Cyatheaceae	\N	Endangered	Endemic	248
\N	Cycas lacrimans KD. Hill & Lindst.	Cycadaceae	\N	Endangered	Endemic	249
\N	Cycas nitida KD. Hill & Lindstr.	Cycadaceae	\N	Endangered	Endemic	250
Culion Pitogo	Cycas wadei Merr.	Cycadaceae	\N	Endangered	Endemic	251
\N	Dennstaedtia articulata Copel.	Dennstaedtiaceae	\N	Endangered	Endemic	252
\N	Dennstaedtia fusca Copel.	Dennstaedtiaceae	\N	Endangered	Endemic	253
\N	Microlepia protracta Copel.	Dennstaedtiaceae	\N	Endangered	Endemic	254
\N	Dicksonia mollis Holttum	Dicksoniaceae	\N	Endangered	Indigenous	255
Sibuyan Katmon	Dillenia sibuyanensis Merr.	Dilleniaceae	\N	Endangered	Endemic	256
\N	Dryopteris chrysocoma C.Chr.	Dryopteridaceae	\N	Endangered	Indigenous	262
\N	Dryopteris permagna M.G.Price	Dryopteridaceae	\N	Endangered	Endemic	263
\N	Polystichum nudum Copel.	Dryopteridaceae	\N	Endangered	Endemic	264
Malagos	Rhododendron javanicum (Blume) Benn.	Ericaceae	\N	Endangered	Indigenous	265
\N	Rhododendron madulidii Argent	Ericaceae	\N	Endangered	Endemic	266
\N	Rhododendron xanthopetalum Merr.	Ericaceae	\N	Endangered	Endemic	267
Tayabak, Jade Vine	Strongylodon macrobotrys A.Gray	Fabaceae	\N	Endangered	Endemic	271
Lanao Lipstick Plant	Aeschynanthus firmus Kraenzl.	Gesneriaceae	\N	Endangered	Endemic	273
Davao Lipstick Plant	Aeschynanthus littoralis Schltr.	Gesneriaceae	\N	Endangered	Endemic	274
Chila	Aeschynanthus nervosus Schltr.	Gesneriaceae	\N	Endangered	Endemic	275
Round-Leafed Lipstick Plant	Aeschynanthus ovatus Schltr.	Gesneriaceae	\N	Endangered	Endemic	276
\N	Agalmyla bilirana Hilliard & BL Burtt	Gesneriaceae	\N	Endangered	Endemic	277
\N	Agalmyla montis-tomasii Hilliard & BL Burtt	Gesneriaceae	\N	Endangered	Endemic	278
Paningit	Embolanthera spicata Merr.	Hamamelidaceae	\N	Endangered	Endemic	279
\N	Distichophyllum noguchianum B.C.Tan	Hookeriaceae	\N	Endangered	Endemic	280
Cebu Kalingag	Cinnamomum cebuense Kosterm.	Lauraceae	\N	Endangered	Endemic	283
Paren	Cryptocarya palawanensis Merr.	Lauraceae	\N	Endangered	Endemic	284
\N	Drepanolejeunea bakeri Herzog	Lejeuneaceae	\N	Endangered	Endemic	286
\N	Phlegmariurus carinatus (Desv. ex Poir.) Ching	Lycopodiaceae	\N	Endangered	Indigenous	287
\N	Phlegmariurus elmeri (Herter) A.R.Field & Bostock	Lycopodiaceae	\N	Endangered	Endemic	288
Tagulaylay	Phlegmariurus phlegmaria (L.) Holub	Lycopodiaceae	\N	Endangered	Indigenous	289
Tagulaylay	Phlegmariurus salvinioides (Herter) Ching	Lycopodiaceae	\N	Endangered	Indigenous	290
\N	Phlegmariurus squarrosa (G.Forst.) Á.Löve & D.Löve	Lycopodiaceae	\N	Endangered	Indigenous	291
Bantigi	Pemphis acidula J.R.Forst. & G.Forst.	Lythraceae	\N	Endangered	Indigenous	292
Gapas-Gapas	Camptostemon philippinense (S.Vidal) Becc.	Malvaceae	\N	Endangered	Indigenous	293
Red Durian	Durio graveolens Becc.	Malvaceae	\N	Endangered	Indigenous	294
Bungau	Christensenia aesculifolia (Blume) Maxon	Marattiaceae	\N	Endangered	Indigenous	295
\N	Matonia foxworthyi Copel.	Matoniaceae	\N	Endangered	Indigenous	296
Bungau	Astrocalyx calycina (Vidal) Merr.	Melastomataceae	\N	Endangered	Endemic	297
\N	Medinilla apayaoensis Merr.	Melastomataceae	\N	Endangered	Endemic	298
Kalambog-Lambog	Medinilla banahaensis Elmer	Melastomataceae	\N	Endangered	Endemic	299
\N	Medinilla binaria Elmer	Melastomataceae	\N	Endangered	Endemic	300
Tiualos Tatana	Medinilla calelanensis Elmer	Melastomataceae	\N	Endangered	Endemic	301
\N	Medinilla capitata Merr.	Melastomataceae	\N	Endangered	Endemic	302
Gubangbang	Medinilla clementis Merr.	Melastomataceae	\N	Endangered	Endemic	303
Salanakad	Medinilla compressicaulis Merr.	Melastomataceae	\N	Endangered	Endemic	304
Pagirang	Medinilla coronata Regalado	Melastomataceae	\N	Endangered	Endemic	305
Palikpik-Hito	Medinilla lagunae S.Vidal & Fern.-Vill.	Melastomataceae	\N	Endangered	Endemic	306
\N	Medinilla miniata Merr.	Melastomataceae	\N	Endangered	Endemic	307
Palawan Medinilla	Medinilla palawanensis Regalado	Melastomataceae	\N	Endangered	Endemic	308
Baladu	Medinilla pendula Merr.	Melastomataceae	\N	Endangered	Endemic	309
Lalanug	Medinilla stenobotrys Merr.	Melastomataceae	\N	Endangered	Endemic	310
Hagod	Medinilla surigaoensis Regalado	Melastomataceae	\N	Endangered	Endemic	311
\N	Medinilla tayabensis Merr.	Melastomataceae	\N	Endangered	Endemic	312
Bukalau	Walsura monophylla Merr.	Meliaceae	\N	Endangered	Endemic	313
\N	Nepenthes bellii Kondo	Nepenthaceae	\N	Endangered	Endemic	315
\N	Nepenthes burkei Mast.	Nepenthaceae	\N	Endangered	Endemic	316
\N	Nepenthes ceciliae Gronem. et al.	Nepenthaceae	\N	Endangered	Endemic	317
\N	Nepenthes copelandii Merrill ex Macfarl.	Nepenthaceae	\N	Endangered	Endemic	318
\N	Nepenthes gantungensis S.McPherson et al.	Nepenthaceae	\N	Endangered	Endemic	319
\N	Nepenthes mantalingajanensis J. Nerz & A. Wistuba	Nepenthaceae	\N	Endangered	Endemic	320
\N	Nepenthes petiolata Danser	Nepenthaceae	\N	Endangered	Endemic	321
Kuong-Kuong	Nepenthes philippinensis Macfarl.	Nepenthaceae	\N	Endangered	Endemic	322
\N	Nepenthes saranganiensis Sh.Kurata	Nepenthaceae	\N	Endangered	Endemic	323
\N	Nepenthes sumagaya Cheek	Nepenthaceae	\N	Endangered	Endemic	324
\N	Nepenthes surigaoensis Elmer	Nepenthaceae	\N	Endangered	Endemic	325
Sandaoua	Nepenthes truncata Macfarl.	Nepenthaceae	\N	Endangered	Endemic	326
\N	Nepenthes ultra Jebb & Cheek	Nepenthaceae	\N	Endangered	Endemic	327
Kako	Nepenthes ventricosa Blanco	Nepenthaceae	\N	Endangered	Endemic	328
\N	Nepenthes viridis Micheler et al.	Nepenthaceae	\N	Endangered	Endemic	329
Grape Fern	Botrychium lanuginosum Wall. ex Hook. & Grev.	Ophioglossaceae	\N	Endangered	Indigenous	330
\N	Ophioglossum pendulum L.	Ophioglossaceae	\N	Endangered	Indigenous	331
\N	Ophioglossum ramosii Copel.	Ophioglossaceae	\N	Endangered	Endemic	332
\N	Aerides lawrenciae Reichb.f.	Orchidaceae	\N	Endangered	Endemic	333
\N	Amesiella philippinensis (Ames) Garay	Orchidaceae	\N	Endangered	Endemic	334
\N	Arachnis flos-aeris (L.) Rchb.f.	Orchidaceae	\N	Endangered	Indigenous	335
\N	Bulbophyllum nymphopolitanum Kraenzl.	Orchidaceae	\N	Endangered	Endemic	336
\N	Bulbophyllum philippinense Ames	Orchidaceae	\N	Endangered	Endemic	337
\N	Bulbophyllum piestoglossum J.J.Verm.	Orchidaceae	\N	Endangered	Endemic	338
\N	Bulbophyllum stellatum Ames	Orchidaceae	\N	Endangered	Endemic	339
\N	Cirrhopetalum cumingii Lindl.	Orchidaceae	\N	Endangered	Endemic	340
\N	Cirrhopetalum loherianum Kranzl.	Orchidaceae	\N	Endangered	Endemic	341
\N	Cleisostoma sagittatum Blume,	Orchidaceae	\N	Endangered	Indigenous	342
\N	Coelogyne confusa Ames	Orchidaceae	\N	Endangered	Endemic	343
\N	Coelogyne palawanensis Ames	Orchidaceae	\N	Endangered	Endemic	344
\N	Corybas laceratus LO Williams	Orchidaceae	\N	Endangered	Endemic	345
\N	Corybas merrillii (Ames) Ames	Orchidaceae	\N	Endangered	Endemic	346
\N	Corybas ramosianus J Dransf.	Orchidaceae	\N	Endangered	Endemic	347
\N	Cymbidium aliciae Quisumb.	Orchidaceae	\N	Endangered	Endemic	348
\N	Cymbidium ensifolium (L.) Sw.	Orchidaceae	\N	Endangered	Endemic	349
\N	Dendrobium bullenianum Rchb.f	Orchidaceae	\N	Endangered	Endemic	350
\N	Dendrobium goldschmidtianum Kraenzl.	Orchidaceae	\N	Endangered	Indigenous	351
\N	Dendrobium lunatum Lindl.	Orchidaceae	\N	Endangered	Endemic	352
\N	Grammatophyllum measuresianum Sander	Orchidaceae	\N	Endangered	Indigenous	353
\N	Phalaenopsis hieroglyphica (Reichb.f.) HR Sweet	Orchidaceae	\N	Endangered	Endemic	354
\N	Phalaenopsis lindenii Loher	Orchidaceae	\N	Endangered	Endemic	355
\N	Phalaenopsis lueddemanniana Reichb.f.	Orchidaceae	\N	Endangered	Endemic	356
\N	Phalaenopsis pallens (Lindl.) Reichb.f.	Orchidaceae	\N	Endangered	Endemic	357
\N	Phalaenopsis philippinensis (Golamco) ex Fowlie & C.Z.Tsang	Orchidaceae	\N	Endangered	Endemic	358
\N	Phalaenopsis pulchra (Reichb.f) HR Sweet	Orchidaceae	\N	Endangered	Endemic	359
\N	Phalaenopsis reichenbachiana Reichb.f. & Sander	Orchidaceae	\N	Endangered	Endemic	360
\N	Phalaenopsis sanderiana Reichb.f.	Orchidaceae	\N	Endangered	Endemic	361
\N	Phalaenopsis schilleriana Reichb.f.	Orchidaceae	\N	Endangered	Endemic	362
\N	Phalaenopsis stuartiana Reichb.f.	Orchidaceae	\N	Endangered	Endemic	363
\N	Phalaenopsis x veitchiana Rchb.f	Orchidaceae	\N	Endangered	Endemic	364
\N	Phalaenopsis amabilis (L.) Blume	Orchidaceae	\N	Endangered	Indigenous	365
\N	Renanthera monachica Ames	Orchidaceae	\N	Endangered	Endemic	366
\N	Renanthera storiei Rchb.f.	Orchidaceae	\N	Endangered	Endemic	367
\N	Staurochilus leytensis (Ames) Christenson	Orchidaceae	\N	Endangered	Endemic	368
\N	Trichoglottis loheriana (Kraenzl.) L.O.Williams	Orchidaceae	\N	Endangered	Endemic	369
\N	Trichoglottis luzonensis (Ames) Ames	Orchidaceae	\N	Endangered	Endemic	370
\N	Vanda javierae D Tiu ex Fessel & Lückel	Orchidaceae	\N	Endangered	Endemic	371
\N	Vanda luzonica Loher ex Rolfe	Orchidaceae	\N	Endangered	Endemic	372
\N	Vanda merrillii Ames & Quisumb.	Orchidaceae	\N	Endangered	Endemic	373
\N	Vanda scandens Holttum	Orchidaceae	\N	Endangered	Indigenous	374
Pulag Carpet Grass	Rytidosperma oreoboloides (F.Muell.) H.P.Linder	Poaceae	\N	Endangered	Indigenous	375
Igem-Lakibunga	Podocarpus macrocarpus de Laub.	Podocarpaceae	\N	Endangered	Endemic	377
Igem-Bilogan	Podocarpus ramosii R.R.Mill	Podocarpaceae	\N	Endangered	Indigenous	378
Ant Fern	Lecanopteris luzonensis Hennip.	Polypodiaceae	\N	Endangered	Endemic	379
\N	Lecanopteris deparioides (Cesati) Baker	Polypodiaceae	\N	Endangered	Indigenous	380
\N	Lecanopteris sarcopus (Teijsm. & Binn.) Copel.	Polypodiaceae	\N	Endangered	Indigenous	381
\N	Lecanopteris sinuosa (Wall. ex Hook.) Copel.	Polypodiaceae	\N	Endangered	Indigenous	382
Tailed Fern	Lepisorus platyrhynchos (Kunze) Li Wang	Polypodiaceae	\N	Endangered	Indigenous	383
Flat Whisk Fern	Psilotum complanatum Sw.	Psilotaceae	\N	Endangered	Indigenous	384
Zamora Whisk Fern	Tmesipteris zamorae Gruezo & Amoroso,	Psilotaceae	\N	Endangered	Endemic	385
Mindanao Maindenhair Fern	Adiantum (= Pteris) mindanaoense Copel.	Pteridaceae	\N	Endangered	Endemic	386
\N	Ceratopteris thalictroides (L.) Brongn.	Pteridaceae	\N	Endangered	Indigenous	387
\N	Doryopteris concolor (Langsd & Fisch) Kuhn	Pteridaceae	\N	Endangered	Indigenous	388
\N	Pteris endoneura MG Price	Pteridaceae	\N	Endangered	Endemic	389
\N	Rafflesia baletei Barcelona & Cajano	Rafflesiaceae	\N	Endangered	Endemic	390
Malaboo	Rafflesia manillana Teschem.	Rafflesiaceae	\N	Endangered	Endemic	391
\N	Rafflesia mira Fernando & Ong	Rafflesiaceae	\N	Endangered	Endemic	392
\N	Rafflesia philippensis Blanco ex Llanos	Rafflesiaceae	\N	Endangered	Endemic	393
Uruy	Rafflesia speciosa Barcelona & Fernando	Rafflesiaceae	\N	Endangered	Endemic	394
\N	Rhachithecium papillosum (Williams) Wijk & Margard.	Rhachitheciaceae	\N	Endangered	Endemic	395
\N	Antherostele banahaensis (Elmer) Bremek.	Rubiaceae	\N	Endangered	Endemic	396
\N	Antherostele grandistipula (Merr.) Bremek.	Rubiaceae	\N	Endangered	Endemic	397
\N	Boholia nematostylis Merr.	Rubiaceae	\N	Endangered	Indigenous	398
Kubili	Cubilia cubili (Blanco) Adelb.	Sapindaceae	\N	Endangered	Indigenous	399
Tamaho	Gloeocarpus patentivalvis (Radlk.) Radlk.	Sapindaceae	\N	Endangered	Endemic	400
Pasi	Guioa acuminata Radlk.	Sapindaceae	\N	Endangered	Endemic	401
Malalóno	Madhuca lanceolata Merr.	Sapotaceae	\N	Endangered	Endemic	403
Bétis-Bundók	Madhuca monticola (Merr.) Merr	Sapotaceae	\N	Endangered	Endemic	404
Malabetis	Madhuca oblongifolia (Merr.) Merr.	Sapotaceae	\N	Endangered	Endemic	405
\N	Actinostachys inopinata (Selling) C.F.Reed	Schizaeaceae	\N	Endangered	Indigenous	407
\N	Schizaea malaccana Baker	Schizaeaceae	\N	Endangered	Indigenous	408
\N	Selaginella apoensis Hieron.	Selaginellaceae	\N	Endangered	Endemic	409
\N	Selaginella magnifica Warb.	Selaginellaceae	\N	Endangered	Endemic	410
\N	Selaginella pricei BC Tan & Jermy	Selaginellaceae	\N	Endangered	Endemic	411
\N	Selaginella tamariscina (P.Beauv.) Spring	Selaginellaceae	\N	Endangered	Indigenous	412
Linatog	Eurycoma longifolia Jack	Simaroubaceae	\N	Endangered	Endemic	413
Co Mabunót	Gomphandra coi Schori	Stemonuraceae	\N	Endangered	Endemic	414
\N	Gomphandra psilandra Schori	Stemonuraceae	\N	Endangered	Endemic	415
\N	Gomphandra ultramafiterrestris Schori	Stemonuraceae	\N	Endangered	Endemic	416
\N	Psomiocarpa apiifolia C Presl	Tectariaceae	\N	Endangered	Endemic	417
\N	Tectaria lobbii (Hook.) Copel.	Tectariaceae	\N	Endangered	Indigenous	418
\N	Tectaria macleanii (Copel.) S.Y.Dong	Tectariaceae	\N	Endangered	Indigenous	419
\N	Tectaria stalactica MG Price	Tectariaceae	\N	Endangered	Endemic	420
Agarwood/Bari	Aquilaria malaccensis Lam.	Thymelaeaceae	\N	Endangered	Indigenous	421
\N	Rinorea niccolifera Fernando	Violaceae	\N	Endangered	Endemic	422
Dainsuli	Hedychium philippense K Schum.	Zingiberaceae	\N	Endangered	Endemic	423
\N	Gymnostachyum palawanense Elmer	Acanthaceae	\N	Vulnerable	Endemic	424
\N	Gymnostachyum pictum Elmer	Acanthaceae	\N	Vulnerable	Endemic	425
\N	Justicia addisoniensis (Elmer) C.M.Gao & Y.F.Deng	Acanthaceae	\N	Vulnerable	Endemic	426
\N	Justicia pulgarensis (Elmer) C.M.Gao & Y.F. Deng	Acanthaceae	\N	Vulnerable	Endemic	427
\N	Lepidagathis palawanensis Merr.	Acanthaceae	\N	Vulnerable	Endemic	428
\N	Ptyssiglottis aequifolia (C.B.Clarke) Merr.	Acanthaceae	\N	Vulnerable	Endemic	429
\N	Ptyssiglottis elmeri Merr.	Acanthaceae	\N	Vulnerable	Endemic	430
\N	Ruellia philippinensis Elmer	Acanthaceae	\N	Vulnerable	Endemic	431
\N	Staurogyne nudispica (C.B.Clarke) Bremek.	Acanthaceae	\N	Vulnerable	Endemic	432
\N	Strobilanthes palawanensis Elmer	Acanthaceae	\N	Vulnerable	Endemic	433
Dagwey	Saurauia bontocensis Merr.	Actinidiaceae	\N	Vulnerable	Endemic	434
Mutá-Mutá	Saurauia longistyla Merr.	Actinidiaceae	\N	Vulnerable	Endemic	435
Malapaho	Mangifera monandra Merr.	Anacardiaceae	\N	Vulnerable	Endemic	437
Apali	Mangifera longipes Griff.	Anacardiaceae	\N	Vulnerable	Indigenous	439
Ligas-Ilanan	Semecarpus paucinervius Merr.	Anacardiaceae	\N	Vulnerable	Indigenous	440
Lomarau	Swintonia acuta Engl.	Anacardiaceae	\N	Vulnerable	Indigenous	441
Kalabúyo	Dasymaschalon scandens Merr.	Annonaceae	\N	Vulnerable	Endemic	442
Palawan Pirángat	Desmos palawanensis (Elmer) Merr.	Annonaceae	\N	Vulnerable	Endemic	443
Ubáran	Miliusa horsfieldii (Benn.) Baill. ex Pierre	Annonaceae	\N	Vulnerable	Endemic	444
Lanútan-Bangúhan	Mitrephora fragrans Merr.	Annonaceae	\N	Vulnerable	Endemic	445
Tabingálang	Orophea creaghii (Ridl.) Leonardia & Kessler	Annonaceae	\N	Vulnerable	Endemic	446
Bangar	Polyalthia elmeri Merr.	Annonaceae	\N	Vulnerable	Endemic	447
Palawan Lanutan	Polyalthia palawanensis Merr.	Annonaceae	\N	Vulnerable	Endemic	448
\N	Uvaria lurida Hook.f. & Thomson	Annonaceae	\N	Vulnerable	Indigenous	449
Silhigan	Alstonia iwahigensis Elmer	Apocynaceae	\N	Vulnerable	Indigenous	450
\N	Hoya meliflua (Blanco) Merr.	Apocynaceae	\N	Vulnerable	Endemic	451
\N	Hoya paziae Kloppenb.	Apocynaceae	\N	Vulnerable	Endemic	452
Merrill Pasnit	Kibatalia merrilliana Woodson	Apocynaceae	\N	Vulnerable	Endemic	453
\N	Quisumbingia merrillii (Schltr.) Merr.	Apocynaceae	\N	Vulnerable	Endemic	454
Sakang-Manok/Alibótbot	Tabernaemontana cordata Merr.	Apocynaceae	\N	Vulnerable	Endemic	455
\N	Urceola laevis (Elmer) Merr.	Apocynaceae	\N	Vulnerable	Indigenous	456
Tabo	Willughbeia sarawacensis (Pierre) K.Schum.	Apocynaceae	\N	Vulnerable	Indigenous	457
Palawan Lanéte	Wrightia palawanensis D.J.Middleton	Apocynaceae	\N	Vulnerable	Endemic	458
Palawan Kalásan	Ilex palawanica Loes. ex Elmer	Aquifoliaceae	\N	Vulnerable	Endemic	459
\N	Alocasia micholitziana Sander	Araceae	\N	Vulnerable	Endemic	460
Badiang	Alocasia zebrina Schott ex van Houtte	Araceae	\N	Vulnerable	Endemic	461
\N	Homalomena palawanensis Engl.	Araceae	\N	Vulnerable	Endemic	462
Higin	Polyscias pulgarense Elmer	Araliaceae	\N	Vulnerable	Endemic	463
\N	Schefflera microphylla Merr.	Araliaceae	\N	Vulnerable	Endemic	464
Bagtik	Agathis dammara (Lamb.) Rich. & A.Rich.	Araucariaceae	\N	Vulnerable	Indigenous	465
Búngang Jolo,\nManila Palm	Adonidia merrillii (Becc.) Becc	Arecaceae	\N	Vulnerable	Endemic	467
Pisa, Sambulayan	Areca hutchinsoniana Becc.	Arecaceae	\N	Vulnerable	Endemic	468
Bungang-Ipot	Areca ipot Becc.	Arecaceae	\N	Vulnerable	Endemic	469
Boga, Pita	Areca vidaliana Becc.	Arecaceae	\N	Vulnerable	Indigenous	470
Pit-Pit, Saranoi	Calamus curranii (Becc.) W.J.Baker	Arecaceae	\N	Vulnerable	Endemic	471
Abuan	Calamus diepenhorstii Miq.	Arecaceae	\N	Vulnerable	Endemic	472
Arorog	Calamus javensis Blume	Arecaceae	\N	Vulnerable	Indigenous	473
Pin-Pin	Calamus jenkinsianus Griff.	Arecaceae	\N	Vulnerable	Indigenous	474
Bugtong	Calamus subinermis Wendl. ex Becc.	Arecaceae	\N	Vulnerable	Indigenous	475
Buragat	Korthalsia merrillii Becc.	Arecaceae	\N	Vulnerable	Endemic	476
Kalalias	Korthalsia robusta Blume	Arecaceae	\N	Vulnerable	Indigenous	477
Balatbat	Licuala spinosa Wurmb.	Arecaceae	\N	Vulnerable	Indigenous	478
Anibong	Oncosperma tigillarium (Jack) Ridl.	Arecaceae	\N	Vulnerable	Indigenous	479
\N	Orania decipiens Becc.	Arecaceae	\N	Vulnerable	Endemic	480
Curran Abíki	Pinanga curranii Becc.	Arecaceae	\N	Vulnerable	Endemic	481
Dahu	Asplenium vittaeforme Cav.	Aspleniaceae	\N	Vulnerable	Indigenous	482
\N	Begonia chingipengii R.Rubite	Begoniaceae	\N	Vulnerable	Endemic	483
\N	Begonia cleopatrae C.Coyle	Begoniaceae	\N	Vulnerable	Endemic	484
\N	Begonia coronensis Merr.	Begoniaceae	\N	Vulnerable	Endemic	485
\N	Begonia cumingiana (Klotzsch.) A.DC	Begoniaceae	\N	Vulnerable	Endemic	486
\N	Begonia georgei C.Coyle	Begoniaceae	\N	Vulnerable	Endemic	487
\N	Begonia gutierrezii C.Coyle	Begoniaceae	\N	Vulnerable	Endemic	488
\N	Begonia oxysperma A DC	Begoniaceae	\N	Vulnerable	Endemic	489
\N	Begonia suborbiculata Merr.	Begoniaceae	\N	Vulnerable	Endemic	490
\N	Begonia tandangii C.-I.Peng & R.Rubite	Begoniaceae	\N	Vulnerable	Endemic	491
\N	Begonia wilkiei C.Coyle	Begoniaceae	\N	Vulnerable	Endemic	492
\N	Begonia woodii Merr	Begoniaceae	\N	Vulnerable	Endemic	493
\N	Berberis barandana S.Vidal	Berberidaceae	\N	Vulnerable	Endemic	494
Labayanan	Radermachera coriacea Merr.	Bignoniaceae	\N	Vulnerable	Endemic	495
\N	Blechnum egregium Copel.	Blechnaceae	\N	Vulnerable	Indigenous	496
\N	Blechnum fraseri (A.Cunn.) Luerss.	Blechnaceae	\N	Vulnerable	Indigenous	497
\N	Bryoxiphium norvegicum (Brid.) Mitt.	Bryoxiphiaceae	\N	Vulnerable	Indigenous	498
Marangub	Protium connarifolium (Perkins) Merr.	Burseraceae	\N	Vulnerable	Endemic	499
Palawan Agoho	Gymnostoma nobile (Whitmore) L.A.S. Johnson	Casuarinaceae	\N	Vulnerable	Indigenous	500
Palawan Surag	Glyptopetalum palawanense Merr.	Celastraceae	\N	Vulnerable	Endemic	501
\N	Salacia cymosa Elmer	Celastraceae	\N	Vulnerable	Endemic	502
\N	Salacia marginata Ding Hou	Celastraceae	\N	Vulnerable	Endemic	503
Merrillanaháu	Saribus merrillii (Becc.) Bacon & W.J.Baker	Arecaceae	\N	Vulnerable	Endemic	504
\N	Calamus ornatus Blume var. pulverulentus Fernando	Arecaceae	\N	Vulnerable	Endemic	505
Tagobáhi	Clethra pulgarensis Elmer	Clethraceae	\N	Vulnerable	Endemic	506
Bunóg-Diláu	Garcinia sulphurea Elmer	Clusiaceae	\N	Vulnerable	Endemic	507
Bongoran	Terminalia macrantha Merr. & Quisumb. ex Rojo	Combretaceae	\N	Vulnerable	Endemic	508
Dalinsoi	Terminalia surigaensis Merr.	Combretaceae	\N	Vulnerable	Endemic	509
\N	Cyathea callosa Christ	Cyatheaceae	\N	Vulnerable	Endemic	510
\N	Cyathea caudata (J Sm.) Copel.	Cyatheaceae	\N	Vulnerable	Endemic	511
\N	Cyathea cinerea Copel.	Cyatheaceae	\N	Vulnerable	Endemic	512
\N	Cyathea elmeri (Copel.) Copel.	Cyatheaceae	\N	Vulnerable	Indigenous	513
\N	Cyathea fenicis (C. Chr.) Copel.	Cyatheaceae	\N	Vulnerable	Indigenous	514
\N	Cyathea fuliginosa (Christ) Copel.	Cyatheaceae	\N	Vulnerable	Endemic	515
\N	Cyathea halconensis Christ	Cyatheaceae	\N	Vulnerable	Endemic	516
\N	Cyathea heterochlamydea Copel.	Cyatheaceae	\N	Vulnerable	Endemic	517
\N	Cyathea negrosiana Christ	Cyatheaceae	\N	Vulnerable	Endemic	518
\N	Cyathea philippinensis Baker	Cyatheaceae	\N	Vulnerable	Endemic	519
\N	Cyathea robinsonii Copel.	Cyatheaceae	\N	Vulnerable	Endemic	520
\N	Cyathea setulosa Copel.	Cyatheaceae	\N	Vulnerable	Endemic	521
Pitogong-Dagat	Cycas edentata de Laub.	Cycadaceae	\N	Vulnerable	Endemic	522
\N	Cycas vespertilio KD. Hill & Lindstr.	Cycadaceae	\N	Vulnerable	Endemic	523
Pitogo	Cycas riuminiana Porte ex Regel	Cycadaceae	\N	Vulnerable	Indigenous	524
\N	Bescherellia elegantissima Duby	Cyrtopodaceae	\N	Vulnerable	Endemic	525
\N	Gymnocarpium oyamense (Baker) Ching	Cystopteridaceae	\N	Vulnerable	Indigenous	526
\N	Dillenia cauliflora Merr	Dilleniaceae	\N	Vulnerable	Endemic	527
Fischer Katmon	Dillenia fischeri Merr.	Dilleniaceae	\N	Vulnerable	Endemic	528
Kátmon-Bugtóng	Dillenia monantha Merr	Dilleniaceae	\N	Vulnerable	Endemic	530
Palawan Ube	Dioscorea palawana Prain & Burkill	Dioscoreaceae	\N	Vulnerable	Endemic	531
Tailed-Leaf Panáu	Dipterocarpus caudatus Foxw.	Dipterocarpaceae	\N	Vulnerable	Endemic	532
Panau	Dipterocarpus gracilis Blume	Dipterocarpaceae	\N	Vulnerable	Indigenous	534
\N	Hopea rudiformis P.S.Ashton	Dipterocarpaceae	\N	Vulnerable	Indigenous	539
Merill Katap	Trigonostemon merrillii Elmer	Euphorbiaceae	\N	Vulnerable	Indigenous	541
Blanco Narig	Vatica umbonata (Hook.f.) Burck	Dipterocarpaceae	\N	Vulnerable	Indigenous	547
\N	Dryopteris polita Rosenst.	Dryopteridaceae	\N	Vulnerable	Indigenous	548
Kamagong	Diospyros discolor Willd.	Ebenaceae	\N	Vulnerable	Indigenous	550
\N	Rhododendron edanoi Merr. & Quisumb	Ericaceae	\N	Vulnerable	Endemic	555
Koch'S Malagos	Rhododendron kochii Stein	Ericaceae	\N	Vulnerable	Endemic	556
\N	Rhododendron loboense H. F. Copel.	Ericaceae	\N	Vulnerable	Endemic	557
Ausip	Rhododendron subsessile Rendle	Ericaceae	\N	Vulnerable	Endemic	558
\N	Rhododendron vidalii Rolfe	Ericaceae	\N	Vulnerable	Endemic	559
\N	Rhododendron wilkei Argent	Ericaceae	\N	Vulnerable	Endemic	560
\N	Vaccinium brachytrichum Sleumer	Ericaceae	\N	Vulnerable	Endemic	561
Pagangpang	Vaccinium gitingense Elmer	Ericaceae	\N	Vulnerable	Endemic	562
\N	Erpodium luzonense (Bartr.) H.A. Crum	Erpodiaceae	\N	Vulnerable	Indigenous	563
\N	Solmsiella biseriata (Austin) Steere	Erpodiaceae	\N	Vulnerable	Indigenous	564
Súda-Súda	Euphorbia trigona Mill.	Euphorbiaceae	\N	Vulnerable	Endemic	566
Dila-Dila	Cynometra inaequifolia A Gray	Fabaceae	\N	Vulnerable	Endemic	569
Palawan Ipil	Intsia palembanica Miq.	Fabaceae	\N	Vulnerable	Indigenous	571
\N	Kunstleria forbesii Prain	Fabaceae	\N	Vulnerable	Endemic	573
Makapilit	Pericopsis mooniana Thwaites	Fabaceae	\N	Vulnerable	Indigenous	574
\N	Phanera aherniana (Perkins) de Wit	Fabaceae	\N	Vulnerable	Indigenous	575
Kayugalo	Sindora inermis Merr.	Fabaceae	\N	Vulnerable	Endemic	576
Bindanugan	Strongylodon elmeri Merr.	Fabaceae	\N	Vulnerable	Endemic	577
\N	Teyleria tetragona (Merr.) J.A.Lackey & Maesen	Fabaceae	\N	Vulnerable	Endemic	578
Apo Oak	Lithocarpus apoensis (Elmer) Rehd.	Fagaceae	\N	Vulnerable	Endemic	580
Katiluk	Lithocarpus jordanae (Fern.-Villar) Rehd.	Fagaceae	\N	Vulnerable	Endemic	581
\N	Aeschynanthus cuernosensis Elmer	Gesneriaceae	\N	Vulnerable	Endemic	582
\N	Aeschynanthus curvicalyx Mendum	Gesneriaceae	\N	Vulnerable	Endemic	583
\N	Aeschynanthus elmeri Mendum	Gesneriaceae	\N	Vulnerable	Endemic	584
\N	Aeschynanthus madulidii Mendum	Gesneriaceae	\N	Vulnerable	Endemic	585
Pamingkauan	Aeschynanthus miniaceus BL Burtt & PJB Woods	Gesneriaceae	\N	Vulnerable	Endemic	586
\N	Aeschynanthus pergracilis Kraenzl.	Gesneriaceae	\N	Vulnerable	Endemic	587
\N	Aeschynanthus truncatus Schltr.	Gesneriaceae	\N	Vulnerable	Endemic	588
\N	Agalmyla biflora (Elmer) Hilliard & BL Burtt	Gesneriaceae	\N	Vulnerable	Endemic	589
Tasik Sa Lomot	Agalmyla calelanensis (Elmer) Hilliard & BL Burtt	Gesneriaceae	\N	Vulnerable	Endemic	590
\N	Agalmyla glabra (Merr.) Hilliard & BL Burtt	Gesneriaceae	\N	Vulnerable	Endemic	591
\N	Agalmyla parvilimba Hilliard & BL Burtt	Gesneriaceae	\N	Vulnerable	Endemic	592
\N	Agalmyla persimilis Hilliard & BL Burtt	Gesneriaceae	\N	Vulnerable	Endemic	593
\N	Agalmyla rotundiloba Hilliard & BL Burtt	Gesneriaceae	\N	Vulnerable	Endemic	594
\N	Agalmyla samarica Hilliard & BL Burtt	Gesneriaceae	\N	Vulnerable	Endemic	595
\N	Agalmyla sibuyanensis Hilliard & BL Burtt	Gesneriaceae	\N	Vulnerable	Endemic	596
Balibadon	Agalmyla urdanetensis (Elmer) Hilliard & BL Burtt	Gesneriaceae	\N	Vulnerable	Endemic	597
\N	Codonoboea woodii (Merr.) A.Weber	Gesneriaceae	\N	Vulnerable	Endemic	598
\N	Cyrtandra cleopatrae H.J.Atkins & Cronk	Gesneriaceae	\N	Vulnerable	Endemic	599
\N	Cyrtandra elatostemmoides Elmer	Gesneriaceae	\N	Vulnerable	Indigenous	600
\N	Cyrtandra inaequifolia Elmer	Gesneriaceae	\N	Vulnerable	Endemic	601
\N	Cyrtandra livida Kraenzl.	Gesneriaceae	\N	Vulnerable	Endemic	602
\N	Hedyotis bambusetorum Merr.	Rubiaceae	\N	Vulnerable	Endemic	603
\N	Cyrtandra hirtigera H.J.Atkins & Cronk var. chlorina H.J.Atkins & Cronk	Gesneriaceae	\N	Vulnerable	Endemic	605
\N	Cyrtandra hirtigera H.J.Atkins & Cronk var. hirtigera	Gesneriaceae	\N	Vulnerable	Endemic	606
\N	Cyrtandra pulgarensis Elmer ex H.J.Atkins & Cronk	Gesneriaceae	\N	Vulnerable	Endemic	607
\N	Cyrtandra rupicola Elmer	Gesneriaceae	\N	Vulnerable	Endemic	608
\N	Bryobrothera crenulata (Broth. & Par.) Ther.	Hookeriaceae	\N	Vulnerable	Indigenous	609
\N	Ephemeropsis tjibodensis Goeb.	Hookeriaceae	\N	Vulnerable	Indigenous	610
\N	Clerodendrum macrocalyx HJ Lam	Lamiaceae	\N	Vulnerable	Endemic	611
Bagab	Clerodendrum mindorense Merr.	Lamiaceae	\N	Vulnerable	Endemic	612
Alipúng	Gmelina philippensis Cham.	Lamiaceae	\N	Vulnerable	Endemic	614
\N	Cinnamomum rupestre Kosterm.	Lauraceae	\N	Vulnerable	Endemic	615
Bagarilau	Cryptocarya ampla Merr.	Lauraceae	\N	Vulnerable	Endemic	616
Palawan Pútat	Barringtonia palawanensis Chantar.	Lecythidaceae	\N	Vulnerable	Endemic	617
Ridsdale Pútat	Barringtonia ridsdalei Chantar.	Lecythidaceae	\N	Vulnerable	Endemic	618
Vonitan	Lilium longiflorum Thunb.	Liliaceae	\N	Vulnerable	Indigenous	619
Luplupak	Lilium philippinense Baker	Liliaceae	\N	Vulnerable	Indigenous	620
\N	Philbornea magnifolia (Stapf) Hallier f.	Linaceae	\N	Vulnerable	Indigenous	621
\N	Strychnos oleifolia A.W.Hill	Loganiaceae	\N	Vulnerable	Endemic	622
Panugianon	Durio macrophyllus (King) Ridl.	Malvaceae	\N	Vulnerable	Indigenous	623
Bagún	Grewia palawanensis Merr.	Malvaceae	\N	Vulnerable	Endemic	624
Clover Fern	Marsilea minuta L.	Marsileaceae	\N	Vulnerable	Indigenous	625
Ickis Tungau	Beccarianthus ickisii Merr.	Melastomataceae	\N	Vulnerable	Endemic	626
Malintungau	Beccarianthus pulcherrimus (Merr.) Maxw.	Melastomataceae	\N	Vulnerable	Endemic	627
\N	Medinilla cumingii Naudin	Melastomataceae	\N	Vulnerable	Endemic	628
Gunang	Medinilla dolichophylla Merr.	Melastomataceae	\N	Vulnerable	Endemic	629
\N	Memecylon odoratum Elmer	Melastomataceae	\N	Vulnerable	Endemic	630
Kaniuing-Kitid	Aglaia angustifolia Miq.	Meliaceae	\N	Vulnerable	Indigenous	631
Oksa	Aglaia tenuicaulis Hiern	Meliaceae	\N	Vulnerable	Indigenous	632
Maranggo	Azadirachta excelsa (Jack) Jacobs	Meliaceae	\N	Vulnerable	Indigenous	633
Tarublang	Dysoxylum cauliflorum Hiern	Meliaceae	\N	Vulnerable	Indigenous	634
Samar Yabnob	Horsfieldia samarensis de Wilde	Myristicaceae	\N	Vulnerable	Endemic	636
Kalaum	Syzygium borneense (Miq.) Miq.	Myrtaceae	\N	Vulnerable	Indigenous	637
Lamútong-Linís	Syzygium ecostulatum (Elmer) Merr.	Myrtaceae	\N	Vulnerable	Endemic	638
Iwahig Malarúhat	Syzygium iwahigense (Elmer) Merr.	Myrtaceae	\N	Vulnerable	Endemic	639
Duhao	Knema latericia Elmer v. latericia	Myristicaceae	\N	Vulnerable	Endemic	643
\N	Knema latericia Elmer var. subtilis W.J.de Wilde	Myristicaceae	\N	Vulnerable	Indigenous	644
\N	Nepenthes cornuta Marwinski et al.	Nepenthaceae	\N	Vulnerable	Endemic	646
\N	Nepenthes hamiguitanensis Gronem. et al	Nepenthaceae	\N	Vulnerable	Endemic	647
\N	Nepenthes mindanaoensis Sh.Kurata	Nepenthaceae	\N	Vulnerable	Endemic	648
\N	Nepenthes pantaronensis Gieray et al.	Nepenthaceae	\N	Vulnerable	Endemic	649
\N	Nepenthes talaandig Gronem. et al.	Nepenthaceae	\N	Vulnerable	Endemic	650
Bansilai	Brackenridgea palustris Bartell.	Ochnaceae	\N	Vulnerable	Endemic	651
\N	Botrychium daucifolium Wall. ex Hook. & Grev.	Ophioglossaceae	\N	Vulnerable	Indigenous	652
\N	Aerides leeana Reichb.f.	Orchidaceae	\N	Vulnerable	Endemic	653
\N	Aerides quinquevulnera Lindl.	Orchidaceae	\N	Vulnerable	Endemic	654
\N	Ascidieria palawanensis (Ames) W.Suarez & Cootes	Orchidaceae	\N	Vulnerable	Endemic	655
\N	Bulbophyllum curranii Ames	Orchidaceae	\N	Vulnerable	Endemic	656
\N	Bulbophyllum papulosum Garay	Orchidaceae	\N	Vulnerable	Endemic	657
\N	Dendrobium nemorale L.O.Williams	Orchidaceae	\N	Vulnerable	Endemic	658
\N	Dendrobium sanderae Rolfe	Orchidaceae	\N	Vulnerable	Endemic	659
\N	Dendrobium usterioides Ames	Orchidaceae	\N	Vulnerable	Endemic	660
\N	Dendrobium victoria-reginae Loher	Orchidaceae	\N	Vulnerable	Endemic	661
\N	Dendrobium secundum (Blume) Lindl. in Wall.	Orchidaceae	\N	Vulnerable	Indigenous	662
\N	Dendrochilum kingii (Hook.f.) J.J.Sm.	Orchidaceae	\N	Vulnerable	Indigenous	663
\N	Epigeneium treacherianum (Rchb.f ex Hook.f.) Summerh.	Orchidaceae	\N	Vulnerable	Indigenous	664
Rosa Mia	Grammatophyllum multiflorum Lindl.	Orchidaceae	\N	Vulnerable	Endemic	665
\N	Grammatophyllum scriptum (L.) Blume	Orchidaceae	\N	Vulnerable	Indigenous	666
\N	Liparis palawanensis Ames	Orchidaceae	\N	Vulnerable	Endemic	667
\N	Phalaenopsis aphrodite Rchb.f	Orchidaceae	\N	Vulnerable	Endemic	668
\N	Phalaenopsis bastianii O.Gruss & Roellke	Orchidaceae	\N	Vulnerable	Endemic	669
\N	Phalaenopsis equestris (Schauer) Rchb.f	Orchidaceae	\N	Vulnerable	Endemic	670
\N	Phalaenopsis fasciata Reichb.f.	Orchidaceae	\N	Vulnerable	Endemic	671
\N	Phalaenopsis x intermedia	Orchidaceae	\N	Vulnerable	Endemic	672
\N	Phalaenopsis x leucorrhoda	Orchidaceae	\N	Vulnerable	Endemic	673
\N	Phalaenopsis cornu-cervi (Breda) Blume & Rchb.f.	Orchidaceae	\N	Vulnerable	Indigenous	674
\N	Phalaenopsis mariae Burb. ex R.Warner & H.Williams	Orchidaceae	\N	Vulnerable	Indigenous	675
\N	Pinalia curranii (Leav.) W.Suarez & Cootes	Orchidaceae	\N	Vulnerable	Endemic	676
\N	Vandopsis lissochiloides (Gaudich.) Pfitzer in Engl. & Prantl	Orchidaceae	\N	Vulnerable	Indigenous	677
Bagaas, Abasanay/Malapandan	Sararanga philippinensis Merr.	Pandanaceae	\N	Vulnerable	Endemic	678
\N	Pentaphragma platyphyllum Merr.	Pentaphragmataceae	\N	Vulnerable	Endemic	679
Limpahung	Baccaurea lanceolata (Miq.) Müll.Arg. in DC.	Phyllanthaceae	\N	Vulnerable	Indigenous	680
Cenabre Bágna	Glochidion cenabrei Merr.	Phyllanthaceae	\N	Vulnerable	Endemic	681
Tabángo	Glochidion dolichostylum Merr	Phyllanthaceae	\N	Vulnerable	Endemic	682
\N	Glochidion palawanense Elmer	Phyllanthaceae	\N	Vulnerable	Endemic	683
\N	Glochidion pulgarense Elmer	Phyllanthaceae	\N	Vulnerable	Endemic	684
Manglas	Phyllanthus balgooyi Petra Hoffm. & A.J.M.Baker	Phyllanthaceae	\N	Vulnerable	Indigenous	685
\N	Phyllanthus glochidioides Elmer	Phyllanthaceae	\N	Vulnerable	Endemic	686
Mindoro Pine	Pinus merkusii Jungh. & Vriese	Pinaceae	\N	Vulnerable	Indigenous	687
\N	Cyrtochloa puser (Gamble) S.Dransf	Poaceae	\N	Vulnerable	Endemic	688
\N	Hedyotis capitellata Wall. ex G.Don	Rubiaceae	\N	Vulnerable	Indigenous	689
Palawan Bíkal	Dinochloa palawanensis S.Dransf	Poaceae	\N	Vulnerable	Endemic	690
\N	Ischaemum glaucescens Merr.	Poaceae	\N	Vulnerable	Endemic	691
Igem-Pugot	Podocarpus lophatus de Laub.	Podocarpaceae	\N	Vulnerable	Endemic	692
Dilang-Butiki	Podocarpus polystachyus R.Br. ex Endl.	Podocarpaceae	\N	Vulnerable	Indigenous	693
Malakauayan	Podocarpus rumphii Blume	Podocarpaceae	\N	Vulnerable	Indigenous	694
\N	Securidaca atroviolacea Elmer	Polygalaceae	\N	Vulnerable	Endemic	695
Libagod	Aglaomorpha acuminata (Willd.) Hovenkamp	Polypodiaceae	\N	Vulnerable	Indigenous	696
\N	Aglaomorpha cornucopia (Copel.) Roos	Polypodiaceae	\N	Vulnerable	Endemic	697
\N	Aglaomorpha meyeniana Schott	Polypodiaceae	\N	Vulnerable	Endemic	698
\N	Aglaomorpha splendens (Hook. & Bauer) Copel	Polypodiaceae	\N	Vulnerable	Endemic	699
Saraukong	Aglaomorpha heraclea (Kunze) Copel.	Polypodiaceae	\N	Vulnerable	Indigenous	700
\N	Aglaomorpha pilosa (J.Sm. ex Kunze) Copel.	Polypodiaceae	\N	Vulnerable	Indigenous	701
\N	Microsorum sarawakense (Baker) Holttum	Polypodiaceae	\N	Vulnerable	Indigenous	702
Turko	Pyrrosia splendens (Presl) Ching	Polypodiaceae	\N	Vulnerable	Endemic	703
Cacam-Cam	Selliguea sagitta (Christ) Fraser-Jenk.	Polypodiaceae	\N	Vulnerable	Endemic	704
\N	Xiphopterella nudicarpa (P.M.Zamora & Co) Parris	Polypodiaceae	\N	Vulnerable	Indigenous	705
Samadódai	Ardisia iwahigensis Elmer	Primulaceae	\N	Vulnerable	Endemic	706
Roman Tagpo	Ardisia romanii Elmer	Primulaceae	\N	Vulnerable	Endemic	707
Tagpo	Ardisia squamulosa C Presl	Primulaceae	\N	Vulnerable	Endemic	708
Tágpong-Kapalan	Ardisia taytayensis Merr.	Primulaceae	\N	Vulnerable	Endemic	709
\N	Psilotum nudum (L.) Griseb.	Psilotaceae	\N	Vulnerable	Indigenous	710
\N	Adiantum cupreum Copel.	Pteridaceae	\N	Vulnerable	Endemic	711
\N	Adiantum monosorum Baker	Pteridaceae	\N	Vulnerable	Indigenous	712
\N	Adiantum stenochlamys Baker	Pteridaceae	\N	Vulnerable	Indigenous	713
\N	Pteris brevis Copel.	Pteridaceae	\N	Vulnerable	Endemic	714
\N	Pteris dataensis Copel.	Pteridaceae	\N	Vulnerable	Endemic	715
\N	Pteris macgregorii Copel.	Pteridaceae	\N	Vulnerable	Endemic	716
\N	Pteris micracantha Copel.	Pteridaceae	\N	Vulnerable	Endemic	717
\N	Pteris mucronulata Copel.	Pteridaceae	\N	Vulnerable	Endemic	718
\N	Pteris ramosii Copel.	Pteridaceae	\N	Vulnerable	Endemic	719
\N	Pteris squamipes Copel.	Pteridaceae	\N	Vulnerable	Endemic	720
\N	Pteris taenitis Copel.	Pteridaceae	\N	Vulnerable	Indigenous	721
\N	Taenitis cordata (Gaudich.) Holttum	Pteridaceae	\N	Vulnerable	Indigenous	722
Malabóo	Rafflesia lagascae Blanco	Rafflesiaceae	\N	Vulnerable	Endemic	723
\N	Rafflesia leonardi Barcelona & Pelser	Rafflesiaceae	\N	Vulnerable	Endemic	724
\N	Rafflesia lobata Galang & Madulid	Rafflesiaceae	\N	Vulnerable	Endemic	725
\N	Rhachidosorus stramineus (Copel.) Ching	Rhachidosoraceae	\N	Vulnerable	Indigenous	726
\N	Ventilago palawanensis Elmer	Rhamnaceae	\N	Vulnerable	Endemic	727
\N	Ziziphus palawanensis Elmer	Rhamnaceae	\N	Vulnerable	Endemic	728
Gúpit	Prunus pulgarensis (Elmer) Kalkm.	Rosaceae	\N	Vulnerable	Endemic	729
Bakad Pula	Prunus rubiginosa (Elmer) Kalkm.	Rosaceae	\N	Vulnerable	Endemic	730
Kanumog	Prunus subglabra (Merr.) Kalkm.	Rosaceae	\N	Vulnerable	Endemic	731
Lagong-Liitan	Prunus grisea (Blume) Kalkm.	Rosaceae	\N	Vulnerable	Indigenous	732
\N	Antirhea livida Elmer	Rubiaceae	\N	Vulnerable	Endemic	733
\N	Antirhea ternata Chaw	Rubiaceae	\N	Vulnerable	Endemic	734
\N	Exallage perhispida (Elmer) Bremek.	Rubiaceae	\N	Vulnerable	Endemic	735
\N	Gardenia ornata K.M.Wong	Rubiaceae	\N	Vulnerable	Endemic	736
\N	Gardenia vulcanica K.M.Wong	Rubiaceae	\N	Vulnerable	Endemic	737
\N	Hydnophytum angustifolium Merr.	Rubiaceae	\N	Vulnerable	Endemic	738
\N	Hydnophytum brachycladum Merr.	Rubiaceae	\N	Vulnerable	Endemic	739
\N	Hydnophytum intermedium Elmer	Rubiaceae	\N	Vulnerable	Endemic	740
\N	Hydnophytum membranaceum Merr.	Rubiaceae	\N	Vulnerable	Endemic	741
\N	Hydnophytum mindanaense Elmer	Rubiaceae	\N	Vulnerable	Endemic	742
\N	Hydnophytum mindorense Merr.	Rubiaceae	\N	Vulnerable	Endemic	743
\N	Hydnophytum nitidum Merr.	Rubiaceae	\N	Vulnerable	Endemic	744
Katudai	Mussaenda acuminatissima Merr.	Rubiaceae	\N	Vulnerable	Endemic	745
Bungag	Mussaenda attenuifolia Elmer	Rubiaceae	\N	Vulnerable	Endemic	746
\N	Mussaenda chlorantha Merr.	Rubiaceae	\N	Vulnerable	Endemic	747
Sigidago	Mussaenda setosa Merr.	Rubiaceae	\N	Vulnerable	Endemic	748
\N	Mussaenda grandifolia Elmer	Rubiaceae	\N	Vulnerable	Endemic	749
\N	Mussaenda lanata C.B.Rob	Rubiaceae	\N	Vulnerable	Endemic	750
Agboi	Mussaenda magallanensis Elmer	Rubiaceae	\N	Vulnerable	Endemic	751
\N	Mussaenda milleri Elmer	Rubiaceae	\N	Vulnerable	Endemic	752
Buyan	Mussaenda nervosa Elmer	Rubiaceae	\N	Vulnerable	Endemic	753
Buai	Mussaenda scandens Elmer	Rubiaceae	\N	Vulnerable	Endemic	754
Ananayop	Mussaenda vidalii Elmer	Rubiaceae	\N	Vulnerable	Endemic	755
\N	Myrmephytum beccarii Elmer	Rubiaceae	\N	Vulnerable	Endemic	756
Malagusókan	Pavetta phanerophlebia Merr	Rubiaceae	\N	Vulnerable	Endemic	757
Gusókan-Kaláuang	Pavetta subferruginea Merr	Rubiaceae	\N	Vulnerable	Endemic	758
\N	Psychotria balabacensis Merr.	Rubiaceae	\N	Vulnerable	Endemic	759
\N	Psychotria iwahigensis Elmer	Rubiaceae	\N	Vulnerable	Endemic	760
Gumugmug	Psychotria pyramidata Elmer	Rubiaceae	\N	Vulnerable	Endemic	761
Bunkól-Kaláuang	Timonius ferrugineus Merr	Rubiaceae	\N	Vulnerable	Endemic	762
Bunkól	Timonius palawanensis Elmer	Rubiaceae	\N	Vulnerable	Endemic	763
\N	Urophyllum elliptifolium Merr.	Rubiaceae	\N	Vulnerable	Endemic	764
Tarungatau	Melicope lunu-ankenda (Gaertn.) T.G.Hartley	Rutaceae	\N	Vulnerable	Indigenous	765
Pulgar Kámal	Melicope pulgarensis (Elmer) T.G.Hartley	Rutaceae	\N	Vulnerable	Endemic	766
Agsum	Exocarpos longifolius (L.) Endl.	Santalaceae	\N	Vulnerable	Indigenous	767
Mamoko	Glenniea philippinensis (Radlk.) Leenh.	Sapindaceae	\N	Vulnerable	Indigenous	768
Palawan Sarakag	Glenniea thorelii (Pierre) Leenh.	Sapindaceae	\N	Vulnerable	Indigenous	769
Alahan-Puti	Guioa discolor Radlk.	Sapindaceae	\N	Vulnerable	Endemic	770
Ulas	Guioa myriadenia Radlk.	Sapindaceae	\N	Vulnerable	Endemic	771
Uyos	Guioa truncata Radlk.	Sapindaceae	\N	Vulnerable	Endemic	772
Panungaian	Nephelium cuspidatum Blume	Sapindaceae	\N	Vulnerable	Indigenous	774
Kapulasan	Nephelium ramboutan-ake (Labill.) Leenh.	Sapindaceae	\N	Vulnerable	Indigenous	775
Alálud	Pleioluma foxworthyi (Elmer) Swenson	Sapotaceae	\N	Vulnerable	Endemic	779
\N	Selaginella atimonanensis BC Tan & Jermy	Selaginellaceae	\N	Vulnerable	Endemic	781
Fernando Mabunót	Gomphandra fernandoi Schori & Utteridge	Stemonuraceae	\N	Vulnerable	Endemic	782
Amugauen	Taxus sumatrana (Miq.) de Laub.	Taxaceae	\N	Vulnerable	Indigenous	783
\N	Aenigmopteris mindanaensis Holttum	Tectariaceae	\N	Vulnerable	Endemic	784
Haikan	Camellia lanceolata (Blume) Seem.	Theaceae	\N	Vulnerable	Indigenous	785
\N	Schima wallichii Choisy	Theaceae	\N	Vulnerable	Endemic	786
\N	Chingia pricei Holttum	Thelypteridaceae	\N	Vulnerable	Endemic	787
\N	Coryphopteris squamipes (Copel.) Holttum	Thelypteridaceae	\N	Vulnerable	Endemic	788
\N	Cyclogramma auriculata (J.Sm.) Ching.	Thelypteridaceae	\N	Vulnerable	Indigenous	789
\N	Cyclosorus paucipaleatus (Holttum) Mazumdar & Mukhop.	Thelypteridaceae	\N	Vulnerable	Endemic	790
\N	Nannothelypteris aoristisora (Harr.) Holttum	Thelypteridaceae	\N	Vulnerable	Endemic	791
\N	Nannothelypteris camarinensis Holttum	Thelypteridaceae	\N	Vulnerable	Endemic	792
\N	Nannothelypteris inaequilobata Holttum	Thelypteridaceae	\N	Vulnerable	Endemic	793
\N	Nannothelypteris nervosa (Fee) Holttum	Thelypteridaceae	\N	Vulnerable	Endemic	794
\N	Nannothelypteris philippina (C Presl) Holttum	Thelypteridaceae	\N	Vulnerable	Endemic	795
\N	Pronephrium bulusanicum (Holttum) Holttum	Thelypteridaceae	\N	Vulnerable	Endemic	796
\N	Pronephrium hosei (Baker) Holttum	Thelypteridaceae	\N	Vulnerable	Endemic	797
\N	Pronephrium solsonicum Holttum	Thelypteridaceae	\N	Vulnerable	Endemic	798
\N	Sphaerostephanos hernaezii Holttum	Thelypteridaceae	\N	Vulnerable	Endemic	799
\N	Sphaerostephanos angustifolius (C.Presl) Holttum	Thelypteridaceae	\N	Vulnerable	Indigenous	800
Mangód	Aquilaria apiculata Merr.	Thymelaeaceae	\N	Vulnerable	Endemic	801
Binúkat	Aquilaria brachyantha (Merr.) Hallier f	Thymelaeaceae	\N	Vulnerable	Endemic	802
Agodódan	Aquilaria citrinaecarpa (Elmer) Hallier f	Thymelaeaceae	\N	Vulnerable	Endemic	803
Bútlong-Liítan	Aquilaria parvifolia (Quisumb.) Ding Hou	Thymelaeaceae	\N	Vulnerable	Endemic	804
Makólan	Aquilaria urdanetensis (Elmer) Hallier f	Thymelaeaceae	\N	Vulnerable	Endemic	805
Butlo	Aquilaria cumingiana (Decne.) Ridley	Thymelaeaceae	\N	Vulnerable	Indigenous	806
Palisan	Aquilaria filaria (Oken) Merr.	Thymelaeaceae	\N	Vulnerable	Indigenous	807
\N	Elatostema palawanense C.B.Rob	Urticaceae	\N	Vulnerable	Endemic	808
\N	Alpinia elegans (C.Presl) K.Schum	Zingiberaceae	\N	Vulnerable	Endemic	809
Langkawás	Alpinia foxworthyi Ridl	Zingiberaceae	\N	Vulnerable	Endemic	810
Parapat	Alpinia paradoxa (Ridl.) Merr.	Zingiberaceae	\N	Vulnerable	Endemic	811
\N	Amomum palawanense Elmer	Zingiberaceae	\N	Vulnerable	Endemic	812
\N	Kaempferia philippinensis Merr	Zingiberaceae	\N	Vulnerable	Endemic	813
Banai	Leptosolena haenkei C Presl	Zingiberaceae	\N	Vulnerable	Endemic	814
\N	Hypoestes merrillii C.B.Clarke ex Elmer	Acanthaceae	\N	Other Threatened Species	Endemic	815
\N	Hypoestes palawanensis C.B.Clarke	Acanthaceae	\N	Other Threatened Species	Endemic	816
\N	Sphaerostephanos spenceri (Christ) Holttum	Thelypteridaceae	\N	Other Threatened Species	Endemic	817
Tiagang	Lepidagathis amaranthoides Elmer	Acanthaceae	\N	Other Threatened Species	Endemic	818
\N	Artabotrys vidaliana Elmer	Annonaceae	\N	Other Threatened Species	Endemic	820
Lanutan	Mitrephora lanotan (Blanco) Merr.	Annonaceae	\N	Other Threatened Species	Endemic	821
Amunat	Orophea cumingiana S.Vidal	Annonaceae	\N	Other Threatened Species	Indigenous	822
\N	Alyxia linearis Markgr	Apocynaceae	\N	Other Threatened Species	Endemic	823
Elmer Pasnit	Kibatalia elmeri Woodson	Apocynaceae	\N	Other Threatened Species	Endemic	824
Hanley Lanéte	Wrightia hanleyi Elmer	Apocynaceae	\N	Other Threatened Species	Endemic	825
\N	Cryptocoryne usteriana Engl.	Araceae	\N	Other Threatened Species	Endemic	826
\N	Rhaphidophora korthalsii Schott	Araceae	\N	Other Threatened Species	Endemic	827
Batbat	Arenga brevipes Becc.	Arecaceae	\N	Other Threatened Species	Indigenous	828
\N	Calamus daemonoropoides Fernando	Arecaceae	\N	Other Threatened Species	Endemic	829
Palásan	Calamus merrillii Becc.	Arecaceae	\N	Other Threatened Species	Endemic	830
Ditaán	Calamus mollis Blanco	Arecaceae	\N	Other Threatened Species	Endemic	831
\N	Calamus erinaceus (Becc.) Becc.	Arecaceae	\N	Other Threatened Species	Indigenous	832
Labsikan	Calamus longipes Griff.	Arecaceae	\N	Other Threatened Species	Indigenous	833
Voyavoi	Phoenix loureiroi Kunth	Arecaceae	\N	Other Threatened Species	Indigenous	834
Anahau	Saribus rotundifolius (Lam.) Blume	Arecaceae	\N	Other Threatened Species	Indigenous	835
\N	Diplazium sibuyanense (Copel.) Alderw.	Athyriaceae	\N	Other Threatened Species	Endemic	836
\N	Diplazium calliphyllum (Copel.) M.G.Price	Athyriaceae	\N	Other Threatened Species	Indigenous	837
\N	Diplazium maximum (D.Don) C.Chr.	Athyriaceae	\N	Other Threatened Species	Indigenous	838
\N	Diplazium vestitum C.Presl	Athyriaceae	\N	Other Threatened Species	Indigenous	839
\N	Begonia blancii M.Hughes & C.-I.Peng	Begoniaceae	\N	Other Threatened Species	Endemic	840
\N	Begonia lagunensis Elmer	Begoniaceae	\N	Other Threatened Species	Endemic	841
Lunai	Dacryodes rostrata (Blume) H.J.Lam	Burseraceae	\N	Other Threatened Species	Indigenous	844
Mountain Agoho	Gymnostoma rumphianum (Jungh. ex Vriese) L.A.S.Johnson	Casuarinaceae	\N	Other Threatened Species	Indigenous	845
\N	Connarus culionensis Merr.	Connaraceae	\N	Other Threatened Species	Indigenous	846
Malatapai	Alangium longiflorum Merr.	Cornaceae	\N	Other Threatened Species	Indigenous	847
\N	Davallia denticulata (Burm.f.) Mett. ex Kuhn	Davalliaceae	\N	Other Threatened Species	Indigenous	848
\N	Davallia embolostegia Copel.	Davalliaceae	\N	Other Threatened Species	Indigenous	849
\N	Davallia lorrainii Hance	Davalliaceae	\N	Other Threatened Species	Indigenous	850
\N	Davallia solida (G.Forst.) Sw.	Davalliaceae	\N	Other Threatened Species	Indigenous	851
Paláli	Dillenia marsupialis Hoogland	Dilleniaceae	\N	Other Threatened Species	Endemic	852
Katmon-Kalabau	Dillenia reifferscheidia Fern.-Villar	Dilleniaceae	\N	Other Threatened Species	Endemic	853
\N	Stenolepia tristis (Blume) Alderw.	Dryopteridaceae	\N	Other Threatened Species	Indigenous	854
Ánang-Apógan	Diospyros calcicola Merr.	Ebenaceae	\N	Other Threatened Species	Endemic	855
\N	Diospyros transita (Bakh.) Kosterm	Ebenaceae	\N	Other Threatened Species	Endemic	858
Tandikan	Diospyros wrayi King & Gamble	Ebenaceae	\N	Other Threatened Species	Indigenous	859
Dinagat Konakan	Elaeocarpus dinagatensis Merr.	Elaeocarpaceae	\N	Other Threatened Species	Endemic	860
Nabol	Elaeocarpus gigantifolius Elmer	Elaeocarpaceae	\N	Other Threatened Species	Endemic	861
\N	Polyosma pulgarensis Elmer	Escalloniaceae	\N	Other Threatened Species	Endemic	862
Kulis-Daga	Dimorphocalyx denticulatus Merr.	Euphorbiaceae	\N	Other Threatened Species	Indigenous	863
Amublit	Macaranga congestiflora Merr.	Euphorbiaceae	\N	Other Threatened Species	Endemic	864
Tanglin	Adenanthera intermedia Merr.	Fabaceae	\N	Other Threatened Species	Endemic	865
Dalidigan	Entada parvifolia Merr.	Fabaceae	\N	Other Threatened Species	Endemic	866
Gugo	Entada phaseoloides (L.) Merr.	Fabaceae	\N	Other Threatened Species	Indigenous	867
\N	Entada rheedii Sprengel	Fabaceae	\N	Other Threatened Species	Indigenous	868
Baloktot	Luzonia purpurea Elmer	Fabaceae	\N	Other Threatened Species	Endemic	869
Balók	Millettia merrillii Perkins	Fabaceae	\N	Other Threatened Species	Endemic	870
Butad	Parkia speciosa Hassk.	Fabaceae	\N	Other Threatened Species	Indigenous	871
Kilog	Lithocarpus luzoniensis (Merr.) Rehd.	Fagaceae	\N	Other Threatened Species	Endemic	872
Mangasiriki	Lithocarpus ovalis (Blanco) Rehd.	Fagaceae	\N	Other Threatened Species	Endemic	873
Pungo-Pungo	Quercus merrillii Seem.	Fagaceae	\N	Other Threatened Species	Indigenous	874
\N	Quercus subsericea A.Camus	Fagaceae	\N	Other Threatened Species	Indigenous	875
\N	Monophyllaea longipes Kraenzl.	Gesneriaceae	\N	Other Threatened Species	Endemic	876
Sabongaiahon	Monophyllaea merrilliana Kraenzl.	Gesneriaceae	\N	Other Threatened Species	Endemic	877
Koron-Koron	Hernandia ovigera L.	Hernandiaceae	\N	Other Threatened Species	Indigenous	878
Kalalapo-Bulan	Plectranthus apoensis (Elmer) H.Keng	Lamiaceae	\N	Other Threatened Species	Indigenous	879
Bungbungtid	Plectranthus merrillii H.Keng	Lamiaceae	\N	Other Threatened Species	Indigenous	880
Tambulian	Eusideroxylon zwageri Teijsm. & Binn.	Lauraceae	\N	Other Threatened Species	Indigenous	882
\N	Litsea varians (Blume) Boerl.	Lauraceae	\N	Other Threatened Species	Endemic	883
Patúgau	Neolitsea incana Elmer	Lauraceae	\N	Other Threatened Species	Endemic	884
Kulilísiau	Persea philippinensis (Merr.) Elmer	Lauraceae	\N	Other Threatened Species	Endemic	885
Pakong Kalabaw	Angiopteris palmiformis(Cav.) C. Chr.	Marattiaceae	\N	Other Threatened Species	Indigenous	886
Alauihau	Aglaia cumingiana Turcz.	Meliaceae	\N	Other Threatened Species	Endemic	887
\N	Sphaerostephanos stenodontus (Copel.) Holttum	Thelypteridaceae	\N	Other Threatened Species	Endemic	889
\N	Sphaerostephanos tephrophyllus (Copel.) Holttum	Thelypteridaceae	\N	Other Threatened Species	Endemic	890
Balubar	Aglaia rimosa (Blanco) Merr.	Meliaceae	\N	Other Threatened Species	Indigenous	891
Batukanag	Aglaia smithii Koord.	Meliaceae	\N	Other Threatened Species	Indigenous	892
Alamag	Aglaia aherniana Perkins	Meliaceae	\N	Other Threatened Species	Endemic	893
Manabiog	Aglaia costata Elmer ex Merr.	Meliaceae	\N	Other Threatened Species	Endemic	894
Kangko	Aphanamixis polystachya (Wall.) R.Parker	Meliaceae	\N	Other Threatened Species	Indigenous	895
Paluahan, Kayatau	Dysoxylum oppositifolium F.Muell.	Meliaceae	\N	Other Threatened Species	Indigenous	896
Ambal	Pycnarrhena manillensis S.Vidal	Menispermaceae	\N	Other Threatened Species	Endemic	897
Kalulot	Artocarpus rubrovenius Warb.	Moraceae	\N	Other Threatened Species	Endemic	898
Duhao	Knema alvarezii Merr.	Myristicaceae	\N	Other Threatened Species	Endemic	899
Libago	Knema stenocarpa Warb.	Myristicaceae	\N	Other Threatened Species	Endemic	900
Basilan Duguan	Myristica basilanica de Wilde	Myristicaceae	\N	Other Threatened Species	Endemic	901
\N	Myristica frugifera de Wilde	Myristicaceae	\N	Other Threatened Species	Endemic	902
\N	Myristica longipetiolata de Wilde	Myristicaceae	\N	Other Threatened Species	Endemic	903
\N	Myristica pilosigemma de Wilde	Myristicaceae	\N	Other Threatened Species	Endemic	905
Tigang-Liitan	Kania microphylla (Quisumb. & Merr.) Peter G Wilson	Myrtaceae	\N	Other Threatened Species	Endemic	906
Sambulanan	Kania urdanetensis (Elmer) Peter G Wilson	Myrtaceae	\N	Other Threatened Species	Endemic	907
Magadhan	Metrosideros halconensis (Merr.) Dawson	Myrtaceae	\N	Other Threatened Species	Endemic	908
Amtuk	Syzygium cagayanense (Merr.) Merr.	Myrtaceae	\N	Other Threatened Species	Endemic	909
Capoas Lamuto	Syzygium capoasense (Merr.) Merr.	Myrtaceae	\N	Other Threatened Species	Endemic	910
Lakangan	Syzygium ciliato-setosum (Merr.) Merr.	Myrtaceae	\N	Other Threatened Species	Endemic	911
Salakadan	Syzygium densinervium (Merr.) Merr.	Myrtaceae	\N	Other Threatened Species	Endemic	912
Tuál	Syzygium longissimum (Merr.) Merr.	Myrtaceae	\N	Other Threatened Species	Endemic	913
Kalógkog-Dágat	Syzygium subrotundifolium (C Robinson) Merr.	Myrtaceae	\N	Other Threatened Species	Endemic	914
Tamo	Syzygium confertum (Korth.) Merr. & L.M.Perry	Myrtaceae	\N	Other Threatened Species	Indigenous	915
Lauig-Lauigan	Syzygium panduriforme (Elmer) Merr.	Myrtaceae	\N	Other Threatened Species	Indigenous	916
Tígang-Habá	Tristaniopsis oblongifolia (Merr.) Peter G. Wilson & Waterhouse	Myrtaceae	\N	Other Threatened Species	Endemic	917
\N	Osmunda banksiifolia (C.Presl) Kuhn	Osmundaceae	\N	Other Threatened Species	Indigenous	918
Pandan	Benstonea affinis (Kurz) Callm. & Buerki	Pandanaceae	\N	Other Threatened Species	Indigenous	919
Olango	Pandanus basilocularis Martelli	Pandanaceae	\N	Other Threatened Species	Endemic	920
\N	Pentaphragma grandiflorum Kurz	Pentaphragmataceae	\N	Other Threatened Species	Indigenous	921
Anislag	Flueggea flexuosa Müll.Arg.	Phyllanthaceae	\N	Other Threatened Species	Indigenous	922
\N	Piper caninum Blume	Piperaceae	\N	Other Threatened Species	Indigenous	923
\N	Piper retrofractum Vahl	Piperaceae	\N	Other Threatened Species	Indigenous	924
Albón	Pittosporum ramosii Merr.	Pittosporaceae	\N	Other Threatened Species	Endemic	925
Abkel	Pittosporum resiniferum Hemsl.	Pittosporaceae	\N	Other Threatened Species	Indigenous	926
Bikal	Dinochloa acutiflora (Munro) S.Dransf.	Poaceae	\N	Other Threatened Species	Indigenous	927
Igem	Dacrycarpus imbricatus (Blume) de Laub.	Podocarpaceae	\N	Other Threatened Species	Indigenous	928
Malasuklai	Dacrydium pectinatum de Laub.	Podocarpaceae	\N	Other Threatened Species	Indigenous	929
Malaalmaciga	Nageia wallichiana (C.Presl) Kuntze	Podocarpaceae	\N	Other Threatened Species	Indigenous	930
\N	Arthromeris mairei (Brause) Ching	Polypodiaceae	\N	Other Threatened Species	Indigenous	931
Ginárai	Discocalyx palawanensis Elmer ex Merr.	Primulaceae	\N	Other Threatened Species	Endemic	932
Gakákan	Drypetes falcata (Merr.) Pax & K.Hoffm.	Putranjivaceae	\N	Other Threatened Species	Endemic	933
Tombong-Uak	Drypetes rhakodiskos (Hassk.) Airy Shaw	Putranjivaceae	\N	Other Threatened Species	Indigenous	934
Lumuluas	Ziziphus hutchinsonii Merr.	Rhamnaceae	\N	Other Threatened Species	Endemic	935
Balakat	Ziziphus talanai (Blanco) Merr.	Rhamnaceae	\N	Other Threatened Species	Endemic	936
Bakauan-Gubat	Carallia brachiata (Lour.) Merr.	Rhizophoraceae	\N	Other Threatened Species	Indigenous	937
Kuyaob	Rosa luciae Franch. & Rochebr. ex Crépin	Rosaceae	\N	Other Threatened Species	Indigenous	938
Pauikan	Rosa transmorrisonensis Hayata	Rosaceae	\N	Other Threatened Species	Indigenous	939
Tukong	Rubus heterosepalus Merr.	Rosaceae	\N	Other Threatened Species	Endemic	940
Pugaru	Hydnophytum leytense Merr.	Rubiaceae	\N	Other Threatened Species	Endemic	941
\N	Hydnophytum philippinense Becc.	Rubiaceae	\N	Other Threatened Species	Endemic	942
Malabúyon	Mussaenda palawanensis Merr.	Rubiaceae	\N	Other Threatened Species	Endemic	943
Kalomata	Clausena brevistyla Oliv.	Rutaceae	\N	Other Threatened Species	Indigenous	944
Dudua	Hydnocarpus alcalae C DC	Salicaceae	\N	Other Threatened Species	Endemic	945
Mansalay	Xylosma palawanensis DM Mendoza	Salicaceae	\N	Other Threatened Species	Endemic	946
Kaninging	Guioa bicolor Merr.	Sapindaceae	\N	Other Threatened Species	Endemic	947
Bataan Tagátoi	Palaquium bataanense Merr.	Sapotaceae	\N	Other Threatened Species	Endemic	948
\N	Tectaria adenophora Copel.	Tectariaceae	\N	Other Threatened Species	Endemic	949
\N	Tectaria tabonensis M.G.Price	Tectariaceae	\N	Other Threatened Species	Endemic	950
\N	Sphaerostephanos cartilagidens P Zamora & Co	Thelypteridaceae	\N	Other Threatened Species	Endemic	951
\N	Sphaerostephanos dichrotrichoides (Alderw.) Holttum	Thelypteridaceae	\N	Other Threatened Species	Endemic	952
\N	Sphaerostephanos irayensis (Copel.) Holttum	Thelypteridaceae	\N	Other Threatened Species	Endemic	953
\N	Sphaerostephanos williamsii (Copel.) Holttum	Thelypteridaceae	\N	Other Threatened Species	Endemic	954
Palupo	Wikstroemia retusa A.Gray	Thymelaeaceae	\N	Other Threatened Species	Indigenous	955
Lapnai	Astrothalamus reticulatus (Wedd.) C.B.Rob.	Urticaceae	\N	Other Threatened Species	Indigenous	956
Agbab	Vanoverberghia sepulchrei Merr.	Zingiberaceae	\N	Other Threatened Species	Endemic	957
\N	Calophyllum laticostatum P.F.Stevens	Calophyllaceae	\N	Vulnerable	Indigenous	959
Coral Plant	Balanophora coralliformis Pelser, Tandang & Barcelona	Balanophoraceae	\N	Critically Endangered	Endemic	960
\N	Paphiopedilum philippinense (Rchb.f.) Stein	Orchidaceae	\N	Critically Endangered	Endemic	961
\N	Rafflesia mixta Barcelona, Manting, Arbolonio et al.	Rafflesiaceae	\N	Critically Endangered	Endemic	962
\N	Goniothalamus palawanensis C.C.Tang & R.M.K.Saunders	Annonaceae	\N	Endangered	Endemic	963
\N	Bulbophyllum facetum Garay, Hamer & Siegerist	Orchidaceae	\N	Endangered	Endemic	964
\N	Grammatophyllum martae Quisumb. ex Valmayor & D.Tiu	Orchidaceae	\N	Endangered	Endemic	965
\N	Renanthera philippinensis (Ames & Quisumb.) L.O.Williams	Orchidaceae	\N	Endangered	Endemic	966
\N	Pseuderanthemum minutiflorum (Elmer) Merr.	Acanthaceae	\N	Vulnerable	Endemic	967
\N	Codonoboea corrugata (Mendum) D.J.Middleton	Gesneriaceae	\N	Vulnerable	Endemic	968
\N	Lindsaea hamiguitanensis Karger & V.B.Amoroso	Lindsaeaceae	\N	Vulnerable	Endemic	969
\N	Phrynium minutiflorum Suksathan & Borchs.	Maranthaceae	\N	Vulnerable	Endemic	970
\N	Dimeria chloridiformis (Gaudich) K.Schum. & Lauterb.	Poaceae	\N	Vulnerable	Endemic	971
\N	Rhododendron jasminiflorum Hook.	Ericaceae	\N	Vulnerable	Endemic	972
\N	Phanera semibifida (Roxb.)	Fabaceae	\N	Vulnerable	Endemic	974
Ungang	Plectocomia elongata Mart. ex Blume	Arecaceae	\N	Other Threatened Species	Endemic	975
Rambutan; Usau	Nephelium lappaceum L. var. lappaceum.	Sapindaceae	\N	Vulnerable	Indigenous	976
Bulauan	Nephelium lappaceum L. var. pallens (Hiern) Leenh.	Sapindaceae	\N	Vulnerable	Indigenous	977
Pamitóyen	Calophyllum pentapetalum (Blanco) Merr var. pentapetalum	Calophyllaceae	\N	Vulnerable	Endemic	978
Bintaúgan	Calophyllum pentapetalum (Blanco) Merr var. pulgarense (Elmer) P.F.Stevens	Calophyllaceae	\N	Vulnerable	Endemic	979
\N	Vaccinium palawanense Merr. var. foxworthyi (H.F.Copel.) Sleum.	Ericaceae	\N	Vulnerable	Endemic	980
Iualus	Vaccinium palawanense Merr. var. palawanense	Ericaceae	\N	Vulnerable	Endemic	981
Antipolo	Artocarpus blancoi	Moraceae	yes	\N	\N	983
Magabuyo	Celtis luzonica	Cannabaceae	yes	\N	\N	984
Katmon bayani	Dillenia megalantha	Dilleniaceae	yes	\N	\N	985
Katmon	Dillenia philippinensis	Dilleniaceae	yes	\N	\N	986
Kamagong	Diospyros blancoi	Ebenaceae	yes	\N	\N	987
Malapanau	Dipterocarpus kerrii	Ebenaceae	yes	\N	\N	988
Hagakhak	Dipterocarpus validus	Dipterocarpaceae	yes	\N	\N	989
Lamio	Dracontomelon edule	Dipterocarpaceae	yes	\N	\N	990
Bagtikan	Parashorea malaanonan	Dipterocarpaceae	yes	\N	\N	991
Guijo	Shorea guiso	Dipterocarpaceae	yes	\N	\N	992
Kalunti	Shorea hopeifolia	Dipterocarpaceae	yes	\N	\N	993
Mindanao Narig	Vatica mindanensis	Dipterocarpaceae	yes	\N	\N	994
Mayapis	Vatica palosapis	Dipterocarpaceae	yes	\N	\N	995
Basilan Yakal	Hopea basilanica Foxw.	Dipterocarpaceae	yes	Critically Endangered	Endemic	37
Mindanao Narek	Hopea brachyptera (Foxw.) Sloot.	Dipterocarpaceae	yes	Critically Endangered	Endemic	38
Cagayan Narek	Hopea cagayanensis (Foxw.) Sloot.	Dipterocarpaceae	yes	Critically Endangered	Endemic	39
Dalindingan	Hopea foxworthyi Elmer	Dipterocarpaceae	yes	Critically Endangered	Endemic	40
Yakal-Kaliot	Hopea malibato Foxw.	Dipterocarpaceae	yes	Critically Endangered	Endemic	41
Yakal-Magasusu	Hopea mindanensis Foxw.	Dipterocarpaceae	yes	Critically Endangered	Endemic	42
Gisok-Gisok	Hopea philippinensis Dyer	Dipterocarpaceae	yes	Critically Endangered	Endemic	43
Quisumbing Gisok	Hopea quisumbingiana Gutierrez	Dipterocarpaceae	yes	Critically Endangered	Endemic	44
Samar Gisok	Hopea samarensis Gutierrez	Dipterocarpaceae	yes	Critically Endangered	Endemic	45
Yakal	Shorea astylosa Foxw.	Dipterocarpaceae	yes	Critically Endangered	Endemic	46
Yakal-Malibato	Shorea malibato Foxw.	Dipterocarpaceae	yes	Critically Endangered	Endemic	47
Kaladis Narig	Vatica elliptica Foxw.	Dipterocarpaceae	yes	Critically Endangered	Endemic	48
Thick-Leafed Narig	Vatica pachyphylla Merr.	Dipterocarpaceae	yes	Critically Endangered	Endemic	49
Malinoag	Diospyros brideliifolia Elmer	Ebenaceae	yes	Critically Endangered	Endemic	52
Itom-Itom	Diospyros longiciliata Merr.	Ebenaceae	yes	Critically Endangered	Endemic	53
Ponce Kamagong	Diospyros poncei Merr.	Ebenaceae	yes	Critically Endangered	Endemic	54
Kanining Peneras	Aglaia pyriformis Merr.	Meliaceae	yes	Critically Endangered	Endemic	72
Bago-Adlau	Xanthostemon philippinensis Merr.	Myrtaceae	yes	Critically Endangered	Endemic	75
Sierra Madre Mangkono	Xanthostemon fruticosus Peter G Wilson & Co	Myrtaceae	yes	Critically Endangered	Endemic	80
Mindanao Palosapis	Anisoptera costata Korth.	Dipterocarpaceae	yes	Endangered	Indigenous	257
Basilan Apitong	Dipterocarpus eurhynchus Miq.	Dipterocarpaceae	yes	Endangered	Indigenous	258
Manggachapui	Hopea acuminata Merr.	Dipterocarpaceae	yes	Endangered	Endemic	259
Tiaong	Shorea ovata Dyer ex Brandis	Dipterocarpaceae	yes	Endangered	Indigenous	260
Narig Laut	Vatica maritima Slooten	Dipterocarpaceae	yes	Endangered	Indigenous	261
Tindalo	Afzelia rhomboidea (Blanco) S.Vidal	Fabaceae	yes	Endangered	Indigenous	268
Manggis	Koompassia excelsa (Becc.) Taub.	Fabaceae	yes	Endangered	Indigenous	269
Supa	Sindora supa Merr.	Fabaceae	yes	Endangered	Endemic	270
Kamatog	Sympetalandra densiflora (Elmer) Steenis	Fabaceae	yes	Endangered	Endemic	272
Bunglas, Philippine Teak	Tectona philippinensis Benth. & Hook.f.	Lamiaceae	yes	Endangered	Endemic	281
Molave	Vitex parviflora Juss.	Lamiaceae	yes	Endangered	Indigenous	282
Batikuling	Litsea leytensis Merr.	Lauraceae	yes	Endangered	Endemic	285
Mangkono	Xanthostemon verdugonianus Naves	Myrtaceae	yes	Endangered	Endemic	314
Igem-Dagat	Podocarpus costalis C.Presl	Podocarpaceae	yes	Endangered	Indigenous	376
Betis	Madhuca betis (Blanco) JT McBride	Sapotaceae	yes	Endangered	Endemic	402
Pianga	Madhuca obovatifolia (Merr.)	Sapotaceae	yes	Endangered	Endemic	406
Dao	Dracontomelon dao (Blanco) Merr. & Rolfe	Anacardiaceae	yes	Vulnerable	Indigenous	436
Pahutan	Mangifera altissima Blanco	Anacardiaceae	yes	Vulnerable	Indigenous	438
Almaciga	Agathis philippinensis Warb.	Araucariaceae	yes	Vulnerable	Indigenous	466
Malakatmon	Dillenia luzoniensis (S.Vidal) Merr. PJS	Dilleniaceae	yes	Vulnerable	Indigenous	529
Hairy-Leaf Apitong	Dipterocarpus alatus Roxb. ex G.Don.	Dipterocarpaceae	yes	Vulnerable	Indigenous	533
Apitong	Dipterocarpus grandiflorus (Blanco) Blanco	Dipterocarpaceae	yes	Vulnerable	Indigenous	535
Hasselt'S Panau	Dipterocarpus hasseltii Blume	Dipterocarpaceae	yes	Vulnerable	Indigenous	536
Broad-Leaf Apitong	Dipterocarpus kunstleri King.	Dipterocarpaceae	yes	Vulnerable	Indigenous	537
Yakal-Saplungan	Hopea plagata (Blanco) S.Vidal	Dipterocarpaceae	yes	Vulnerable	Indigenous	538
Almon	Shorea almon Foxw.	Dipterocarpaceae	yes	Vulnerable	Indigenous	540
White Lauan	Shorea contorta Vidal	Dipterocarpaceae	yes	Vulnerable	Endemic	542
Yakál-Yambán	Shorea falciferoides Foxw.	Dipterocarpaceae	yes	Vulnerable	Endemic	543
Red Lauan	Shorea negrosensis Foxw.	Dipterocarpaceae	yes	Vulnerable	Endemic	544
Tanguile	Shorea polysperma (Blanco) Merr.	Dipterocarpaceae	yes	Vulnerable	Endemic	545
Malayakal	Shorea seminis (Vriese) Slooten	Dipterocarpaceae	yes	Vulnerable	Indigenous	546
Aponan	Diospyros cauliflora Blume	Ebenaceae	yes	Vulnerable	Indigenous	549
Bantulinau	Diospyros ferrea (Willd.) Bakh.	Ebenaceae	yes	Vulnerable	Indigenous	551
Oi-Oi	Diospyros philippinensis A.DC.	Ebenaceae	yes	Vulnerable	Indigenous	552
Bolong-Eta	Diospyros pilosanthera Blanco	Ebenaceae	yes	Vulnerable	Indigenous	553
Anang	Diospyros pyrrhocarpa Miq.	Ebenaceae	yes	Vulnerable	Indigenous	554
Balakat-Gubat	Balakata luzonica (S.Vidal) Esser	Euphorbiaceae	yes	Vulnerable	Indigenous	565
Bagilumbáng	Reutealis trisperma (Blanco) Airy Shaw	Euphorbiaceae	yes	Vulnerable	Endemic	567
Narig	Vatica mangachapoi Blanco ssp. Mangachapoi	Dipterocarpaceae	yes	Vulnerable	Indigenous	568
Ipil	Intsia bijuga (Colebr.) Kuntze	Fabaceae	yes	Vulnerable	Indigenous	570
Batete	Kingiodendron alternifolium (Elmer) Merr. & Rolfe	Fabaceae	yes	Vulnerable	Indigenous	572
Banuyo	Wallaceodendron celebicum Koord.	Fabaceae	yes	Vulnerable	Indigenous	579
Smooth Narra	Pterocarpus indicus Willd. forma indicus	Fabaceae	yes	Vulnerable	Indigenous	604
Bagauak-Morado	Clerodendrum quadriloculare (Blanco) Merr.	Lamiaceae	yes	Vulnerable	Indigenous	613
Kalantas	Toona calantas Merr. & Rolfe	Meliaceae	yes	Vulnerable	Indigenous	635
Makaasim	Syzygium nitidum Benth.	Myrtaceae	yes	Vulnerable	Indigenous	640
Malabayabas	Tristaniopsis decorticata (Merr.) Peter G Wilson & Waterhouse	Myrtaceae	yes	Vulnerable	Endemic	641
Taba	Tristaniopsis littoralis (Merr.) Peter G Wilson & Waterhouse	Myrtaceae	yes	Vulnerable	Endemic	642
Malapiga	Xanthostemon speciosus Merr.	Myrtaceae	yes	Vulnerable	Endemic	645
Alupag	Litchi chinensis Sonn.	Sapindaceae	yes	Vulnerable	Indigenous	773
Red Nato, Nato	Palaquium luzoniense (Fern.-Villar) Vidal	Sapotaceae	yes	Vulnerable	Endemic	776
Pinulog	Palaquium mindanaense Merr.	Sapotaceae	yes	Vulnerable	Endemic	777
Malak-Malak	Palaquium philippense (Perr.) C Robinson	Sapotaceae	yes	Vulnerable	Endemic	778
Villamil Nato, White Nato	Pouteria villamilii (Merr.) Swenson	Sapotaceae	yes	Vulnerable	Endemic	780
Amugis	Koordersiodendron pinnatum (Blanco) Merr.	Anacardiaceae	yes	Other Threatened Species	Indigenous	819
Píling-Liítan	Canarium luzonicum (Blume) Miq.	Burseraceae	yes	Other Threatened Species	Endemic	842
Pili	Canarium ovatum Engl.	Burseraceae	yes	Other Threatened Species	Endemic	843
Malagaitmon	Diospyros curranii Merr.	Ebenaceae	yes	Other Threatened Species	Indigenous	856
Ata-Ata	Diospyros mindanaensis Merr.	Ebenaceae	yes	Other Threatened Species	Indigenous	857
Kalingag	Cinnamomum mercadoi Vidal	Lauraceae	yes	Other Threatened Species	Endemic	881
Malasaging	Aglaia edulis (Roxb.) Wall.	Meliaceae	yes	Other Threatened Species	Indigenous	888
Duguan	Myristica philippensis Lam.	Myristicaceae	yes	Other Threatened Species	Endemic	904
Mapilig	Xanthostemon bracteatus Merr.	Myrtaceae	yes	Critically Endangered	Endemic	958
Palawan Narig	Vatica mangachapoi Blanco ssp.obtusifolia (Elmer) Ashton	Dipterocarpaceae	yes	Endangered	Endemic	973
Prickly Narra	Pterocarpus indicus Willd. forma echinatus	Fabaceae	yes	Vulnerable	Indigenous	982
\.


--
-- Name: insert_to_ntapi_species_id_seq; Type: SEQUENCE SET; Schema: staging; Owner: postgres
--

SELECT pg_catalog.setval('staging.insert_to_ntapi_species_id_seq', 995, true);


--
-- Name: insert_to_ntapi_species insert_to_ntapi_species_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.insert_to_ntapi_species
    ADD CONSTRAINT insert_to_ntapi_species_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

