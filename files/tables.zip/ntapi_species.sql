--
-- PostgreSQL database dump
--

-- Dumped from database version 14.13 (Postgres.app)
-- Dumped by pg_dump version 16.4 (Postgres.app)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ntapi_species; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.ntapi_species (
    id integer NOT NULL,
    common_name character varying(150),
    species character varying(150),
    family character varying(100),
    ecological_classification character varying(50),
    conservation_status character varying(50),
    binhi_priority character varying(3)
);


ALTER TABLE staging.ntapi_species OWNER TO postgres;

--
-- Data for Name: ntapi_species; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.ntapi_species (id, common_name, species, family, ecological_classification, conservation_status, binhi_priority) FROM stdin;
1	Malapasnit	Kibatalia longifolia Merr.	Apocynaceae	Endemic	Critically Endangered	\N
2	\N	Amorphophallus palawanensis Bogner & Hett.	Araceae	Endemic	Critically Endangered	\N
3	\N	Amorphophallus natolii Hett., A.Wistuba, V.B.Amoroso, M.Medecilo & C.Claudel	Araceae	Endemic	Critically Endangered	\N
4	Takobtob	Areca parens Becc.	Arecaceae	Endemic	Critically Endangered	\N
5	Valit	Calamus batanensis (Becc.) Baja-Lapis	Arecaceae	Endemic	Critically Endangered	\N
6	\N	Calamus jenningsianus Becc.	Arecaceae	Endemic	Critically Endangered	\N
7	\N	Calamus vinosus Becc.	Arecaceae	Endemic	Critically Endangered	\N
8	Bagbag	Calamus affinis Becc.	Arecaceae	Endemic	Critically Endangered	\N
9	Rogman	Calamus oligolepis Becc.	Arecaceae	Endemic	Critically Endangered	\N
10	Sabilog	Calamus pannosus Becc.	Arecaceae	Endemic	Critically Endangered	\N
11	Yanisi	Heterospathe califrons Fernando	Arecaceae	Endemic	Critically Endangered	\N
12	Dransfield Sanakti	Heterospathe dransfieldii Fernando	Arecaceae	Endemic	Critically Endangered	\N
13	Malasanakti	Heterospathe scitula Fernando	Arecaceae	Endemic	Critically Endangered	\N
14	Bilis	Heterospathe sibuyanensis Becc.	Arecaceae	Endemic	Critically Endangered	\N
15	Tatlong Bilisan	Heterospathe trispatha Fernando	Arecaceae	Endemic	Critically Endangered	\N
16	Palawan Banga	Orania paraguanensis Becc., Webbia	Arecaceae	Indigenous	Critically Endangered	\N
17	Dapiau	Pinanga batanensis Becc.	Arecaceae	Endemic	Critically Endangered	\N
18	Bicol Abiki	Pinanga bicolana Fernando	Arecaceae	Endemic	Critically Endangered	\N
19	Samar Abiki	Pinanga samarana Becc.	Arecaceae	Endemic	Critically Endangered	\N
20	Abiking-Tigas	Pinanga sclerophylla Becc.	Arecaceae	Endemic	Critically Endangered	\N
21	Tibangan	Pinanga sibuyanensis Becc.	Arecaceae	Endemic	Critically Endangered	\N
22	Ungang	Plectocomia elmeri Becc.	Arecaceae	Endemic	Critically Endangered	\N
23	\N	Buxbaumia javanica Muell. Hal.	Buxbaumiaceae	Indigenous	Critically Endangered	\N
24	Paróngpong	Ceuthostoma palawanense L.A.S.Johnson	Casuarinaceae	Endemic	Critically Endangered	\N
25	\N	Ceuthostoma terminale L.A.S.Johnson	Casuarinaceae	Indigenous	Critically Endangered	\N
26	\N	Cyathea curranii Copel.	Cyatheaceae	Endemic	Critically Endangered	\N
27	\N	Cyathea latipinnula Copel.	Cyatheaceae	Endemic	Critically Endangered	\N
28	\N	Cyathea microchlamys Holttum	Cyatheaceae	Endemic	Critically Endangered	\N
29	\N	Cyathea obliqua Copel.	Cyatheaceae	Endemic	Critically Endangered	\N
30	\N	Cyathea sibuyanensis Copel.	Cyatheaceae	Endemic	Critically Endangered	\N
31	\N	Cycas aenigma K.D.Hill & A.Lindstr	Cycadaceae	Endemic	Critically Endangered	\N
32	Curran Pitogo	Cycas curranii (J Schust.) KD Hill	Cycadaceae	Endemic	Critically Endangered	\N
33	\N	Cycas sancti-lasallei Agoo & Madulid	Cycadaceae	Endemic	Critically Endangered	\N
34	\N	Cycas saxatilis KD. Hill & Lindstr.	Cycadaceae	Endemic	Critically Endangered	\N
35	\N	Cycas zambalensis Madulid & Agoo	Cycadaceae	Endemic	Critically Endangered	\N
36	\N	Dipteris lobbiana (Hook.) Moore, Ind. Fil.	Dipteridaceae	Indigenous	Critically Endangered	\N
50	\N	Ctenitis paleolata Copel.	Dryopteridaceae	Endemic	Critically Endangered	\N
51	\N	Dryopteris zhuweimingii Li Bing Zhang	Dryopteridaceae	Indigenous	Critically Endangered	\N
55	\N	Rhododendron acrophilum Merr. & Quisumb.	Ericaceae	Endemic	Critically Endangered	\N
56	\N	Rhododendron mendumiae Argent	Ericaceae	Endemic	Critically Endangered	\N
57	\N	Rhododendron reynosoi Argent	Ericaceae	Endemic	Critically Endangered	\N
58	Yew-Leaf Rhododendron	Rhododendron taxifolium Merr.	Ericaceae	Endemic	Critically Endangered	\N
59	\N	Cynometra cebuensis Seidenschwarz	Fabaceae	Endemic	Critically Endangered	\N
60	\N	Macgregorella indica (Broth) W.R. Buck	Fabroniaceae	Indigenous	Critically Endangered	\N
61	\N	Merrilliobryum fabronioides Broth.	Fabroniaceae	Endemic	Critically Endangered	\N
62	\N	Hypericum pulogense Merr.	Hypericaceae	Endemic	Critically Endangered	\N
63	\N	Isoetes philippinensis Merr. & Perry	Isoetaceae	Endemic	Critically Endangered	\N
64	Mendoza Kalíngag	Cinnamomum mendozae Kosterm	Lauraceae	Endemic	Critically Endangered	\N
65	Oro Kalingag	Cinnamomum oroi Quisumb.	Lauraceae	Endemic	Critically Endangered	\N
66	Amutmagiso	Tricyrtis imeldae Gut.	Liliaceae	Endemic	Critically Endangered	\N
67	\N	Thaumasianthes amplifolia (Merr.) Danser	Loranthaceae	Endemic	Critically Endangered	\N
68	Salindugok	Phlegmariurus whitfordii (Herter)	Lycopodiaceae	Endemic	Critically Endangered	\N
69	\N	Phanerosorus major Diels	Matoniaceae	Indigenous	Critically Endangered	\N
70	\N	Medinilla dallciana Fernando & Balete	Melastomataceae	Endemic	Critically Endangered	\N
71	Kapa-Kapa	Medinilla magnifica Lindl.	Melastomataceae	Endemic	Critically Endangered	\N
73	Ridsdale Tambalau	Knema ridsdaleana de Wilde	Myristicaceae	Endemic	Critically Endangered	\N
74	Ridsdale Duguan	Myristica colinridsdalei de Wilde	Myristicaceae	Endemic	Critically Endangered	\N
76	\N	Nepenthes abalata Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
77	\N	Nepenthes abgracilis Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
78	\N	Nepenthes alzapan Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
79	\N	Nepenthes argentii M Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
81	\N	Porotrichodendron mahahaicum (Muell.Hal.) M.Fleisch.	Lembophyllaceae	Endemic	Critically Endangered	\N
82	\N	Nepenthes armin Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
83	\N	Nepenthes attenboroughii A.S. Robinson, McPherson & Heinrich	Nepenthaceae	Endemic	Critically Endangered	\N
84	\N	Nepenthes barcelonae Tandang & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
85	\N	Nepenthes cid Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
86	\N	Nepenthes deaniana Macfarl	Nepenthaceae	Endemic	Critically Endangered	\N
87	\N	Nepenthes extincta Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
88	\N	Nepenthes kitanglad Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
89	\N	Nepenthes kurata Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
90	\N	Nepenthes leonardoi S.McPherson et al	Nepenthaceae	Endemic	Critically Endangered	\N
91	\N	Nepenthes leyte Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
92	\N	Nepenthes merrilliana Macfarl.	Nepenthaceae	Endemic	Critically Endangered	\N
93	\N	Nepenthes micramphora Heinrich, et.al.	Nepenthaceae	Endemic	Critically Endangered	\N
94	\N	Nepenthes mira Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
95	\N	Nepenthes negros Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
96	\N	Nepenthes palawanensis S.McPherson et al.	Nepenthaceae	Endemic	Critically Endangered	\N
97	\N	Nepenthes peltata Sh. Kurata	Nepenthaceae	Endemic	Critically Endangered	\N
98	\N	Nepenthes pulchra Gronem. et al	Nepenthaceae	Endemic	Critically Endangered	\N
99	\N	Nepenthes ramos Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
100	\N	Nepenthes robcantleyi Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
101	\N	Nepenthes samar Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
102	\N	Nepenthes sibuyanensis J Nerz	Nepenthaceae	Endemic	Critically Endangered	\N
103	\N	Nepenthes tboli Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
104	\N	Nepenthes zygon Jebb & Cheek	Nepenthaceae	Endemic	Critically Endangered	\N
105	Kayantol	Chionanthus clementis (Quisumb. & Merr.) Kiew	Oleaceae	Endemic	Critically Endangered	\N
106	Pamoplasin	Chionanthus remotinervius (Merr.) Kiew	Oleaceae	Endemic	Critically Endangered	\N
107	Palawan Olive	Olea palawanensis Kiew	Oleaceae	Endemic	Critically Endangered	\N
108	Tungkod-Langit	Helminthostachys zeylanica (L.) Hook	Ophioglossaceae	Indigenous	Critically Endangered	\N
109	\N	Amesiella monticola J Cootes & DP Banks	Orchidaceae	Endemic	Critically Endangered	\N
110	\N	Bulbophyllum cootesii M.A.Clem	Orchidaceae	Endemic	Critically Endangered	\N
111	\N	Ceratocentron fesselii Senghas	Orchidaceae	Endemic	Critically Endangered	\N
112	\N	Dendrobium schuetzei Rolfe	Orchidaceae	Endemic	Critically Endangered	\N
113	\N	Gastrochilus calceolaris (Buch.-Ham. ex Sm.) D.Don	Orchidaceae	Indigenous	Critically Endangered	\N
114	\N	Grammatophyllum speciosum Blume	Orchidaceae	Indigenous	Critically Endangered	\N
115	\N	Grammatophyllum ravanii D.Tiu	Orchidaceae	Endemic	Critically Endangered	\N
116	\N	Grammatophyllum walisii Rchb.f	Orchidaceae	Endemic	Critically Endangered	\N
117	\N	Mycaranthes leonardoi Ferreras & Suarez	Orchidaceae	Endemic	Critically Endangered	\N
118	\N	Paphiopedilum acmodontum MW Wood	Orchidaceae	Endemic	Critically Endangered	\N
119	\N	Paphiopedilum adductum Asher	Orchidaceae	Endemic	Critically Endangered	\N
120	\N	Paphiopedilum argus (Reichb.f.) Stein	Orchidaceae	Endemic	Critically Endangered	\N
121	\N	Paphiopedilum ciliolare (Reichb.f.) Stein	Orchidaceae	Endemic	Critically Endangered	\N
122	\N	Paphiopedilum fowliei Birk	Orchidaceae	Endemic	Critically Endangered	\N
123	\N	Paphiopedilum haynaldianum (Reichb.f.) Stein	Orchidaceae	Endemic	Critically Endangered	\N
124	\N	Paphiopedilum hennisianum (MW Wood) Fowlie	Orchidaceae	Endemic	Critically Endangered	\N
125	\N	Paphiopedilum randsii Fowlie	Orchidaceae	Endemic	Critically Endangered	\N
126	\N	Paphiopedilum urbanianum Fowlie	Orchidaceae	Endemic	Critically Endangered	\N
127	\N	Paphiopedilum usitanum O.Gruss & Roeth	Orchidaceae	Endemic	Critically Endangered	\N
128	\N	Paphiopedilum barbatum (Lindl.) Pfitzer	Orchidaceae	Indigenous	Critically Endangered	\N
129	\N	Paphiopedilum lowii (Lindl.) Stein,	Orchidaceae	Indigenous	Critically Endangered	\N
130	\N	Phalaenopsis micholitzii Rolfe	Orchidaceae	Endemic	Critically Endangered	\N
131	\N	Phragmorchis teretifolia LO Williams	Orchidaceae	Endemic	Critically Endangered	\N
132	\N	Renanthera caloptera (Rchb.f.) Kocyan & Schuit.	Orchidaceae	Indigenous	Critically Endangered	\N
133	\N	Vanda lamellata Lindl.	Orchidaceae	Endemic	Critically Endangered	\N
134	Waling-Waling	Vanda sanderiana (Reichb.f) Schltr.	Orchidaceae	Endemic	Critically Endangered	\N
135	Palawan Malakauayan	Podocarpus palawanensis de Laub. & Silba	Podocarpaceae	Endemic	Critically Endangered	\N
136	\N	Goniophlebium terrestre Copel.	Polypodiaceae	Endemic	Critically Endangered	\N
137	Staghorn Fern	Platycerium coronarium (König ex Müller) Desv.	Polypodiaceae	Indigenous	Critically Endangered	\N
138	Giant Staghorn Fern	Platycerium grande (Fee) Kunze	Polypodiaceae	Endemic	Critically Endangered	\N
139	\N	Podosorus angustatus Holttum	Polypodiaceae	Endemic	Critically Endangered	\N
140	\N	Pteris calocarpa (Copel.) MG Price	Pteridaceae	Endemic	Critically Endangered	\N
141	\N	Pteris pachysora (Copel.) MG Price	Pteridaceae	Endemic	Critically Endangered	\N
142	\N	Euptychium setigerum (Sull.) Broth.	Pterobryaceae	Indigenous	Critically Endangered	\N
143	\N	Rafflesia aurantia Barcelona, Co & Balete	Rafflesiaceae	Endemic	Critically Endangered	\N
144	Boo	Rafflesia schadenbergiana Goeppert ex Hieron.	Rafflesiaceae	Endemic	Critically Endangered	\N
145	\N	Rafflesia verrucosa Balete et al.	Rafflesiaceae	Endemic	Critically Endangered	\N
146	Baler Bakauan	Kandelia candel Druce	Rhizophoraceae	Indigenous	Critically Endangered	\N
147	\N	Antherostele callophylla Bremek.	Rubiaceae	Endemic	Critically Endangered	\N
148	\N	Antherostele luzoniensis (Merr.) Bremek.	Rubiaceae	Endemic	Critically Endangered	\N
149	\N	Antherostele samarensis Obico & Alejandro	Rubiaceae	Endemic	Critically Endangered	\N
150	Kalinigi	Atractocarpus obscurinervius (Merr.)	Rubiaceae	Endemic	Critically Endangered	\N
151	Palawan Palak	Badusa palawanensis Ridsd.	Rubiaceae	Endemic	Critically Endangered	\N
152	\N	Bikkia montoyae Mejillano et al.	Rubiaceae	Endemic	Critically Endangered	\N
153	\N	Bikkia philippinensis Valeton	Rubiaceae	Endemic	Critically Endangered	\N
154	Pangalimanan	Greeniopsis discolor Merr.	Rubiaceae	Endemic	Critically Endangered	\N
155	Buhon-Buhon	Greeniopsis euphlebia Merr.	Rubiaceae	Endemic	Critically Endangered	\N
156	Humagos	Greeniopsis megalantha Merr.	Rubiaceae	Endemic	Critically Endangered	\N
157	Paluay-Mabolo	Greeniopsis pubescens Merr.	Rubiaceae	Endemic	Critically Endangered	\N
158	\N	Psydrax puberula Arriola & Alejandro	Rubiaceae	Endemic	Critically Endangered	\N
159	Tango	Villaria acutifolia (Elmer) Merr.	Rubiaceae	Endemic	Critically Endangered	\N
160	Otto	Villaria fasciculiflora Quisumb. & Merr.	Rubiaceae	Endemic	Critically Endangered	\N
161	\N	Villaria leytensis Alejandro & Meve	Rubiaceae	Endemic	Critically Endangered	\N
162	\N	Villaria uniflora Arriola & Alejandro	Rubiaceae	Endemic	Critically Endangered	\N
163	Kabuyok	Swinglea glutinosa (Blanco) Merr.	Rutaceae	Endemic	Critically Endangered	\N
164	\N	Medinilla calcicola Merr.	Melastomataceae	Endemic	Endangered	\N
165	Kasau-Kasau	Gongrospermum philippinense Radlk.	Sapindaceae	Endemic	Critically Endangered	\N
166	Palawan Alahan	Guioa palawanica Welzen	Sapindaceae	Endemic	Critically Endangered	\N
167	Angset	Guioa parvifoliola Merr.	Sapindaceae	Endemic	Critically Endangered	\N
168	Alahan-Sinima	Guioa reticulata Radlk.	Sapindaceae	Endemic	Critically Endangered	\N
169	\N	Gomphandra bracteata Schori	Stemonuraceae	Endemic	Critically Endangered	\N
170	Conklin Mabunót	Gomphandra conklinii Schori	Stemonuraceae	Endemic	Critically Endangered	\N
171	Dinagat Mabunót	Gomphandra dinagatensis Schori	Stemonuraceae	Endemic	Critically Endangered	\N
172	Halcon Mabunót	Gomphandra halconensis Schori	Stemonuraceae	Endemic	Critically Endangered	\N
173	\N	Heterogonium wenzelii (Copel.) Holttum	Tectariaceae	Endemic	Critically Endangered	\N
174	\N	Chingia urens Holttum	Thelypteridaceae	Endemic	Critically Endangered	\N
175	\N	Coryphopteris borealis Holttum	Thelypteridaceae	Endemic	Critically Endangered	\N
176	Pahong-Liitan	Mangifera merrillii Mukherji	Anacardiaceae	Endemic	Endangered	\N
177	Huani	Mangifera odorata Griff., Notul.	Anacardiaceae	Indigenous	Endangered	\N
178	\N	Hoya alagensis Kloppenb.	Apocynaceae	Endemic	Endangered	\N
179	\N	Hoya angustisepala CM Burton	Apocynaceae	Endemic	Endangered	\N
180	\N	Hoya burtoniae Kloppenb.	Apocynaceae	Endemic	Endangered	\N
181	\N	Hoya crassicaulis (Elmer) Kloppenb.	Apocynaceae	Endemic	Endangered	\N
182	\N	Hoya curtisii King &Gamble	Apocynaceae	Indigenous	Endangered	\N
183	\N	Hoya diversifolia Blume Kloppenb.	Apocynaceae	Endemic	Endangered	\N
184	\N	Hoya estrellaensis T.Green & Kloppenb	Apocynaceae	Endemic	Endangered	\N
185	\N	Hoya gigantanganensis Kloppenb.	Apocynaceae	Endemic	Endangered	\N
186	\N	Hoya greenii Kloppenb.	Apocynaceae	Endemic	Endangered	\N
187	\N	Hoya halconensis Kloppenb.	Apocynaceae	Endemic	Endangered	\N
188	\N	Hoya heuschkeliana Kloppenb.	Apocynaceae	Endemic	Endangered	\N
189	\N	Hoya imperialis Lindl.	Apocynaceae	Indigenous	Endangered	\N
190	\N	Hoya panchoi Kloppenb.	Apocynaceae	Endemic	Endangered	\N
191	\N	Hoya pulgarensis Elmer	Apocynaceae	Endemic	Endangered	\N
192	\N	Hoya quinquenervia Warb.	Apocynaceae	Endemic	Endangered	\N
193	\N	Hoya quisumbingii Kloppenb.	Apocynaceae	Endemic	Endangered	\N
194	\N	Hoya rizaliana Kloppenb.	Apocynaceae	Endemic	Endangered	\N
195	\N	Hoya wayetii Kloppenb.	Apocynaceae	Endemic	Endangered	\N
196	Paslit-Mabolo	Kibatalia puberula Merr.	Apocynaceae	Endemic	Endangered	\N
197	Paslit-Kitid	Kibatalia stenopetala Merr.	Apocynaceae	Endemic	Endangered	\N
198	\N	Marsdenia purpurella Fernando & Rodda	Apocynaceae	Endemic	Endangered	\N
199	Sander'S Alocasia	Alocasia sanderiana W Bull.	Araceae	Endemic	Endangered	\N
200	Agama Galamay-Amo	Schefflera agamae Merr.	Araliaceae	Endemic	Endangered	\N
201	Makinging	Schefflera albido-bracteata Elmer	Araliaceae	Endemic	Endangered	\N
202	Curran Galamay-Amo	Schefflera curranii Merr.	Araliaceae	Endemic	Endangered	\N
203	Foxworthy Galamay-Amo	Schefflera foxworthyi Merr.	Araliaceae	Endemic	Endangered	\N
204	Palawan Galamay-Amo	Schefflera palawanensis Merr.	Araliaceae	Endemic	Endangered	\N
205	Mono	Areca camarinensis Becc.	Arecaceae	Endemic	Endangered	\N
206	Malatandulang-Parang	Calamus balerensis Fernando	Arecaceae	Endemic	Endangered	\N
207	\N	Calamus flexilis W.J.Baker	Arecaceae	Endemic	Endangered	\N
208	\N	Calamus foxworthyi Becc.	Arecaceae	Endemic	Endangered	\N
209	Sika	Calamus caesius Blume	Arecaceae	Indigenous	Endangered	\N
210	Marighoi-Baba	Heterospathe brevicaulis Fernando	Arecaceae	Endemic	Endangered	\N
211	Anibong	Oncosperma platyphyllum Becc.	Arecaceae	Endemic	Endangered	\N
212	\N	Pinanga sobolifera Fernando, Kew Bull.	Arecaceae	Endemic	Endangered	\N
213	Abiking-Puti	Pinanga glaucifolia Fernando	Arecaceae	Endemic	Endangered	\N
214	Lakaúbi	Salacca clemensiana Becc.	Arecaceae	Endemic	Endangered	\N
215	Parutungun	Salacca ramosiana Mogea	Arecaceae	Indigenous	Endangered	\N
216	\N	Diplazium costulisorum (Copel.) C.Chr.	Athyriaceae	Endemic	Endangered	\N
217	\N	Diplazium egenolfioides M.G.Price	Athyriaceae	Endemic	Endangered	\N
218	\N	Diplazium propinquum (Copel.) Alderw.	Athyriaceae	Endemic	Endangered	\N
219	\N	Begonia acclivis C.Coyle	Begoniaceae	Endemic	Endangered	\N
220	\N	Begonia aequata A.Gray	Begoniaceae	Endemic	Endangered	\N
221	\N	Begonia androturba C.Coyle	Begoniaceae	Endemic	Endangered	\N
222	\N	Begonia apayaoensis Merr.	Begoniaceae	Endemic	Endangered	\N
223	\N	Begonia brevipes Merr.	Begoniaceae	Endemic	Endangered	\N
224	\N	Begonia casiguranensis Merr.	Begoniaceae	Endemic	Endangered	\N
225	\N	Begonia gracilipes Merr.	Begoniaceae	Endemic	Endangered	\N
226	\N	Begonia macgregorii Merr.	Begoniaceae	Endemic	Endangered	\N
227	\N	Begonia megalantha Merr.	Begoniaceae	Endemic	Endangered	\N
228	\N	Begonia palawanensis Merr.	Begoniaceae	Endemic	Endangered	\N
229	\N	Begonia platyphlla Merr.	Begoniaceae	Endemic	Endangered	\N
230	\N	Begonia ramosii Merr.	Begoniaceae	Endemic	Endangered	\N
231	\N	Begonia rubiteae M.Hughes	Begoniaceae	Endemic	Endangered	\N
232	Cycad Fern	Brainea insignis (Hook.) J.Sm	Blechnaceae	Indigenous	Endangered	\N
233	\N	Centrolepis philippinensis Merr.	Centrolepidaceae	Indigenous	Endangered	\N
234	Golden Fern	Cibotium barometz (L.) J.Sm., London J. Bot.	Cibotiaceae	Indigenous	Endangered	\N
235	Golden Fern	Cibotium cumingii Kunze, Farrnkräuter	Cibotiaceae	Indigenous	Endangered	\N
236	Malaputat	Terminalia darlingii Merr.	Combretaceae	Endemic	Endangered	\N
237	\N	Cyathea acuminata Copel.	Cyatheaceae	Endemic	Endangered	\N
238	\N	Cyathea apoensis Copel.	Cyatheaceae	Endemic	Endangered	\N
239	\N	Cyathea atropurpurea Copel.	Cyatheaceae	Endemic	Endangered	\N
240	\N	Cyathea binuangensis Alderw.	Cyatheaceae	Endemic	Endangered	\N
241	\N	Cyathea christii Copel.	Cyatheaceae	Endemic	Endangered	\N
242	\N	Cyathea contaminans (Wall. ex Hook.) Copel.	Cyatheaceae	Indigenous	Endangered	\N
243	\N	Cyathea edanoi Copel.	Cyatheaceae	Endemic	Endangered	\N
244	\N	Cyathea ferruginea Christ	Cyatheaceae	Endemic	Endangered	\N
245	\N	Cyathea lepifera (J.Sm. ex Hook.) Copel.	Cyatheaceae	Indigenous	Endangered	\N
246	\N	Cyathea masapilidensis Copel.	Cyatheaceae	Endemic	Endangered	\N
247	\N	Cyathea rufopannosa Christ	Cyatheaceae	Endemic	Endangered	\N
248	\N	Cyathea zamboangana Copel.	Cyatheaceae	Endemic	Endangered	\N
249	\N	Cycas lacrimans KD. Hill & Lindst.	Cycadaceae	Endemic	Endangered	\N
250	\N	Cycas nitida KD. Hill & Lindstr.	Cycadaceae	Endemic	Endangered	\N
251	Culion Pitogo	Cycas wadei Merr.	Cycadaceae	Endemic	Endangered	\N
252	\N	Dennstaedtia articulata Copel.	Dennstaedtiaceae	Endemic	Endangered	\N
253	\N	Dennstaedtia fusca Copel.	Dennstaedtiaceae	Endemic	Endangered	\N
254	\N	Microlepia protracta Copel.	Dennstaedtiaceae	Endemic	Endangered	\N
255	\N	Dicksonia mollis Holttum	Dicksoniaceae	Indigenous	Endangered	\N
256	Sibuyan Katmon	Dillenia sibuyanensis Merr.	Dilleniaceae	Endemic	Endangered	\N
262	\N	Dryopteris chrysocoma C.Chr.	Dryopteridaceae	Indigenous	Endangered	\N
263	\N	Dryopteris permagna M.G.Price	Dryopteridaceae	Endemic	Endangered	\N
264	\N	Polystichum nudum Copel.	Dryopteridaceae	Endemic	Endangered	\N
265	Malagos	Rhododendron javanicum (Blume) Benn.	Ericaceae	Indigenous	Endangered	\N
266	\N	Rhododendron madulidii Argent	Ericaceae	Endemic	Endangered	\N
267	\N	Rhododendron xanthopetalum Merr.	Ericaceae	Endemic	Endangered	\N
271	Tayabak, Jade Vine	Strongylodon macrobotrys A.Gray	Fabaceae	Endemic	Endangered	\N
273	Lanao Lipstick Plant	Aeschynanthus firmus Kraenzl.	Gesneriaceae	Endemic	Endangered	\N
274	Davao Lipstick Plant	Aeschynanthus littoralis Schltr.	Gesneriaceae	Endemic	Endangered	\N
275	Chila	Aeschynanthus nervosus Schltr.	Gesneriaceae	Endemic	Endangered	\N
276	Round-Leafed Lipstick Plant	Aeschynanthus ovatus Schltr.	Gesneriaceae	Endemic	Endangered	\N
277	\N	Agalmyla bilirana Hilliard & BL Burtt	Gesneriaceae	Endemic	Endangered	\N
278	\N	Agalmyla montis-tomasii Hilliard & BL Burtt	Gesneriaceae	Endemic	Endangered	\N
279	Paningit	Embolanthera spicata Merr.	Hamamelidaceae	Endemic	Endangered	\N
280	\N	Distichophyllum noguchianum B.C.Tan	Hookeriaceae	Endemic	Endangered	\N
283	Cebu Kalingag	Cinnamomum cebuense Kosterm.	Lauraceae	Endemic	Endangered	\N
284	Paren	Cryptocarya palawanensis Merr.	Lauraceae	Endemic	Endangered	\N
286	\N	Drepanolejeunea bakeri Herzog	Lejeuneaceae	Endemic	Endangered	\N
287	\N	Phlegmariurus carinatus (Desv. ex Poir.) Ching	Lycopodiaceae	Indigenous	Endangered	\N
288	\N	Phlegmariurus elmeri (Herter) A.R.Field & Bostock	Lycopodiaceae	Endemic	Endangered	\N
289	Tagulaylay	Phlegmariurus phlegmaria (L.) Holub	Lycopodiaceae	Indigenous	Endangered	\N
290	Tagulaylay	Phlegmariurus salvinioides (Herter) Ching	Lycopodiaceae	Indigenous	Endangered	\N
291	\N	Phlegmariurus squarrosa (G.Forst.) Á.Löve & D.Löve	Lycopodiaceae	Indigenous	Endangered	\N
292	Bantigi	Pemphis acidula J.R.Forst. & G.Forst.	Lythraceae	Indigenous	Endangered	\N
293	Gapas-Gapas	Camptostemon philippinense (S.Vidal) Becc.	Malvaceae	Indigenous	Endangered	\N
294	Red Durian	Durio graveolens Becc.	Malvaceae	Indigenous	Endangered	\N
295	Bungau	Christensenia aesculifolia (Blume) Maxon	Marattiaceae	Indigenous	Endangered	\N
296	\N	Matonia foxworthyi Copel.	Matoniaceae	Indigenous	Endangered	\N
297	Bungau	Astrocalyx calycina (Vidal) Merr.	Melastomataceae	Endemic	Endangered	\N
298	\N	Medinilla apayaoensis Merr.	Melastomataceae	Endemic	Endangered	\N
299	Kalambog-Lambog	Medinilla banahaensis Elmer	Melastomataceae	Endemic	Endangered	\N
300	\N	Medinilla binaria Elmer	Melastomataceae	Endemic	Endangered	\N
301	Tiualos Tatana	Medinilla calelanensis Elmer	Melastomataceae	Endemic	Endangered	\N
302	\N	Medinilla capitata Merr.	Melastomataceae	Endemic	Endangered	\N
303	Gubangbang	Medinilla clementis Merr.	Melastomataceae	Endemic	Endangered	\N
304	Salanakad	Medinilla compressicaulis Merr.	Melastomataceae	Endemic	Endangered	\N
305	Pagirang	Medinilla coronata Regalado	Melastomataceae	Endemic	Endangered	\N
306	Palikpik-Hito	Medinilla lagunae S.Vidal & Fern.-Vill.	Melastomataceae	Endemic	Endangered	\N
307	\N	Medinilla miniata Merr.	Melastomataceae	Endemic	Endangered	\N
308	Palawan Medinilla	Medinilla palawanensis Regalado	Melastomataceae	Endemic	Endangered	\N
309	Baladu	Medinilla pendula Merr.	Melastomataceae	Endemic	Endangered	\N
310	Lalanug	Medinilla stenobotrys Merr.	Melastomataceae	Endemic	Endangered	\N
311	Hagod	Medinilla surigaoensis Regalado	Melastomataceae	Endemic	Endangered	\N
312	\N	Medinilla tayabensis Merr.	Melastomataceae	Endemic	Endangered	\N
313	Bukalau	Walsura monophylla Merr.	Meliaceae	Endemic	Endangered	\N
315	\N	Nepenthes bellii Kondo	Nepenthaceae	Endemic	Endangered	\N
316	\N	Nepenthes burkei Mast.	Nepenthaceae	Endemic	Endangered	\N
317	\N	Nepenthes ceciliae Gronem. et al.	Nepenthaceae	Endemic	Endangered	\N
318	\N	Nepenthes copelandii Merrill ex Macfarl.	Nepenthaceae	Endemic	Endangered	\N
319	\N	Nepenthes gantungensis S.McPherson et al.	Nepenthaceae	Endemic	Endangered	\N
320	\N	Nepenthes mantalingajanensis J. Nerz & A. Wistuba	Nepenthaceae	Endemic	Endangered	\N
321	\N	Nepenthes petiolata Danser	Nepenthaceae	Endemic	Endangered	\N
322	Kuong-Kuong	Nepenthes philippinensis Macfarl.	Nepenthaceae	Endemic	Endangered	\N
323	\N	Nepenthes saranganiensis Sh.Kurata	Nepenthaceae	Endemic	Endangered	\N
324	\N	Nepenthes sumagaya Cheek	Nepenthaceae	Endemic	Endangered	\N
325	\N	Nepenthes surigaoensis Elmer	Nepenthaceae	Endemic	Endangered	\N
326	Sandaoua	Nepenthes truncata Macfarl.	Nepenthaceae	Endemic	Endangered	\N
327	\N	Nepenthes ultra Jebb & Cheek	Nepenthaceae	Endemic	Endangered	\N
328	Kako	Nepenthes ventricosa Blanco	Nepenthaceae	Endemic	Endangered	\N
329	\N	Nepenthes viridis Micheler et al.	Nepenthaceae	Endemic	Endangered	\N
330	Grape Fern	Botrychium lanuginosum Wall. ex Hook. & Grev.	Ophioglossaceae	Indigenous	Endangered	\N
331	\N	Ophioglossum pendulum L.	Ophioglossaceae	Indigenous	Endangered	\N
332	\N	Ophioglossum ramosii Copel.	Ophioglossaceae	Endemic	Endangered	\N
333	\N	Aerides lawrenciae Reichb.f.	Orchidaceae	Endemic	Endangered	\N
334	\N	Amesiella philippinensis (Ames) Garay	Orchidaceae	Endemic	Endangered	\N
335	\N	Arachnis flos-aeris (L.) Rchb.f.	Orchidaceae	Indigenous	Endangered	\N
336	\N	Bulbophyllum nymphopolitanum Kraenzl.	Orchidaceae	Endemic	Endangered	\N
337	\N	Bulbophyllum philippinense Ames	Orchidaceae	Endemic	Endangered	\N
338	\N	Bulbophyllum piestoglossum J.J.Verm.	Orchidaceae	Endemic	Endangered	\N
339	\N	Bulbophyllum stellatum Ames	Orchidaceae	Endemic	Endangered	\N
340	\N	Cirrhopetalum cumingii Lindl.	Orchidaceae	Endemic	Endangered	\N
341	\N	Cirrhopetalum loherianum Kranzl.	Orchidaceae	Endemic	Endangered	\N
342	\N	Cleisostoma sagittatum Blume,	Orchidaceae	Indigenous	Endangered	\N
343	\N	Coelogyne confusa Ames	Orchidaceae	Endemic	Endangered	\N
344	\N	Coelogyne palawanensis Ames	Orchidaceae	Endemic	Endangered	\N
345	\N	Corybas laceratus LO Williams	Orchidaceae	Endemic	Endangered	\N
346	\N	Corybas merrillii (Ames) Ames	Orchidaceae	Endemic	Endangered	\N
347	\N	Corybas ramosianus J Dransf.	Orchidaceae	Endemic	Endangered	\N
348	\N	Cymbidium aliciae Quisumb.	Orchidaceae	Endemic	Endangered	\N
349	\N	Cymbidium ensifolium (L.) Sw.	Orchidaceae	Endemic	Endangered	\N
350	\N	Dendrobium bullenianum Rchb.f	Orchidaceae	Endemic	Endangered	\N
351	\N	Dendrobium goldschmidtianum Kraenzl.	Orchidaceae	Indigenous	Endangered	\N
352	\N	Dendrobium lunatum Lindl.	Orchidaceae	Endemic	Endangered	\N
353	\N	Grammatophyllum measuresianum Sander	Orchidaceae	Indigenous	Endangered	\N
354	\N	Phalaenopsis hieroglyphica (Reichb.f.) HR Sweet	Orchidaceae	Endemic	Endangered	\N
355	\N	Phalaenopsis lindenii Loher	Orchidaceae	Endemic	Endangered	\N
356	\N	Phalaenopsis lueddemanniana Reichb.f.	Orchidaceae	Endemic	Endangered	\N
357	\N	Phalaenopsis pallens (Lindl.) Reichb.f.	Orchidaceae	Endemic	Endangered	\N
358	\N	Phalaenopsis philippinensis (Golamco) ex Fowlie & C.Z.Tsang	Orchidaceae	Endemic	Endangered	\N
359	\N	Phalaenopsis pulchra (Reichb.f) HR Sweet	Orchidaceae	Endemic	Endangered	\N
360	\N	Phalaenopsis reichenbachiana Reichb.f. & Sander	Orchidaceae	Endemic	Endangered	\N
361	\N	Phalaenopsis sanderiana Reichb.f.	Orchidaceae	Endemic	Endangered	\N
362	\N	Phalaenopsis schilleriana Reichb.f.	Orchidaceae	Endemic	Endangered	\N
363	\N	Phalaenopsis stuartiana Reichb.f.	Orchidaceae	Endemic	Endangered	\N
364	\N	Phalaenopsis x veitchiana Rchb.f	Orchidaceae	Endemic	Endangered	\N
365	\N	Phalaenopsis amabilis (L.) Blume	Orchidaceae	Indigenous	Endangered	\N
366	\N	Renanthera monachica Ames	Orchidaceae	Endemic	Endangered	\N
367	\N	Renanthera storiei Rchb.f.	Orchidaceae	Endemic	Endangered	\N
368	\N	Staurochilus leytensis (Ames) Christenson	Orchidaceae	Endemic	Endangered	\N
369	\N	Trichoglottis loheriana (Kraenzl.) L.O.Williams	Orchidaceae	Endemic	Endangered	\N
370	\N	Trichoglottis luzonensis (Ames) Ames	Orchidaceae	Endemic	Endangered	\N
371	\N	Vanda javierae D Tiu ex Fessel & Lückel	Orchidaceae	Endemic	Endangered	\N
372	\N	Vanda luzonica Loher ex Rolfe	Orchidaceae	Endemic	Endangered	\N
373	\N	Vanda merrillii Ames & Quisumb.	Orchidaceae	Endemic	Endangered	\N
374	\N	Vanda scandens Holttum	Orchidaceae	Indigenous	Endangered	\N
375	Pulag Carpet Grass	Rytidosperma oreoboloides (F.Muell.) H.P.Linder	Poaceae	Indigenous	Endangered	\N
377	Igem-Lakibunga	Podocarpus macrocarpus de Laub.	Podocarpaceae	Endemic	Endangered	\N
378	Igem-Bilogan	Podocarpus ramosii R.R.Mill	Podocarpaceae	Indigenous	Endangered	\N
379	Ant Fern	Lecanopteris luzonensis Hennip.	Polypodiaceae	Endemic	Endangered	\N
380	\N	Lecanopteris deparioides (Cesati) Baker	Polypodiaceae	Indigenous	Endangered	\N
381	\N	Lecanopteris sarcopus (Teijsm. & Binn.) Copel.	Polypodiaceae	Indigenous	Endangered	\N
382	\N	Lecanopteris sinuosa (Wall. ex Hook.) Copel.	Polypodiaceae	Indigenous	Endangered	\N
383	Tailed Fern	Lepisorus platyrhynchos (Kunze) Li Wang	Polypodiaceae	Indigenous	Endangered	\N
384	Flat Whisk Fern	Psilotum complanatum Sw.	Psilotaceae	Indigenous	Endangered	\N
385	Zamora Whisk Fern	Tmesipteris zamorae Gruezo & Amoroso,	Psilotaceae	Endemic	Endangered	\N
386	Mindanao Maindenhair Fern	Adiantum (= Pteris) mindanaoense Copel.	Pteridaceae	Endemic	Endangered	\N
387	\N	Ceratopteris thalictroides (L.) Brongn.	Pteridaceae	Indigenous	Endangered	\N
388	\N	Doryopteris concolor (Langsd & Fisch) Kuhn	Pteridaceae	Indigenous	Endangered	\N
389	\N	Pteris endoneura MG Price	Pteridaceae	Endemic	Endangered	\N
390	\N	Rafflesia baletei Barcelona & Cajano	Rafflesiaceae	Endemic	Endangered	\N
391	Malaboo	Rafflesia manillana Teschem.	Rafflesiaceae	Endemic	Endangered	\N
392	\N	Rafflesia mira Fernando & Ong	Rafflesiaceae	Endemic	Endangered	\N
393	\N	Rafflesia philippensis Blanco ex Llanos	Rafflesiaceae	Endemic	Endangered	\N
394	Uruy	Rafflesia speciosa Barcelona & Fernando	Rafflesiaceae	Endemic	Endangered	\N
395	\N	Rhachithecium papillosum (Williams) Wijk & Margard.	Rhachitheciaceae	Endemic	Endangered	\N
396	\N	Antherostele banahaensis (Elmer) Bremek.	Rubiaceae	Endemic	Endangered	\N
397	\N	Antherostele grandistipula (Merr.) Bremek.	Rubiaceae	Endemic	Endangered	\N
398	\N	Boholia nematostylis Merr.	Rubiaceae	Indigenous	Endangered	\N
399	Kubili	Cubilia cubili (Blanco) Adelb.	Sapindaceae	Indigenous	Endangered	\N
400	Tamaho	Gloeocarpus patentivalvis (Radlk.) Radlk.	Sapindaceae	Endemic	Endangered	\N
401	Pasi	Guioa acuminata Radlk.	Sapindaceae	Endemic	Endangered	\N
403	Malalóno	Madhuca lanceolata Merr.	Sapotaceae	Endemic	Endangered	\N
404	Bétis-Bundók	Madhuca monticola (Merr.) Merr	Sapotaceae	Endemic	Endangered	\N
405	Malabetis	Madhuca oblongifolia (Merr.) Merr.	Sapotaceae	Endemic	Endangered	\N
407	\N	Actinostachys inopinata (Selling) C.F.Reed	Schizaeaceae	Indigenous	Endangered	\N
408	\N	Schizaea malaccana Baker	Schizaeaceae	Indigenous	Endangered	\N
409	\N	Selaginella apoensis Hieron.	Selaginellaceae	Endemic	Endangered	\N
410	\N	Selaginella magnifica Warb.	Selaginellaceae	Endemic	Endangered	\N
411	\N	Selaginella pricei BC Tan & Jermy	Selaginellaceae	Endemic	Endangered	\N
412	\N	Selaginella tamariscina (P.Beauv.) Spring	Selaginellaceae	Indigenous	Endangered	\N
413	Linatog	Eurycoma longifolia Jack	Simaroubaceae	Endemic	Endangered	\N
414	Co Mabunót	Gomphandra coi Schori	Stemonuraceae	Endemic	Endangered	\N
415	\N	Gomphandra psilandra Schori	Stemonuraceae	Endemic	Endangered	\N
416	\N	Gomphandra ultramafiterrestris Schori	Stemonuraceae	Endemic	Endangered	\N
417	\N	Psomiocarpa apiifolia C Presl	Tectariaceae	Endemic	Endangered	\N
418	\N	Tectaria lobbii (Hook.) Copel.	Tectariaceae	Indigenous	Endangered	\N
419	\N	Tectaria macleanii (Copel.) S.Y.Dong	Tectariaceae	Indigenous	Endangered	\N
420	\N	Tectaria stalactica MG Price	Tectariaceae	Endemic	Endangered	\N
421	Agarwood/Bari	Aquilaria malaccensis Lam.	Thymelaeaceae	Indigenous	Endangered	\N
422	\N	Rinorea niccolifera Fernando	Violaceae	Endemic	Endangered	\N
423	Dainsuli	Hedychium philippense K Schum.	Zingiberaceae	Endemic	Endangered	\N
424	\N	Gymnostachyum palawanense Elmer	Acanthaceae	Endemic	Vulnerable	\N
425	\N	Gymnostachyum pictum Elmer	Acanthaceae	Endemic	Vulnerable	\N
426	\N	Justicia addisoniensis (Elmer) C.M.Gao & Y.F.Deng	Acanthaceae	Endemic	Vulnerable	\N
427	\N	Justicia pulgarensis (Elmer) C.M.Gao & Y.F. Deng	Acanthaceae	Endemic	Vulnerable	\N
428	\N	Lepidagathis palawanensis Merr.	Acanthaceae	Endemic	Vulnerable	\N
429	\N	Ptyssiglottis aequifolia (C.B.Clarke) Merr.	Acanthaceae	Endemic	Vulnerable	\N
430	\N	Ptyssiglottis elmeri Merr.	Acanthaceae	Endemic	Vulnerable	\N
431	\N	Ruellia philippinensis Elmer	Acanthaceae	Endemic	Vulnerable	\N
432	\N	Staurogyne nudispica (C.B.Clarke) Bremek.	Acanthaceae	Endemic	Vulnerable	\N
433	\N	Strobilanthes palawanensis Elmer	Acanthaceae	Endemic	Vulnerable	\N
434	Dagwey	Saurauia bontocensis Merr.	Actinidiaceae	Endemic	Vulnerable	\N
435	Mutá-Mutá	Saurauia longistyla Merr.	Actinidiaceae	Endemic	Vulnerable	\N
437	Malapaho	Mangifera monandra Merr.	Anacardiaceae	Endemic	Vulnerable	\N
439	Apali	Mangifera longipes Griff.	Anacardiaceae	Indigenous	Vulnerable	\N
440	Ligas-Ilanan	Semecarpus paucinervius Merr.	Anacardiaceae	Indigenous	Vulnerable	\N
441	Lomarau	Swintonia acuta Engl.	Anacardiaceae	Indigenous	Vulnerable	\N
442	Kalabúyo	Dasymaschalon scandens Merr.	Annonaceae	Endemic	Vulnerable	\N
443	Palawan Pirángat	Desmos palawanensis (Elmer) Merr.	Annonaceae	Endemic	Vulnerable	\N
444	Ubáran	Miliusa horsfieldii (Benn.) Baill. ex Pierre	Annonaceae	Endemic	Vulnerable	\N
445	Lanútan-Bangúhan	Mitrephora fragrans Merr.	Annonaceae	Endemic	Vulnerable	\N
446	Tabingálang	Orophea creaghii (Ridl.) Leonardia & Kessler	Annonaceae	Endemic	Vulnerable	\N
447	Bangar	Polyalthia elmeri Merr.	Annonaceae	Endemic	Vulnerable	\N
448	Palawan Lanutan	Polyalthia palawanensis Merr.	Annonaceae	Endemic	Vulnerable	\N
449	\N	Uvaria lurida Hook.f. & Thomson	Annonaceae	Indigenous	Vulnerable	\N
450	Silhigan	Alstonia iwahigensis Elmer	Apocynaceae	Indigenous	Vulnerable	\N
451	\N	Hoya meliflua (Blanco) Merr.	Apocynaceae	Endemic	Vulnerable	\N
452	\N	Hoya paziae Kloppenb.	Apocynaceae	Endemic	Vulnerable	\N
453	Merrill Pasnit	Kibatalia merrilliana Woodson	Apocynaceae	Endemic	Vulnerable	\N
454	\N	Quisumbingia merrillii (Schltr.) Merr.	Apocynaceae	Endemic	Vulnerable	\N
455	Sakang-Manok/Alibótbot	Tabernaemontana cordata Merr.	Apocynaceae	Endemic	Vulnerable	\N
456	\N	Urceola laevis (Elmer) Merr.	Apocynaceae	Indigenous	Vulnerable	\N
457	Tabo	Willughbeia sarawacensis (Pierre) K.Schum.	Apocynaceae	Indigenous	Vulnerable	\N
458	Palawan Lanéte	Wrightia palawanensis D.J.Middleton	Apocynaceae	Endemic	Vulnerable	\N
459	Palawan Kalásan	Ilex palawanica Loes. ex Elmer	Aquifoliaceae	Endemic	Vulnerable	\N
460	\N	Alocasia micholitziana Sander	Araceae	Endemic	Vulnerable	\N
461	Badiang	Alocasia zebrina Schott ex van Houtte	Araceae	Endemic	Vulnerable	\N
462	\N	Homalomena palawanensis Engl.	Araceae	Endemic	Vulnerable	\N
463	Higin	Polyscias pulgarense Elmer	Araliaceae	Endemic	Vulnerable	\N
464	\N	Schefflera microphylla Merr.	Araliaceae	Endemic	Vulnerable	\N
465	Bagtik	Agathis dammara (Lamb.) Rich. & A.Rich.	Araucariaceae	Indigenous	Vulnerable	\N
467	Búngang Jolo,\nManila Palm	Adonidia merrillii (Becc.) Becc	Arecaceae	Endemic	Vulnerable	\N
468	Pisa, Sambulayan	Areca hutchinsoniana Becc.	Arecaceae	Endemic	Vulnerable	\N
469	Bungang-Ipot	Areca ipot Becc.	Arecaceae	Endemic	Vulnerable	\N
470	Boga, Pita	Areca vidaliana Becc.	Arecaceae	Indigenous	Vulnerable	\N
471	Pit-Pit, Saranoi	Calamus curranii (Becc.) W.J.Baker	Arecaceae	Endemic	Vulnerable	\N
472	Abuan	Calamus diepenhorstii Miq.	Arecaceae	Endemic	Vulnerable	\N
473	Arorog	Calamus javensis Blume	Arecaceae	Indigenous	Vulnerable	\N
474	Pin-Pin	Calamus jenkinsianus Griff.	Arecaceae	Indigenous	Vulnerable	\N
475	Bugtong	Calamus subinermis Wendl. ex Becc.	Arecaceae	Indigenous	Vulnerable	\N
476	Buragat	Korthalsia merrillii Becc.	Arecaceae	Endemic	Vulnerable	\N
477	Kalalias	Korthalsia robusta Blume	Arecaceae	Indigenous	Vulnerable	\N
478	Balatbat	Licuala spinosa Wurmb.	Arecaceae	Indigenous	Vulnerable	\N
479	Anibong	Oncosperma tigillarium (Jack) Ridl.	Arecaceae	Indigenous	Vulnerable	\N
480	\N	Orania decipiens Becc.	Arecaceae	Endemic	Vulnerable	\N
481	Curran Abíki	Pinanga curranii Becc.	Arecaceae	Endemic	Vulnerable	\N
482	Dahu	Asplenium vittaeforme Cav.	Aspleniaceae	Indigenous	Vulnerable	\N
483	\N	Begonia chingipengii R.Rubite	Begoniaceae	Endemic	Vulnerable	\N
484	\N	Begonia cleopatrae C.Coyle	Begoniaceae	Endemic	Vulnerable	\N
485	\N	Begonia coronensis Merr.	Begoniaceae	Endemic	Vulnerable	\N
486	\N	Begonia cumingiana (Klotzsch.) A.DC	Begoniaceae	Endemic	Vulnerable	\N
487	\N	Begonia georgei C.Coyle	Begoniaceae	Endemic	Vulnerable	\N
488	\N	Begonia gutierrezii C.Coyle	Begoniaceae	Endemic	Vulnerable	\N
489	\N	Begonia oxysperma A DC	Begoniaceae	Endemic	Vulnerable	\N
490	\N	Begonia suborbiculata Merr.	Begoniaceae	Endemic	Vulnerable	\N
491	\N	Begonia tandangii C.-I.Peng & R.Rubite	Begoniaceae	Endemic	Vulnerable	\N
492	\N	Begonia wilkiei C.Coyle	Begoniaceae	Endemic	Vulnerable	\N
493	\N	Begonia woodii Merr	Begoniaceae	Endemic	Vulnerable	\N
494	\N	Berberis barandana S.Vidal	Berberidaceae	Endemic	Vulnerable	\N
495	Labayanan	Radermachera coriacea Merr.	Bignoniaceae	Endemic	Vulnerable	\N
496	\N	Blechnum egregium Copel.	Blechnaceae	Indigenous	Vulnerable	\N
497	\N	Blechnum fraseri (A.Cunn.) Luerss.	Blechnaceae	Indigenous	Vulnerable	\N
498	\N	Bryoxiphium norvegicum (Brid.) Mitt.	Bryoxiphiaceae	Indigenous	Vulnerable	\N
499	Marangub	Protium connarifolium (Perkins) Merr.	Burseraceae	Endemic	Vulnerable	\N
500	Palawan Agoho	Gymnostoma nobile (Whitmore) L.A.S. Johnson	Casuarinaceae	Indigenous	Vulnerable	\N
501	Palawan Surag	Glyptopetalum palawanense Merr.	Celastraceae	Endemic	Vulnerable	\N
502	\N	Salacia cymosa Elmer	Celastraceae	Endemic	Vulnerable	\N
503	\N	Salacia marginata Ding Hou	Celastraceae	Endemic	Vulnerable	\N
504	Merrillanaháu	Saribus merrillii (Becc.) Bacon & W.J.Baker	Arecaceae	Endemic	Vulnerable	\N
505	\N	Calamus ornatus Blume var. pulverulentus Fernando	Arecaceae	Endemic	Vulnerable	\N
506	Tagobáhi	Clethra pulgarensis Elmer	Clethraceae	Endemic	Vulnerable	\N
507	Bunóg-Diláu	Garcinia sulphurea Elmer	Clusiaceae	Endemic	Vulnerable	\N
508	Bongoran	Terminalia macrantha Merr. & Quisumb. ex Rojo	Combretaceae	Endemic	Vulnerable	\N
509	Dalinsoi	Terminalia surigaensis Merr.	Combretaceae	Endemic	Vulnerable	\N
510	\N	Cyathea callosa Christ	Cyatheaceae	Endemic	Vulnerable	\N
511	\N	Cyathea caudata (J Sm.) Copel.	Cyatheaceae	Endemic	Vulnerable	\N
512	\N	Cyathea cinerea Copel.	Cyatheaceae	Endemic	Vulnerable	\N
513	\N	Cyathea elmeri (Copel.) Copel.	Cyatheaceae	Indigenous	Vulnerable	\N
514	\N	Cyathea fenicis (C. Chr.) Copel.	Cyatheaceae	Indigenous	Vulnerable	\N
515	\N	Cyathea fuliginosa (Christ) Copel.	Cyatheaceae	Endemic	Vulnerable	\N
516	\N	Cyathea halconensis Christ	Cyatheaceae	Endemic	Vulnerable	\N
517	\N	Cyathea heterochlamydea Copel.	Cyatheaceae	Endemic	Vulnerable	\N
518	\N	Cyathea negrosiana Christ	Cyatheaceae	Endemic	Vulnerable	\N
519	\N	Cyathea philippinensis Baker	Cyatheaceae	Endemic	Vulnerable	\N
520	\N	Cyathea robinsonii Copel.	Cyatheaceae	Endemic	Vulnerable	\N
521	\N	Cyathea setulosa Copel.	Cyatheaceae	Endemic	Vulnerable	\N
522	Pitogong-Dagat	Cycas edentata de Laub.	Cycadaceae	Endemic	Vulnerable	\N
523	\N	Cycas vespertilio KD. Hill & Lindstr.	Cycadaceae	Endemic	Vulnerable	\N
524	Pitogo	Cycas riuminiana Porte ex Regel	Cycadaceae	Indigenous	Vulnerable	\N
525	\N	Bescherellia elegantissima Duby	Cyrtopodaceae	Endemic	Vulnerable	\N
526	\N	Gymnocarpium oyamense (Baker) Ching	Cystopteridaceae	Indigenous	Vulnerable	\N
527	\N	Dillenia cauliflora Merr	Dilleniaceae	Endemic	Vulnerable	\N
528	Fischer Katmon	Dillenia fischeri Merr.	Dilleniaceae	Endemic	Vulnerable	\N
530	Kátmon-Bugtóng	Dillenia monantha Merr	Dilleniaceae	Endemic	Vulnerable	\N
531	Palawan Ube	Dioscorea palawana Prain & Burkill	Dioscoreaceae	Endemic	Vulnerable	\N
532	Tailed-Leaf Panáu	Dipterocarpus caudatus Foxw.	Dipterocarpaceae	Endemic	Vulnerable	\N
534	Panau	Dipterocarpus gracilis Blume	Dipterocarpaceae	Indigenous	Vulnerable	\N
539	\N	Hopea rudiformis P.S.Ashton	Dipterocarpaceae	Indigenous	Vulnerable	\N
541	Merill Katap	Trigonostemon merrillii Elmer	Euphorbiaceae	Indigenous	Vulnerable	\N
547	Blanco Narig	Vatica umbonata (Hook.f.) Burck	Dipterocarpaceae	Indigenous	Vulnerable	\N
548	\N	Dryopteris polita Rosenst.	Dryopteridaceae	Indigenous	Vulnerable	\N
550	Kamagong	Diospyros discolor Willd.	Ebenaceae	Indigenous	Vulnerable	\N
555	\N	Rhododendron edanoi Merr. & Quisumb	Ericaceae	Endemic	Vulnerable	\N
556	Koch'S Malagos	Rhododendron kochii Stein	Ericaceae	Endemic	Vulnerable	\N
557	\N	Rhododendron loboense H. F. Copel.	Ericaceae	Endemic	Vulnerable	\N
558	Ausip	Rhododendron subsessile Rendle	Ericaceae	Endemic	Vulnerable	\N
559	\N	Rhododendron vidalii Rolfe	Ericaceae	Endemic	Vulnerable	\N
560	\N	Rhododendron wilkei Argent	Ericaceae	Endemic	Vulnerable	\N
561	\N	Vaccinium brachytrichum Sleumer	Ericaceae	Endemic	Vulnerable	\N
562	Pagangpang	Vaccinium gitingense Elmer	Ericaceae	Endemic	Vulnerable	\N
563	\N	Erpodium luzonense (Bartr.) H.A. Crum	Erpodiaceae	Indigenous	Vulnerable	\N
564	\N	Solmsiella biseriata (Austin) Steere	Erpodiaceae	Indigenous	Vulnerable	\N
566	Súda-Súda	Euphorbia trigona Mill.	Euphorbiaceae	Endemic	Vulnerable	\N
569	Dila-Dila	Cynometra inaequifolia A Gray	Fabaceae	Endemic	Vulnerable	\N
571	Palawan Ipil	Intsia palembanica Miq.	Fabaceae	Indigenous	Vulnerable	\N
573	\N	Kunstleria forbesii Prain	Fabaceae	Endemic	Vulnerable	\N
574	Makapilit	Pericopsis mooniana Thwaites	Fabaceae	Indigenous	Vulnerable	\N
575	\N	Phanera aherniana (Perkins) de Wit	Fabaceae	Indigenous	Vulnerable	\N
576	Kayugalo	Sindora inermis Merr.	Fabaceae	Endemic	Vulnerable	\N
577	Bindanugan	Strongylodon elmeri Merr.	Fabaceae	Endemic	Vulnerable	\N
578	\N	Teyleria tetragona (Merr.) J.A.Lackey & Maesen	Fabaceae	Endemic	Vulnerable	\N
580	Apo Oak	Lithocarpus apoensis (Elmer) Rehd.	Fagaceae	Endemic	Vulnerable	\N
581	Katiluk	Lithocarpus jordanae (Fern.-Villar) Rehd.	Fagaceae	Endemic	Vulnerable	\N
582	\N	Aeschynanthus cuernosensis Elmer	Gesneriaceae	Endemic	Vulnerable	\N
583	\N	Aeschynanthus curvicalyx Mendum	Gesneriaceae	Endemic	Vulnerable	\N
584	\N	Aeschynanthus elmeri Mendum	Gesneriaceae	Endemic	Vulnerable	\N
585	\N	Aeschynanthus madulidii Mendum	Gesneriaceae	Endemic	Vulnerable	\N
586	Pamingkauan	Aeschynanthus miniaceus BL Burtt & PJB Woods	Gesneriaceae	Endemic	Vulnerable	\N
587	\N	Aeschynanthus pergracilis Kraenzl.	Gesneriaceae	Endemic	Vulnerable	\N
588	\N	Aeschynanthus truncatus Schltr.	Gesneriaceae	Endemic	Vulnerable	\N
589	\N	Agalmyla biflora (Elmer) Hilliard & BL Burtt	Gesneriaceae	Endemic	Vulnerable	\N
590	Tasik Sa Lomot	Agalmyla calelanensis (Elmer) Hilliard & BL Burtt	Gesneriaceae	Endemic	Vulnerable	\N
591	\N	Agalmyla glabra (Merr.) Hilliard & BL Burtt	Gesneriaceae	Endemic	Vulnerable	\N
592	\N	Agalmyla parvilimba Hilliard & BL Burtt	Gesneriaceae	Endemic	Vulnerable	\N
593	\N	Agalmyla persimilis Hilliard & BL Burtt	Gesneriaceae	Endemic	Vulnerable	\N
594	\N	Agalmyla rotundiloba Hilliard & BL Burtt	Gesneriaceae	Endemic	Vulnerable	\N
595	\N	Agalmyla samarica Hilliard & BL Burtt	Gesneriaceae	Endemic	Vulnerable	\N
596	\N	Agalmyla sibuyanensis Hilliard & BL Burtt	Gesneriaceae	Endemic	Vulnerable	\N
597	Balibadon	Agalmyla urdanetensis (Elmer) Hilliard & BL Burtt	Gesneriaceae	Endemic	Vulnerable	\N
598	\N	Codonoboea woodii (Merr.) A.Weber	Gesneriaceae	Endemic	Vulnerable	\N
599	\N	Cyrtandra cleopatrae H.J.Atkins & Cronk	Gesneriaceae	Endemic	Vulnerable	\N
600	\N	Cyrtandra elatostemmoides Elmer	Gesneriaceae	Indigenous	Vulnerable	\N
601	\N	Cyrtandra inaequifolia Elmer	Gesneriaceae	Endemic	Vulnerable	\N
602	\N	Cyrtandra livida Kraenzl.	Gesneriaceae	Endemic	Vulnerable	\N
603	\N	Hedyotis bambusetorum Merr.	Rubiaceae	Endemic	Vulnerable	\N
605	\N	Cyrtandra hirtigera H.J.Atkins & Cronk var. chlorina H.J.Atkins & Cronk	Gesneriaceae	Endemic	Vulnerable	\N
606	\N	Cyrtandra hirtigera H.J.Atkins & Cronk var. hirtigera	Gesneriaceae	Endemic	Vulnerable	\N
607	\N	Cyrtandra pulgarensis Elmer ex H.J.Atkins & Cronk	Gesneriaceae	Endemic	Vulnerable	\N
608	\N	Cyrtandra rupicola Elmer	Gesneriaceae	Endemic	Vulnerable	\N
609	\N	Bryobrothera crenulata (Broth. & Par.) Ther.	Hookeriaceae	Indigenous	Vulnerable	\N
610	\N	Ephemeropsis tjibodensis Goeb.	Hookeriaceae	Indigenous	Vulnerable	\N
611	\N	Clerodendrum macrocalyx HJ Lam	Lamiaceae	Endemic	Vulnerable	\N
612	Bagab	Clerodendrum mindorense Merr.	Lamiaceae	Endemic	Vulnerable	\N
614	Alipúng	Gmelina philippensis Cham.	Lamiaceae	Endemic	Vulnerable	\N
615	\N	Cinnamomum rupestre Kosterm.	Lauraceae	Endemic	Vulnerable	\N
616	Bagarilau	Cryptocarya ampla Merr.	Lauraceae	Endemic	Vulnerable	\N
617	Palawan Pútat	Barringtonia palawanensis Chantar.	Lecythidaceae	Endemic	Vulnerable	\N
618	Ridsdale Pútat	Barringtonia ridsdalei Chantar.	Lecythidaceae	Endemic	Vulnerable	\N
619	Vonitan	Lilium longiflorum Thunb.	Liliaceae	Indigenous	Vulnerable	\N
620	Luplupak	Lilium philippinense Baker	Liliaceae	Indigenous	Vulnerable	\N
621	\N	Philbornea magnifolia (Stapf) Hallier f.	Linaceae	Indigenous	Vulnerable	\N
622	\N	Strychnos oleifolia A.W.Hill	Loganiaceae	Endemic	Vulnerable	\N
623	Panugianon	Durio macrophyllus (King) Ridl.	Malvaceae	Indigenous	Vulnerable	\N
624	Bagún	Grewia palawanensis Merr.	Malvaceae	Endemic	Vulnerable	\N
625	Clover Fern	Marsilea minuta L.	Marsileaceae	Indigenous	Vulnerable	\N
626	Ickis Tungau	Beccarianthus ickisii Merr.	Melastomataceae	Endemic	Vulnerable	\N
627	Malintungau	Beccarianthus pulcherrimus (Merr.) Maxw.	Melastomataceae	Endemic	Vulnerable	\N
628	\N	Medinilla cumingii Naudin	Melastomataceae	Endemic	Vulnerable	\N
629	Gunang	Medinilla dolichophylla Merr.	Melastomataceae	Endemic	Vulnerable	\N
630	\N	Memecylon odoratum Elmer	Melastomataceae	Endemic	Vulnerable	\N
631	Kaniuing-Kitid	Aglaia angustifolia Miq.	Meliaceae	Indigenous	Vulnerable	\N
632	Oksa	Aglaia tenuicaulis Hiern	Meliaceae	Indigenous	Vulnerable	\N
633	Maranggo	Azadirachta excelsa (Jack) Jacobs	Meliaceae	Indigenous	Vulnerable	\N
634	Tarublang	Dysoxylum cauliflorum Hiern	Meliaceae	Indigenous	Vulnerable	\N
636	Samar Yabnob	Horsfieldia samarensis de Wilde	Myristicaceae	Endemic	Vulnerable	\N
637	Kalaum	Syzygium borneense (Miq.) Miq.	Myrtaceae	Indigenous	Vulnerable	\N
638	Lamútong-Linís	Syzygium ecostulatum (Elmer) Merr.	Myrtaceae	Endemic	Vulnerable	\N
639	Iwahig Malarúhat	Syzygium iwahigense (Elmer) Merr.	Myrtaceae	Endemic	Vulnerable	\N
643	Duhao	Knema latericia Elmer v. latericia	Myristicaceae	Endemic	Vulnerable	\N
644	\N	Knema latericia Elmer var. subtilis W.J.de Wilde	Myristicaceae	Indigenous	Vulnerable	\N
646	\N	Nepenthes cornuta Marwinski et al.	Nepenthaceae	Endemic	Vulnerable	\N
647	\N	Nepenthes hamiguitanensis Gronem. et al	Nepenthaceae	Endemic	Vulnerable	\N
648	\N	Nepenthes mindanaoensis Sh.Kurata	Nepenthaceae	Endemic	Vulnerable	\N
649	\N	Nepenthes pantaronensis Gieray et al.	Nepenthaceae	Endemic	Vulnerable	\N
650	\N	Nepenthes talaandig Gronem. et al.	Nepenthaceae	Endemic	Vulnerable	\N
651	Bansilai	Brackenridgea palustris Bartell.	Ochnaceae	Endemic	Vulnerable	\N
652	\N	Botrychium daucifolium Wall. ex Hook. & Grev.	Ophioglossaceae	Indigenous	Vulnerable	\N
653	\N	Aerides leeana Reichb.f.	Orchidaceae	Endemic	Vulnerable	\N
654	\N	Aerides quinquevulnera Lindl.	Orchidaceae	Endemic	Vulnerable	\N
655	\N	Ascidieria palawanensis (Ames) W.Suarez & Cootes	Orchidaceae	Endemic	Vulnerable	\N
656	\N	Bulbophyllum curranii Ames	Orchidaceae	Endemic	Vulnerable	\N
657	\N	Bulbophyllum papulosum Garay	Orchidaceae	Endemic	Vulnerable	\N
658	\N	Dendrobium nemorale L.O.Williams	Orchidaceae	Endemic	Vulnerable	\N
659	\N	Dendrobium sanderae Rolfe	Orchidaceae	Endemic	Vulnerable	\N
660	\N	Dendrobium usterioides Ames	Orchidaceae	Endemic	Vulnerable	\N
661	\N	Dendrobium victoria-reginae Loher	Orchidaceae	Endemic	Vulnerable	\N
662	\N	Dendrobium secundum (Blume) Lindl. in Wall.	Orchidaceae	Indigenous	Vulnerable	\N
663	\N	Dendrochilum kingii (Hook.f.) J.J.Sm.	Orchidaceae	Indigenous	Vulnerable	\N
664	\N	Epigeneium treacherianum (Rchb.f ex Hook.f.) Summerh.	Orchidaceae	Indigenous	Vulnerable	\N
665	Rosa Mia	Grammatophyllum multiflorum Lindl.	Orchidaceae	Endemic	Vulnerable	\N
666	\N	Grammatophyllum scriptum (L.) Blume	Orchidaceae	Indigenous	Vulnerable	\N
667	\N	Liparis palawanensis Ames	Orchidaceae	Endemic	Vulnerable	\N
668	\N	Phalaenopsis aphrodite Rchb.f	Orchidaceae	Endemic	Vulnerable	\N
669	\N	Phalaenopsis bastianii O.Gruss & Roellke	Orchidaceae	Endemic	Vulnerable	\N
670	\N	Phalaenopsis equestris (Schauer) Rchb.f	Orchidaceae	Endemic	Vulnerable	\N
671	\N	Phalaenopsis fasciata Reichb.f.	Orchidaceae	Endemic	Vulnerable	\N
672	\N	Phalaenopsis x intermedia	Orchidaceae	Endemic	Vulnerable	\N
673	\N	Phalaenopsis x leucorrhoda	Orchidaceae	Endemic	Vulnerable	\N
674	\N	Phalaenopsis cornu-cervi (Breda) Blume & Rchb.f.	Orchidaceae	Indigenous	Vulnerable	\N
675	\N	Phalaenopsis mariae Burb. ex R.Warner & H.Williams	Orchidaceae	Indigenous	Vulnerable	\N
676	\N	Pinalia curranii (Leav.) W.Suarez & Cootes	Orchidaceae	Endemic	Vulnerable	\N
677	\N	Vandopsis lissochiloides (Gaudich.) Pfitzer in Engl. & Prantl	Orchidaceae	Indigenous	Vulnerable	\N
678	Bagaas, Abasanay/Malapandan	Sararanga philippinensis Merr.	Pandanaceae	Endemic	Vulnerable	\N
679	\N	Pentaphragma platyphyllum Merr.	Pentaphragmataceae	Endemic	Vulnerable	\N
680	Limpahung	Baccaurea lanceolata (Miq.) Müll.Arg. in DC.	Phyllanthaceae	Indigenous	Vulnerable	\N
681	Cenabre Bágna	Glochidion cenabrei Merr.	Phyllanthaceae	Endemic	Vulnerable	\N
682	Tabángo	Glochidion dolichostylum Merr	Phyllanthaceae	Endemic	Vulnerable	\N
683	\N	Glochidion palawanense Elmer	Phyllanthaceae	Endemic	Vulnerable	\N
684	\N	Glochidion pulgarense Elmer	Phyllanthaceae	Endemic	Vulnerable	\N
685	Manglas	Phyllanthus balgooyi Petra Hoffm. & A.J.M.Baker	Phyllanthaceae	Indigenous	Vulnerable	\N
686	\N	Phyllanthus glochidioides Elmer	Phyllanthaceae	Endemic	Vulnerable	\N
687	Mindoro Pine	Pinus merkusii Jungh. & Vriese	Pinaceae	Indigenous	Vulnerable	\N
688	\N	Cyrtochloa puser (Gamble) S.Dransf	Poaceae	Endemic	Vulnerable	\N
689	\N	Hedyotis capitellata Wall. ex G.Don	Rubiaceae	Indigenous	Vulnerable	\N
690	Palawan Bíkal	Dinochloa palawanensis S.Dransf	Poaceae	Endemic	Vulnerable	\N
691	\N	Ischaemum glaucescens Merr.	Poaceae	Endemic	Vulnerable	\N
692	Igem-Pugot	Podocarpus lophatus de Laub.	Podocarpaceae	Endemic	Vulnerable	\N
693	Dilang-Butiki	Podocarpus polystachyus R.Br. ex Endl.	Podocarpaceae	Indigenous	Vulnerable	\N
694	Malakauayan	Podocarpus rumphii Blume	Podocarpaceae	Indigenous	Vulnerable	\N
695	\N	Securidaca atroviolacea Elmer	Polygalaceae	Endemic	Vulnerable	\N
696	Libagod	Aglaomorpha acuminata (Willd.) Hovenkamp	Polypodiaceae	Indigenous	Vulnerable	\N
697	\N	Aglaomorpha cornucopia (Copel.) Roos	Polypodiaceae	Endemic	Vulnerable	\N
698	\N	Aglaomorpha meyeniana Schott	Polypodiaceae	Endemic	Vulnerable	\N
699	\N	Aglaomorpha splendens (Hook. & Bauer) Copel	Polypodiaceae	Endemic	Vulnerable	\N
700	Saraukong	Aglaomorpha heraclea (Kunze) Copel.	Polypodiaceae	Indigenous	Vulnerable	\N
701	\N	Aglaomorpha pilosa (J.Sm. ex Kunze) Copel.	Polypodiaceae	Indigenous	Vulnerable	\N
702	\N	Microsorum sarawakense (Baker) Holttum	Polypodiaceae	Indigenous	Vulnerable	\N
703	Turko	Pyrrosia splendens (Presl) Ching	Polypodiaceae	Endemic	Vulnerable	\N
704	Cacam-Cam	Selliguea sagitta (Christ) Fraser-Jenk.	Polypodiaceae	Endemic	Vulnerable	\N
705	\N	Xiphopterella nudicarpa (P.M.Zamora & Co) Parris	Polypodiaceae	Indigenous	Vulnerable	\N
706	Samadódai	Ardisia iwahigensis Elmer	Primulaceae	Endemic	Vulnerable	\N
707	Roman Tagpo	Ardisia romanii Elmer	Primulaceae	Endemic	Vulnerable	\N
708	Tagpo	Ardisia squamulosa C Presl	Primulaceae	Endemic	Vulnerable	\N
709	Tágpong-Kapalan	Ardisia taytayensis Merr.	Primulaceae	Endemic	Vulnerable	\N
710	\N	Psilotum nudum (L.) Griseb.	Psilotaceae	Indigenous	Vulnerable	\N
711	\N	Adiantum cupreum Copel.	Pteridaceae	Endemic	Vulnerable	\N
712	\N	Adiantum monosorum Baker	Pteridaceae	Indigenous	Vulnerable	\N
713	\N	Adiantum stenochlamys Baker	Pteridaceae	Indigenous	Vulnerable	\N
714	\N	Pteris brevis Copel.	Pteridaceae	Endemic	Vulnerable	\N
715	\N	Pteris dataensis Copel.	Pteridaceae	Endemic	Vulnerable	\N
716	\N	Pteris macgregorii Copel.	Pteridaceae	Endemic	Vulnerable	\N
717	\N	Pteris micracantha Copel.	Pteridaceae	Endemic	Vulnerable	\N
718	\N	Pteris mucronulata Copel.	Pteridaceae	Endemic	Vulnerable	\N
719	\N	Pteris ramosii Copel.	Pteridaceae	Endemic	Vulnerable	\N
720	\N	Pteris squamipes Copel.	Pteridaceae	Endemic	Vulnerable	\N
721	\N	Pteris taenitis Copel.	Pteridaceae	Indigenous	Vulnerable	\N
722	\N	Taenitis cordata (Gaudich.) Holttum	Pteridaceae	Indigenous	Vulnerable	\N
723	Malabóo	Rafflesia lagascae Blanco	Rafflesiaceae	Endemic	Vulnerable	\N
724	\N	Rafflesia leonardi Barcelona & Pelser	Rafflesiaceae	Endemic	Vulnerable	\N
725	\N	Rafflesia lobata Galang & Madulid	Rafflesiaceae	Endemic	Vulnerable	\N
726	\N	Rhachidosorus stramineus (Copel.) Ching	Rhachidosoraceae	Indigenous	Vulnerable	\N
727	\N	Ventilago palawanensis Elmer	Rhamnaceae	Endemic	Vulnerable	\N
728	\N	Ziziphus palawanensis Elmer	Rhamnaceae	Endemic	Vulnerable	\N
729	Gúpit	Prunus pulgarensis (Elmer) Kalkm.	Rosaceae	Endemic	Vulnerable	\N
730	Bakad Pula	Prunus rubiginosa (Elmer) Kalkm.	Rosaceae	Endemic	Vulnerable	\N
731	Kanumog	Prunus subglabra (Merr.) Kalkm.	Rosaceae	Endemic	Vulnerable	\N
732	Lagong-Liitan	Prunus grisea (Blume) Kalkm.	Rosaceae	Indigenous	Vulnerable	\N
733	\N	Antirhea livida Elmer	Rubiaceae	Endemic	Vulnerable	\N
734	\N	Antirhea ternata Chaw	Rubiaceae	Endemic	Vulnerable	\N
735	\N	Exallage perhispida (Elmer) Bremek.	Rubiaceae	Endemic	Vulnerable	\N
736	\N	Gardenia ornata K.M.Wong	Rubiaceae	Endemic	Vulnerable	\N
737	\N	Gardenia vulcanica K.M.Wong	Rubiaceae	Endemic	Vulnerable	\N
738	\N	Hydnophytum angustifolium Merr.	Rubiaceae	Endemic	Vulnerable	\N
739	\N	Hydnophytum brachycladum Merr.	Rubiaceae	Endemic	Vulnerable	\N
740	\N	Hydnophytum intermedium Elmer	Rubiaceae	Endemic	Vulnerable	\N
741	\N	Hydnophytum membranaceum Merr.	Rubiaceae	Endemic	Vulnerable	\N
742	\N	Hydnophytum mindanaense Elmer	Rubiaceae	Endemic	Vulnerable	\N
743	\N	Hydnophytum mindorense Merr.	Rubiaceae	Endemic	Vulnerable	\N
744	\N	Hydnophytum nitidum Merr.	Rubiaceae	Endemic	Vulnerable	\N
745	Katudai	Mussaenda acuminatissima Merr.	Rubiaceae	Endemic	Vulnerable	\N
746	Bungag	Mussaenda attenuifolia Elmer	Rubiaceae	Endemic	Vulnerable	\N
747	\N	Mussaenda chlorantha Merr.	Rubiaceae	Endemic	Vulnerable	\N
748	Sigidago	Mussaenda setosa Merr.	Rubiaceae	Endemic	Vulnerable	\N
749	\N	Mussaenda grandifolia Elmer	Rubiaceae	Endemic	Vulnerable	\N
750	\N	Mussaenda lanata C.B.Rob	Rubiaceae	Endemic	Vulnerable	\N
751	Agboi	Mussaenda magallanensis Elmer	Rubiaceae	Endemic	Vulnerable	\N
752	\N	Mussaenda milleri Elmer	Rubiaceae	Endemic	Vulnerable	\N
753	Buyan	Mussaenda nervosa Elmer	Rubiaceae	Endemic	Vulnerable	\N
754	Buai	Mussaenda scandens Elmer	Rubiaceae	Endemic	Vulnerable	\N
755	Ananayop	Mussaenda vidalii Elmer	Rubiaceae	Endemic	Vulnerable	\N
756	\N	Myrmephytum beccarii Elmer	Rubiaceae	Endemic	Vulnerable	\N
757	Malagusókan	Pavetta phanerophlebia Merr	Rubiaceae	Endemic	Vulnerable	\N
758	Gusókan-Kaláuang	Pavetta subferruginea Merr	Rubiaceae	Endemic	Vulnerable	\N
759	\N	Psychotria balabacensis Merr.	Rubiaceae	Endemic	Vulnerable	\N
760	\N	Psychotria iwahigensis Elmer	Rubiaceae	Endemic	Vulnerable	\N
761	Gumugmug	Psychotria pyramidata Elmer	Rubiaceae	Endemic	Vulnerable	\N
762	Bunkól-Kaláuang	Timonius ferrugineus Merr	Rubiaceae	Endemic	Vulnerable	\N
763	Bunkól	Timonius palawanensis Elmer	Rubiaceae	Endemic	Vulnerable	\N
764	\N	Urophyllum elliptifolium Merr.	Rubiaceae	Endemic	Vulnerable	\N
765	Tarungatau	Melicope lunu-ankenda (Gaertn.) T.G.Hartley	Rutaceae	Indigenous	Vulnerable	\N
766	Pulgar Kámal	Melicope pulgarensis (Elmer) T.G.Hartley	Rutaceae	Endemic	Vulnerable	\N
767	Agsum	Exocarpos longifolius (L.) Endl.	Santalaceae	Indigenous	Vulnerable	\N
768	Mamoko	Glenniea philippinensis (Radlk.) Leenh.	Sapindaceae	Indigenous	Vulnerable	\N
769	Palawan Sarakag	Glenniea thorelii (Pierre) Leenh.	Sapindaceae	Indigenous	Vulnerable	\N
770	Alahan-Puti	Guioa discolor Radlk.	Sapindaceae	Endemic	Vulnerable	\N
771	Ulas	Guioa myriadenia Radlk.	Sapindaceae	Endemic	Vulnerable	\N
772	Uyos	Guioa truncata Radlk.	Sapindaceae	Endemic	Vulnerable	\N
774	Panungaian	Nephelium cuspidatum Blume	Sapindaceae	Indigenous	Vulnerable	\N
775	Kapulasan	Nephelium ramboutan-ake (Labill.) Leenh.	Sapindaceae	Indigenous	Vulnerable	\N
779	Alálud	Pleioluma foxworthyi (Elmer) Swenson	Sapotaceae	Endemic	Vulnerable	\N
781	\N	Selaginella atimonanensis BC Tan & Jermy	Selaginellaceae	Endemic	Vulnerable	\N
782	Fernando Mabunót	Gomphandra fernandoi Schori & Utteridge	Stemonuraceae	Endemic	Vulnerable	\N
783	Amugauen	Taxus sumatrana (Miq.) de Laub.	Taxaceae	Indigenous	Vulnerable	\N
784	\N	Aenigmopteris mindanaensis Holttum	Tectariaceae	Endemic	Vulnerable	\N
785	Haikan	Camellia lanceolata (Blume) Seem.	Theaceae	Indigenous	Vulnerable	\N
786	\N	Schima wallichii Choisy	Theaceae	Endemic	Vulnerable	\N
787	\N	Chingia pricei Holttum	Thelypteridaceae	Endemic	Vulnerable	\N
788	\N	Coryphopteris squamipes (Copel.) Holttum	Thelypteridaceae	Endemic	Vulnerable	\N
789	\N	Cyclogramma auriculata (J.Sm.) Ching.	Thelypteridaceae	Indigenous	Vulnerable	\N
790	\N	Cyclosorus paucipaleatus (Holttum) Mazumdar & Mukhop.	Thelypteridaceae	Endemic	Vulnerable	\N
791	\N	Nannothelypteris aoristisora (Harr.) Holttum	Thelypteridaceae	Endemic	Vulnerable	\N
792	\N	Nannothelypteris camarinensis Holttum	Thelypteridaceae	Endemic	Vulnerable	\N
793	\N	Nannothelypteris inaequilobata Holttum	Thelypteridaceae	Endemic	Vulnerable	\N
794	\N	Nannothelypteris nervosa (Fee) Holttum	Thelypteridaceae	Endemic	Vulnerable	\N
795	\N	Nannothelypteris philippina (C Presl) Holttum	Thelypteridaceae	Endemic	Vulnerable	\N
796	\N	Pronephrium bulusanicum (Holttum) Holttum	Thelypteridaceae	Endemic	Vulnerable	\N
797	\N	Pronephrium hosei (Baker) Holttum	Thelypteridaceae	Endemic	Vulnerable	\N
798	\N	Pronephrium solsonicum Holttum	Thelypteridaceae	Endemic	Vulnerable	\N
799	\N	Sphaerostephanos hernaezii Holttum	Thelypteridaceae	Endemic	Vulnerable	\N
800	\N	Sphaerostephanos angustifolius (C.Presl) Holttum	Thelypteridaceae	Indigenous	Vulnerable	\N
801	Mangód	Aquilaria apiculata Merr.	Thymelaeaceae	Endemic	Vulnerable	\N
802	Binúkat	Aquilaria brachyantha (Merr.) Hallier f	Thymelaeaceae	Endemic	Vulnerable	\N
803	Agodódan	Aquilaria citrinaecarpa (Elmer) Hallier f	Thymelaeaceae	Endemic	Vulnerable	\N
804	Bútlong-Liítan	Aquilaria parvifolia (Quisumb.) Ding Hou	Thymelaeaceae	Endemic	Vulnerable	\N
805	Makólan	Aquilaria urdanetensis (Elmer) Hallier f	Thymelaeaceae	Endemic	Vulnerable	\N
806	Butlo	Aquilaria cumingiana (Decne.) Ridley	Thymelaeaceae	Indigenous	Vulnerable	\N
807	Palisan	Aquilaria filaria (Oken) Merr.	Thymelaeaceae	Indigenous	Vulnerable	\N
808	\N	Elatostema palawanense C.B.Rob	Urticaceae	Endemic	Vulnerable	\N
809	\N	Alpinia elegans (C.Presl) K.Schum	Zingiberaceae	Endemic	Vulnerable	\N
810	Langkawás	Alpinia foxworthyi Ridl	Zingiberaceae	Endemic	Vulnerable	\N
811	Parapat	Alpinia paradoxa (Ridl.) Merr.	Zingiberaceae	Endemic	Vulnerable	\N
812	\N	Amomum palawanense Elmer	Zingiberaceae	Endemic	Vulnerable	\N
813	\N	Kaempferia philippinensis Merr	Zingiberaceae	Endemic	Vulnerable	\N
814	Banai	Leptosolena haenkei C Presl	Zingiberaceae	Endemic	Vulnerable	\N
815	\N	Hypoestes merrillii C.B.Clarke ex Elmer	Acanthaceae	Endemic	Other Threatened Species	\N
816	\N	Hypoestes palawanensis C.B.Clarke	Acanthaceae	Endemic	Other Threatened Species	\N
817	\N	Sphaerostephanos spenceri (Christ) Holttum	Thelypteridaceae	Endemic	Other Threatened Species	\N
818	Tiagang	Lepidagathis amaranthoides Elmer	Acanthaceae	Endemic	Other Threatened Species	\N
820	\N	Artabotrys vidaliana Elmer	Annonaceae	Endemic	Other Threatened Species	\N
821	Lanutan	Mitrephora lanotan (Blanco) Merr.	Annonaceae	Endemic	Other Threatened Species	\N
822	Amunat	Orophea cumingiana S.Vidal	Annonaceae	Indigenous	Other Threatened Species	\N
823	\N	Alyxia linearis Markgr	Apocynaceae	Endemic	Other Threatened Species	\N
824	Elmer Pasnit	Kibatalia elmeri Woodson	Apocynaceae	Endemic	Other Threatened Species	\N
825	Hanley Lanéte	Wrightia hanleyi Elmer	Apocynaceae	Endemic	Other Threatened Species	\N
826	\N	Cryptocoryne usteriana Engl.	Araceae	Endemic	Other Threatened Species	\N
827	\N	Rhaphidophora korthalsii Schott	Araceae	Endemic	Other Threatened Species	\N
828	Batbat	Arenga brevipes Becc.	Arecaceae	Indigenous	Other Threatened Species	\N
829	\N	Calamus daemonoropoides Fernando	Arecaceae	Endemic	Other Threatened Species	\N
830	Palásan	Calamus merrillii Becc.	Arecaceae	Endemic	Other Threatened Species	\N
831	Ditaán	Calamus mollis Blanco	Arecaceae	Endemic	Other Threatened Species	\N
832	\N	Calamus erinaceus (Becc.) Becc.	Arecaceae	Indigenous	Other Threatened Species	\N
833	Labsikan	Calamus longipes Griff.	Arecaceae	Indigenous	Other Threatened Species	\N
834	Voyavoi	Phoenix loureiroi Kunth	Arecaceae	Indigenous	Other Threatened Species	\N
835	Anahau	Saribus rotundifolius (Lam.) Blume	Arecaceae	Indigenous	Other Threatened Species	\N
836	\N	Diplazium sibuyanense (Copel.) Alderw.	Athyriaceae	Endemic	Other Threatened Species	\N
837	\N	Diplazium calliphyllum (Copel.) M.G.Price	Athyriaceae	Indigenous	Other Threatened Species	\N
838	\N	Diplazium maximum (D.Don) C.Chr.	Athyriaceae	Indigenous	Other Threatened Species	\N
839	\N	Diplazium vestitum C.Presl	Athyriaceae	Indigenous	Other Threatened Species	\N
840	\N	Begonia blancii M.Hughes & C.-I.Peng	Begoniaceae	Endemic	Other Threatened Species	\N
841	\N	Begonia lagunensis Elmer	Begoniaceae	Endemic	Other Threatened Species	\N
844	Lunai	Dacryodes rostrata (Blume) H.J.Lam	Burseraceae	Indigenous	Other Threatened Species	\N
845	Mountain Agoho	Gymnostoma rumphianum (Jungh. ex Vriese) L.A.S.Johnson	Casuarinaceae	Indigenous	Other Threatened Species	\N
846	\N	Connarus culionensis Merr.	Connaraceae	Indigenous	Other Threatened Species	\N
847	Malatapai	Alangium longiflorum Merr.	Cornaceae	Indigenous	Other Threatened Species	\N
848	\N	Davallia denticulata (Burm.f.) Mett. ex Kuhn	Davalliaceae	Indigenous	Other Threatened Species	\N
849	\N	Davallia embolostegia Copel.	Davalliaceae	Indigenous	Other Threatened Species	\N
850	\N	Davallia lorrainii Hance	Davalliaceae	Indigenous	Other Threatened Species	\N
851	\N	Davallia solida (G.Forst.) Sw.	Davalliaceae	Indigenous	Other Threatened Species	\N
852	Paláli	Dillenia marsupialis Hoogland	Dilleniaceae	Endemic	Other Threatened Species	\N
853	Katmon-Kalabau	Dillenia reifferscheidia Fern.-Villar	Dilleniaceae	Endemic	Other Threatened Species	\N
854	\N	Stenolepia tristis (Blume) Alderw.	Dryopteridaceae	Indigenous	Other Threatened Species	\N
855	Ánang-Apógan	Diospyros calcicola Merr.	Ebenaceae	Endemic	Other Threatened Species	\N
858	\N	Diospyros transita (Bakh.) Kosterm	Ebenaceae	Endemic	Other Threatened Species	\N
859	Tandikan	Diospyros wrayi King & Gamble	Ebenaceae	Indigenous	Other Threatened Species	\N
860	Dinagat Konakan	Elaeocarpus dinagatensis Merr.	Elaeocarpaceae	Endemic	Other Threatened Species	\N
861	Nabol	Elaeocarpus gigantifolius Elmer	Elaeocarpaceae	Endemic	Other Threatened Species	\N
862	\N	Polyosma pulgarensis Elmer	Escalloniaceae	Endemic	Other Threatened Species	\N
863	Kulis-Daga	Dimorphocalyx denticulatus Merr.	Euphorbiaceae	Indigenous	Other Threatened Species	\N
864	Amublit	Macaranga congestiflora Merr.	Euphorbiaceae	Endemic	Other Threatened Species	\N
865	Tanglin	Adenanthera intermedia Merr.	Fabaceae	Endemic	Other Threatened Species	\N
866	Dalidigan	Entada parvifolia Merr.	Fabaceae	Endemic	Other Threatened Species	\N
867	Gugo	Entada phaseoloides (L.) Merr.	Fabaceae	Indigenous	Other Threatened Species	\N
868	\N	Entada rheedii Sprengel	Fabaceae	Indigenous	Other Threatened Species	\N
869	Baloktot	Luzonia purpurea Elmer	Fabaceae	Endemic	Other Threatened Species	\N
870	Balók	Millettia merrillii Perkins	Fabaceae	Endemic	Other Threatened Species	\N
871	Butad	Parkia speciosa Hassk.	Fabaceae	Indigenous	Other Threatened Species	\N
872	Kilog	Lithocarpus luzoniensis (Merr.) Rehd.	Fagaceae	Endemic	Other Threatened Species	\N
873	Mangasiriki	Lithocarpus ovalis (Blanco) Rehd.	Fagaceae	Endemic	Other Threatened Species	\N
874	Pungo-Pungo	Quercus merrillii Seem.	Fagaceae	Indigenous	Other Threatened Species	\N
875	\N	Quercus subsericea A.Camus	Fagaceae	Indigenous	Other Threatened Species	\N
876	\N	Monophyllaea longipes Kraenzl.	Gesneriaceae	Endemic	Other Threatened Species	\N
877	Sabongaiahon	Monophyllaea merrilliana Kraenzl.	Gesneriaceae	Endemic	Other Threatened Species	\N
878	Koron-Koron	Hernandia ovigera L.	Hernandiaceae	Indigenous	Other Threatened Species	\N
879	Kalalapo-Bulan	Plectranthus apoensis (Elmer) H.Keng	Lamiaceae	Indigenous	Other Threatened Species	\N
880	Bungbungtid	Plectranthus merrillii H.Keng	Lamiaceae	Indigenous	Other Threatened Species	\N
882	Tambulian	Eusideroxylon zwageri Teijsm. & Binn.	Lauraceae	Indigenous	Other Threatened Species	\N
883	\N	Litsea varians (Blume) Boerl.	Lauraceae	Endemic	Other Threatened Species	\N
884	Patúgau	Neolitsea incana Elmer	Lauraceae	Endemic	Other Threatened Species	\N
885	Kulilísiau	Persea philippinensis (Merr.) Elmer	Lauraceae	Endemic	Other Threatened Species	\N
886	Pakong Kalabaw	Angiopteris palmiformis(Cav.) C. Chr.	Marattiaceae	Indigenous	Other Threatened Species	\N
887	Alauihau	Aglaia cumingiana Turcz.	Meliaceae	Endemic	Other Threatened Species	\N
889	\N	Sphaerostephanos stenodontus (Copel.) Holttum	Thelypteridaceae	Endemic	Other Threatened Species	\N
890	\N	Sphaerostephanos tephrophyllus (Copel.) Holttum	Thelypteridaceae	Endemic	Other Threatened Species	\N
891	Balubar	Aglaia rimosa (Blanco) Merr.	Meliaceae	Indigenous	Other Threatened Species	\N
892	Batukanag	Aglaia smithii Koord.	Meliaceae	Indigenous	Other Threatened Species	\N
893	Alamag	Aglaia aherniana Perkins	Meliaceae	Endemic	Other Threatened Species	\N
894	Manabiog	Aglaia costata Elmer ex Merr.	Meliaceae	Endemic	Other Threatened Species	\N
895	Kangko	Aphanamixis polystachya (Wall.) R.Parker	Meliaceae	Indigenous	Other Threatened Species	\N
896	Paluahan, Kayatau	Dysoxylum oppositifolium F.Muell.	Meliaceae	Indigenous	Other Threatened Species	\N
897	Ambal	Pycnarrhena manillensis S.Vidal	Menispermaceae	Endemic	Other Threatened Species	\N
898	Kalulot	Artocarpus rubrovenius Warb.	Moraceae	Endemic	Other Threatened Species	\N
899	Duhao	Knema alvarezii Merr.	Myristicaceae	Endemic	Other Threatened Species	\N
900	Libago	Knema stenocarpa Warb.	Myristicaceae	Endemic	Other Threatened Species	\N
901	Basilan Duguan	Myristica basilanica de Wilde	Myristicaceae	Endemic	Other Threatened Species	\N
902	\N	Myristica frugifera de Wilde	Myristicaceae	Endemic	Other Threatened Species	\N
903	\N	Myristica longipetiolata de Wilde	Myristicaceae	Endemic	Other Threatened Species	\N
905	\N	Myristica pilosigemma de Wilde	Myristicaceae	Endemic	Other Threatened Species	\N
906	Tigang-Liitan	Kania microphylla (Quisumb. & Merr.) Peter G Wilson	Myrtaceae	Endemic	Other Threatened Species	\N
907	Sambulanan	Kania urdanetensis (Elmer) Peter G Wilson	Myrtaceae	Endemic	Other Threatened Species	\N
908	Magadhan	Metrosideros halconensis (Merr.) Dawson	Myrtaceae	Endemic	Other Threatened Species	\N
909	Amtuk	Syzygium cagayanense (Merr.) Merr.	Myrtaceae	Endemic	Other Threatened Species	\N
910	Capoas Lamuto	Syzygium capoasense (Merr.) Merr.	Myrtaceae	Endemic	Other Threatened Species	\N
911	Lakangan	Syzygium ciliato-setosum (Merr.) Merr.	Myrtaceae	Endemic	Other Threatened Species	\N
912	Salakadan	Syzygium densinervium (Merr.) Merr.	Myrtaceae	Endemic	Other Threatened Species	\N
913	Tuál	Syzygium longissimum (Merr.) Merr.	Myrtaceae	Endemic	Other Threatened Species	\N
914	Kalógkog-Dágat	Syzygium subrotundifolium (C Robinson) Merr.	Myrtaceae	Endemic	Other Threatened Species	\N
915	Tamo	Syzygium confertum (Korth.) Merr. & L.M.Perry	Myrtaceae	Indigenous	Other Threatened Species	\N
916	Lauig-Lauigan	Syzygium panduriforme (Elmer) Merr.	Myrtaceae	Indigenous	Other Threatened Species	\N
917	Tígang-Habá	Tristaniopsis oblongifolia (Merr.) Peter G. Wilson & Waterhouse	Myrtaceae	Endemic	Other Threatened Species	\N
918	\N	Osmunda banksiifolia (C.Presl) Kuhn	Osmundaceae	Indigenous	Other Threatened Species	\N
919	Pandan	Benstonea affinis (Kurz) Callm. & Buerki	Pandanaceae	Indigenous	Other Threatened Species	\N
920	Olango	Pandanus basilocularis Martelli	Pandanaceae	Endemic	Other Threatened Species	\N
921	\N	Pentaphragma grandiflorum Kurz	Pentaphragmataceae	Indigenous	Other Threatened Species	\N
922	Anislag	Flueggea flexuosa Müll.Arg.	Phyllanthaceae	Indigenous	Other Threatened Species	\N
923	\N	Piper caninum Blume	Piperaceae	Indigenous	Other Threatened Species	\N
924	\N	Piper retrofractum Vahl	Piperaceae	Indigenous	Other Threatened Species	\N
925	Albón	Pittosporum ramosii Merr.	Pittosporaceae	Endemic	Other Threatened Species	\N
926	Abkel	Pittosporum resiniferum Hemsl.	Pittosporaceae	Indigenous	Other Threatened Species	\N
927	Bikal	Dinochloa acutiflora (Munro) S.Dransf.	Poaceae	Indigenous	Other Threatened Species	\N
928	Igem	Dacrycarpus imbricatus (Blume) de Laub.	Podocarpaceae	Indigenous	Other Threatened Species	\N
929	Malasuklai	Dacrydium pectinatum de Laub.	Podocarpaceae	Indigenous	Other Threatened Species	\N
930	Malaalmaciga	Nageia wallichiana (C.Presl) Kuntze	Podocarpaceae	Indigenous	Other Threatened Species	\N
931	\N	Arthromeris mairei (Brause) Ching	Polypodiaceae	Indigenous	Other Threatened Species	\N
932	Ginárai	Discocalyx palawanensis Elmer ex Merr.	Primulaceae	Endemic	Other Threatened Species	\N
933	Gakákan	Drypetes falcata (Merr.) Pax & K.Hoffm.	Putranjivaceae	Endemic	Other Threatened Species	\N
934	Tombong-Uak	Drypetes rhakodiskos (Hassk.) Airy Shaw	Putranjivaceae	Indigenous	Other Threatened Species	\N
935	Lumuluas	Ziziphus hutchinsonii Merr.	Rhamnaceae	Endemic	Other Threatened Species	\N
936	Balakat	Ziziphus talanai (Blanco) Merr.	Rhamnaceae	Endemic	Other Threatened Species	\N
937	Bakauan-Gubat	Carallia brachiata (Lour.) Merr.	Rhizophoraceae	Indigenous	Other Threatened Species	\N
938	Kuyaob	Rosa luciae Franch. & Rochebr. ex Crépin	Rosaceae	Indigenous	Other Threatened Species	\N
939	Pauikan	Rosa transmorrisonensis Hayata	Rosaceae	Indigenous	Other Threatened Species	\N
940	Tukong	Rubus heterosepalus Merr.	Rosaceae	Endemic	Other Threatened Species	\N
941	Pugaru	Hydnophytum leytense Merr.	Rubiaceae	Endemic	Other Threatened Species	\N
942	\N	Hydnophytum philippinense Becc.	Rubiaceae	Endemic	Other Threatened Species	\N
943	Malabúyon	Mussaenda palawanensis Merr.	Rubiaceae	Endemic	Other Threatened Species	\N
944	Kalomata	Clausena brevistyla Oliv.	Rutaceae	Indigenous	Other Threatened Species	\N
945	Dudua	Hydnocarpus alcalae C DC	Salicaceae	Endemic	Other Threatened Species	\N
946	Mansalay	Xylosma palawanensis DM Mendoza	Salicaceae	Endemic	Other Threatened Species	\N
947	Kaninging	Guioa bicolor Merr.	Sapindaceae	Endemic	Other Threatened Species	\N
948	Bataan Tagátoi	Palaquium bataanense Merr.	Sapotaceae	Endemic	Other Threatened Species	\N
949	\N	Tectaria adenophora Copel.	Tectariaceae	Endemic	Other Threatened Species	\N
950	\N	Tectaria tabonensis M.G.Price	Tectariaceae	Endemic	Other Threatened Species	\N
951	\N	Sphaerostephanos cartilagidens P Zamora & Co	Thelypteridaceae	Endemic	Other Threatened Species	\N
952	\N	Sphaerostephanos dichrotrichoides (Alderw.) Holttum	Thelypteridaceae	Endemic	Other Threatened Species	\N
953	\N	Sphaerostephanos irayensis (Copel.) Holttum	Thelypteridaceae	Endemic	Other Threatened Species	\N
954	\N	Sphaerostephanos williamsii (Copel.) Holttum	Thelypteridaceae	Endemic	Other Threatened Species	\N
955	Palupo	Wikstroemia retusa A.Gray	Thymelaeaceae	Indigenous	Other Threatened Species	\N
956	Lapnai	Astrothalamus reticulatus (Wedd.) C.B.Rob.	Urticaceae	Indigenous	Other Threatened Species	\N
957	Agbab	Vanoverberghia sepulchrei Merr.	Zingiberaceae	Endemic	Other Threatened Species	\N
959	\N	Calophyllum laticostatum P.F.Stevens	Calophyllaceae	Indigenous	Vulnerable	\N
960	Coral Plant	Balanophora coralliformis Pelser, Tandang & Barcelona	Balanophoraceae	Endemic	Critically Endangered	\N
961	\N	Paphiopedilum philippinense (Rchb.f.) Stein	Orchidaceae	Endemic	Critically Endangered	\N
962	\N	Rafflesia mixta Barcelona, Manting, Arbolonio et al.	Rafflesiaceae	Endemic	Critically Endangered	\N
963	\N	Goniothalamus palawanensis C.C.Tang & R.M.K.Saunders	Annonaceae	Endemic	Endangered	\N
964	\N	Bulbophyllum facetum Garay, Hamer & Siegerist	Orchidaceae	Endemic	Endangered	\N
965	\N	Grammatophyllum martae Quisumb. ex Valmayor & D.Tiu	Orchidaceae	Endemic	Endangered	\N
966	\N	Renanthera philippinensis (Ames & Quisumb.) L.O.Williams	Orchidaceae	Endemic	Endangered	\N
967	\N	Pseuderanthemum minutiflorum (Elmer) Merr.	Acanthaceae	Endemic	Vulnerable	\N
968	\N	Codonoboea corrugata (Mendum) D.J.Middleton	Gesneriaceae	Endemic	Vulnerable	\N
969	\N	Lindsaea hamiguitanensis Karger & V.B.Amoroso	Lindsaeaceae	Endemic	Vulnerable	\N
970	\N	Phrynium minutiflorum Suksathan & Borchs.	Maranthaceae	Endemic	Vulnerable	\N
971	\N	Dimeria chloridiformis (Gaudich) K.Schum. & Lauterb.	Poaceae	Endemic	Vulnerable	\N
972	\N	Rhododendron jasminiflorum Hook.	Ericaceae	Endemic	Vulnerable	\N
974	\N	Phanera semibifida (Roxb.)	Fabaceae	Endemic	Vulnerable	\N
975	Ungang	Plectocomia elongata Mart. ex Blume	Arecaceae	Endemic	Other Threatened Species	\N
976	Rambutan; Usau	Nephelium lappaceum L. var. lappaceum.	Sapindaceae	Indigenous	Vulnerable	\N
977	Bulauan	Nephelium lappaceum L. var. pallens (Hiern) Leenh.	Sapindaceae	Indigenous	Vulnerable	\N
978	Pamitóyen	Calophyllum pentapetalum (Blanco) Merr var. pentapetalum	Calophyllaceae	Endemic	Vulnerable	\N
567	Bagilumbáng	Reutealis trisperma (Blanco) Airy Shaw	Euphorbiaceae	Endemic	Vulnerable	yes
979	Bintaúgan	Calophyllum pentapetalum (Blanco) Merr var. pulgarense (Elmer) P.F.Stevens	Calophyllaceae	Endemic	Vulnerable	\N
980	\N	Vaccinium palawanense Merr. var. foxworthyi (H.F.Copel.) Sleum.	Ericaceae	Endemic	Vulnerable	\N
981	Iualus	Vaccinium palawanense Merr. var. palawanense	Ericaceae	Endemic	Vulnerable	\N
984	Magabuyo	Celtis luzonica	Cannabaceae	\N	\N	yes
985	Katmon bayani	Dillenia megalantha	Dilleniaceae	\N	\N	yes
986	Katmon	Dillenia philippinensis	Dilleniaceae	\N	\N	yes
987	Kamagong	Diospyros blancoi	Ebenaceae	\N	\N	yes
988	Malapanau	Dipterocarpus kerrii	Ebenaceae	\N	\N	yes
989	Hagakhak	Dipterocarpus validus	Dipterocarpaceae	\N	\N	yes
990	Lamio	Dracontomelon edule	Dipterocarpaceae	\N	\N	yes
991	Bagtikan	Parashorea malaanonan	Dipterocarpaceae	\N	\N	yes
992	Guijo	Shorea guiso	Dipterocarpaceae	\N	\N	yes
993	Kalunti	Shorea hopeifolia	Dipterocarpaceae	\N	\N	yes
994	Mindanao Narig	Vatica mindanensis	Dipterocarpaceae	\N	\N	yes
995	Mayapis	Vatica palosapis	Dipterocarpaceae	\N	\N	yes
37	Basilan Yakal	Hopea basilanica Foxw.	Dipterocarpaceae	Endemic	Critically Endangered	yes
38	Mindanao Narek	Hopea brachyptera (Foxw.) Sloot.	Dipterocarpaceae	Endemic	Critically Endangered	yes
39	Cagayan Narek	Hopea cagayanensis (Foxw.) Sloot.	Dipterocarpaceae	Endemic	Critically Endangered	yes
40	Dalindingan	Hopea foxworthyi Elmer	Dipterocarpaceae	Endemic	Critically Endangered	yes
41	Yakal-Kaliot	Hopea malibato Foxw.	Dipterocarpaceae	Endemic	Critically Endangered	yes
42	Yakal-Magasusu	Hopea mindanensis Foxw.	Dipterocarpaceae	Endemic	Critically Endangered	yes
43	Gisok-Gisok	Hopea philippinensis Dyer	Dipterocarpaceae	Endemic	Critically Endangered	yes
44	Quisumbing Gisok	Hopea quisumbingiana Gutierrez	Dipterocarpaceae	Endemic	Critically Endangered	yes
45	Samar Gisok	Hopea samarensis Gutierrez	Dipterocarpaceae	Endemic	Critically Endangered	yes
46	Yakal	Shorea astylosa Foxw.	Dipterocarpaceae	Endemic	Critically Endangered	yes
47	Yakal-Malibato	Shorea malibato Foxw.	Dipterocarpaceae	Endemic	Critically Endangered	yes
48	Kaladis Narig	Vatica elliptica Foxw.	Dipterocarpaceae	Endemic	Critically Endangered	yes
49	Thick-Leafed Narig	Vatica pachyphylla Merr.	Dipterocarpaceae	Endemic	Critically Endangered	yes
52	Malinoag	Diospyros brideliifolia Elmer	Ebenaceae	Endemic	Critically Endangered	yes
53	Itom-Itom	Diospyros longiciliata Merr.	Ebenaceae	Endemic	Critically Endangered	yes
54	Ponce Kamagong	Diospyros poncei Merr.	Ebenaceae	Endemic	Critically Endangered	yes
72	Kanining Peneras	Aglaia pyriformis Merr.	Meliaceae	Endemic	Critically Endangered	yes
75	Bago-Adlau	Xanthostemon philippinensis Merr.	Myrtaceae	Endemic	Critically Endangered	yes
80	Sierra Madre Mangkono	Xanthostemon fruticosus Peter G Wilson & Co	Myrtaceae	Endemic	Critically Endangered	yes
257	Mindanao Palosapis	Anisoptera costata Korth.	Dipterocarpaceae	Indigenous	Endangered	yes
258	Basilan Apitong	Dipterocarpus eurhynchus Miq.	Dipterocarpaceae	Indigenous	Endangered	yes
259	Manggachapui	Hopea acuminata Merr.	Dipterocarpaceae	Endemic	Endangered	yes
260	Tiaong	Shorea ovata Dyer ex Brandis	Dipterocarpaceae	Indigenous	Endangered	yes
261	Narig Laut	Vatica maritima Slooten	Dipterocarpaceae	Indigenous	Endangered	yes
268	Tindalo	Afzelia rhomboidea (Blanco) S.Vidal	Fabaceae	Indigenous	Endangered	yes
269	Manggis	Koompassia excelsa (Becc.) Taub.	Fabaceae	Indigenous	Endangered	yes
270	Supa	Sindora supa Merr.	Fabaceae	Endemic	Endangered	yes
272	Kamatog	Sympetalandra densiflora (Elmer) Steenis	Fabaceae	Endemic	Endangered	yes
281	Bunglas, Philippine Teak	Tectona philippinensis Benth. & Hook.f.	Lamiaceae	Endemic	Endangered	yes
282	Molave	Vitex parviflora Juss.	Lamiaceae	Indigenous	Endangered	yes
285	Batikuling	Litsea leytensis Merr.	Lauraceae	Endemic	Endangered	yes
314	Mangkono	Xanthostemon verdugonianus Naves	Myrtaceae	Endemic	Endangered	yes
376	Igem-Dagat	Podocarpus costalis C.Presl	Podocarpaceae	Indigenous	Endangered	yes
402	Betis	Madhuca betis (Blanco) JT McBride	Sapotaceae	Endemic	Endangered	yes
406	Pianga	Madhuca obovatifolia (Merr.)	Sapotaceae	Endemic	Endangered	yes
436	Dao	Dracontomelon dao (Blanco) Merr. & Rolfe	Anacardiaceae	Indigenous	Vulnerable	yes
438	Pahutan	Mangifera altissima Blanco	Anacardiaceae	Indigenous	Vulnerable	yes
466	Almaciga	Agathis philippinensis Warb.	Araucariaceae	Indigenous	Vulnerable	yes
529	Malakatmon	Dillenia luzoniensis (S.Vidal) Merr. PJS	Dilleniaceae	Indigenous	Vulnerable	yes
533	Hairy-Leaf Apitong	Dipterocarpus alatus Roxb. ex G.Don.	Dipterocarpaceae	Indigenous	Vulnerable	yes
535	Apitong	Dipterocarpus grandiflorus (Blanco) Blanco	Dipterocarpaceae	Indigenous	Vulnerable	yes
536	Hasselt'S Panau	Dipterocarpus hasseltii Blume	Dipterocarpaceae	Indigenous	Vulnerable	yes
537	Broad-Leaf Apitong	Dipterocarpus kunstleri King.	Dipterocarpaceae	Indigenous	Vulnerable	yes
538	Yakal-Saplungan	Hopea plagata (Blanco) S.Vidal	Dipterocarpaceae	Indigenous	Vulnerable	yes
540	Almon	Shorea almon Foxw.	Dipterocarpaceae	Indigenous	Vulnerable	yes
542	White Lauan	Shorea contorta Vidal	Dipterocarpaceae	Endemic	Vulnerable	yes
543	Yakál-Yambán	Shorea falciferoides Foxw.	Dipterocarpaceae	Endemic	Vulnerable	yes
544	Red Lauan	Shorea negrosensis Foxw.	Dipterocarpaceae	Endemic	Vulnerable	yes
545	Tanguile	Shorea polysperma (Blanco) Merr.	Dipterocarpaceae	Endemic	Vulnerable	yes
546	Malayakal	Shorea seminis (Vriese) Slooten	Dipterocarpaceae	Indigenous	Vulnerable	yes
549	Aponan	Diospyros cauliflora Blume	Ebenaceae	Indigenous	Vulnerable	yes
551	Bantulinau	Diospyros ferrea (Willd.) Bakh.	Ebenaceae	Indigenous	Vulnerable	yes
552	Oi-Oi	Diospyros philippinensis A.DC.	Ebenaceae	Indigenous	Vulnerable	yes
553	Bolong-Eta	Diospyros pilosanthera Blanco	Ebenaceae	Indigenous	Vulnerable	yes
554	Anang	Diospyros pyrrhocarpa Miq.	Ebenaceae	Indigenous	Vulnerable	yes
565	Balakat-Gubat	Balakata luzonica (S.Vidal) Esser	Euphorbiaceae	Indigenous	Vulnerable	yes
568	Narig	Vatica mangachapoi Blanco ssp. Mangachapoi	Dipterocarpaceae	Indigenous	Vulnerable	yes
570	Ipil	Intsia bijuga (Colebr.) Kuntze	Fabaceae	Indigenous	Vulnerable	yes
572	Batete	Kingiodendron alternifolium (Elmer) Merr. & Rolfe	Fabaceae	Indigenous	Vulnerable	yes
579	Banuyo	Wallaceodendron celebicum Koord.	Fabaceae	Indigenous	Vulnerable	yes
604	Smooth Narra	Pterocarpus indicus Willd. forma indicus	Fabaceae	Indigenous	Vulnerable	yes
613	Bagauak-Morado	Clerodendrum quadriloculare (Blanco) Merr.	Lamiaceae	Indigenous	Vulnerable	yes
635	Kalantas	Toona calantas Merr. & Rolfe	Meliaceae	Indigenous	Vulnerable	yes
640	Makaasim	Syzygium nitidum Benth.	Myrtaceae	Indigenous	Vulnerable	yes
641	Malabayabas	Tristaniopsis decorticata (Merr.) Peter G Wilson & Waterhouse	Myrtaceae	Endemic	Vulnerable	yes
642	Taba	Tristaniopsis littoralis (Merr.) Peter G Wilson & Waterhouse	Myrtaceae	Endemic	Vulnerable	yes
645	Malapiga	Xanthostemon speciosus Merr.	Myrtaceae	Endemic	Vulnerable	yes
773	Alupag	Litchi chinensis Sonn.	Sapindaceae	Indigenous	Vulnerable	yes
776	Red Nato, Nato	Palaquium luzoniense (Fern.-Villar) Vidal	Sapotaceae	Endemic	Vulnerable	yes
777	Pinulog	Palaquium mindanaense Merr.	Sapotaceae	Endemic	Vulnerable	yes
778	Malak-Malak	Palaquium philippense (Perr.) C Robinson	Sapotaceae	Endemic	Vulnerable	yes
780	Villamil Nato, White Nato	Pouteria villamilii (Merr.) Swenson	Sapotaceae	Endemic	Vulnerable	yes
819	Amugis	Koordersiodendron pinnatum (Blanco) Merr.	Anacardiaceae	Indigenous	Other Threatened Species	yes
842	Píling-Liítan	Canarium luzonicum (Blume) Miq.	Burseraceae	Endemic	Other Threatened Species	yes
843	Pili	Canarium ovatum Engl.	Burseraceae	Endemic	Other Threatened Species	yes
856	Malagaitmon	Diospyros curranii Merr.	Ebenaceae	Indigenous	Other Threatened Species	yes
857	Ata-Ata	Diospyros mindanaensis Merr.	Ebenaceae	Indigenous	Other Threatened Species	yes
881	Kalingag	Cinnamomum mercadoi Vidal	Lauraceae	Endemic	Other Threatened Species	yes
888	Malasaging	Aglaia edulis (Roxb.) Wall.	Meliaceae	Indigenous	Other Threatened Species	yes
904	Duguan	Myristica philippensis Lam.	Myristicaceae	Endemic	Other Threatened Species	yes
958	Mapilig	Xanthostemon bracteatus Merr.	Myrtaceae	Endemic	Critically Endangered	yes
973	Palawan Narig	Vatica mangachapoi Blanco ssp.obtusifolia (Elmer) Ashton	Dipterocarpaceae	Endemic	Endangered	yes
982	Prickly Narra	Pterocarpus indicus Willd. forma echinatus	Fabaceae	Indigenous	Vulnerable	yes
983	Antipolo	Artocarpus blancoi	Moraceae	\N	\N	yes
\.


--
-- Name: ntapi_species ntapi_species_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.ntapi_species
    ADD CONSTRAINT ntapi_species_pkey PRIMARY KEY (id);


--
-- Name: ntapi_species ntapi_species_species_key; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.ntapi_species
    ADD CONSTRAINT ntapi_species_species_key UNIQUE (species);


--
-- Name: ntapi_species_species_c0ddb82f_like; Type: INDEX; Schema: staging; Owner: postgres
--

CREATE INDEX ntapi_species_species_c0ddb82f_like ON staging.ntapi_species USING btree (species varchar_pattern_ops);


--
-- PostgreSQL database dump complete
--

