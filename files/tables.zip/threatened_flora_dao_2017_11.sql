--
-- PostgreSQL database dump
--

-- Dumped from database version 14.13 (Postgres.app)
-- Dumped by pg_dump version 16.4 (Postgres.app)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: threatened_flora_dao_2017_11; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.threatened_flora_dao_2017_11 (
    id integer NOT NULL,
    family character varying,
    genus character varying,
    species character varying,
    sub_species character varying,
    varietal character varying,
    common_name character varying,
    taxonomic_group character varying,
    conservation_status character varying,
    residency_status character varying,
    distribution character varying
);


ALTER TABLE staging.threatened_flora_dao_2017_11 OWNER TO postgres;

--
-- Name: threatened_flora_dao_2017_11_id_seq; Type: SEQUENCE; Schema: staging; Owner: postgres
--

CREATE SEQUENCE staging.threatened_flora_dao_2017_11_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE staging.threatened_flora_dao_2017_11_id_seq OWNER TO postgres;

--
-- Name: threatened_flora_dao_2017_11_id_seq; Type: SEQUENCE OWNED BY; Schema: staging; Owner: postgres
--

ALTER SEQUENCE staging.threatened_flora_dao_2017_11_id_seq OWNED BY staging.threatened_flora_dao_2017_11.id;


--
-- Name: threatened_flora_dao_2017_11 id; Type: DEFAULT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.threatened_flora_dao_2017_11 ALTER COLUMN id SET DEFAULT nextval('staging.threatened_flora_dao_2017_11_id_seq'::regclass);


--
-- Data for Name: threatened_flora_dao_2017_11; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.threatened_flora_dao_2017_11 (id, family, genus, species, sub_species, varietal, common_name, taxonomic_group, conservation_status, residency_status, distribution) FROM stdin;
1	Apocynaceae	Kibatalia	longifolia Merr.	\N	\N	Malapasnit	Angiosperm (Tree)	Critically Endangered	Endemic	MINDANAO: Davao del Sur.
2	Araceae	Amorphophallus	palawanensis Bogner & Hett.	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	Palawan: Underground River, Piedras Point, Cliffs Head
3	Araceae	Amorphophallus	natolii Hett., A.Wistuba, V.B.Amoroso, M.Medecilo & C.Claudel	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	PALAWAN.
4	Arecaceae	Areca	parens Becc.	\N	\N	Takobtob	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Camarines Norte (Mt Labo), Camarines Sur (Bicol National Park).
5	Arecaceae	Calamus	batanensis (Becc.) Baja-Lapis	\N	\N	Valit	Angiosperm	Critically Endangered	Endemic	BATAN (Mt Iraya)
6	Arecaceae	Calamus	jenningsianus Becc.	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDORO: Mindoro Oriental (Mt Halcon).
7	Arecaceae	Calamus	vinosus Becc.	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Agusan del Norte (Mt Hilong-hilong).
8	Arecaceae	Calamus	affinis Becc.	\N	\N	Bagbag	Angiosperm	Critically Endangered	Endemic	MINDANAO: Agusan del Norte (Mt Urdaneta).
9	Arecaceae	Calamus	oligolepis Becc.	\N	\N	Rogman	Angiosperm	Critically Endangered	Endemic	MINDANAO: Davao (Mt Apo).
10	Arecaceae	Calamus	pannosus Becc.	\N	\N	Sabilog	Angiosperm	Critically Endangered	Endemic	MINDANAO: Davao (Mt Apo).
11	Arecaceae	Heterospathe	califrons Fernando	\N	\N	Yanisi	Angiosperm (Tree)	Critically Endangered	Endemic	NE MINDANAO: E slopes of Diwata Mtns, Surigao del Sur (Carmen).
12	Arecaceae	Heterospathe	dransfieldii Fernando	\N	\N	Dransfield sanakti	Angiosperm (Tree)	Critically Endangered	Endemic	PALAWAN (vicinity of Mt Beaufort-Thumb Peak).
13	Arecaceae	Heterospathe	scitula Fernando	\N	\N	Malasanakti	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Camarines Norte (Basud, Tuaca; Bicol National Park), Camarines Sur (Buhi), Albay (Daraga).
14	Arecaceae	Heterospathe	sibuyanensis Becc.	\N	\N	Bilis	Angiosperm (Tree)	Critically Endangered	Endemic	SIBUYAN (Mt Giting-giting).
15	Arecaceae	Heterospathe	trispatha Fernando	\N	\N	Tatlong bilisan	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Aurora (Dilasag; Baler).
16	Arecaceae	Orania	paraguanensis Becc., Webbia	\N	\N	Palawan Banga	Angiosperm (Tree)	Critically Endangered	Indigenous	Palawan, Separation Point, Banguey
17	Arecaceae	Pinanga	batanensis Becc.	\N	\N	Dapiau	Angiosperm (Tree)	Critically Endangered	Endemic	MINDANAO: Zamboanga, BASILAN.
18	Arecaceae	Pinanga	bicolana Fernando	\N	\N	Bicol abiki	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Camarines Norte and Sur provincial borders (Bicol National Park).
19	Arecaceae	Pinanga	samarana Becc.	\N	\N	Samar abiki	Angiosperm (Tree)	Critically Endangered	Endemic	SAMAR
20	Arecaceae	Pinanga	sclerophylla Becc.	\N	\N	Abiking-tigas	Angiosperm (Tree)	Critically Endangered	Endemic	MINDORO: Mindoro Oriental (Mt Halcon).
21	Arecaceae	Pinanga	sibuyanensis Becc.	\N	\N	Tibangan	Angiosperm (Tree)	Critically Endangered	Endemic	SIBUYAN (Mt Giting-giting).
22	Arecaceae	Plectocomia	elmeri Becc.	\N	\N	Ungang	Angiosperm	Critically Endangered	Endemic	MINDANAO: Davao (Mt Apo).
23	Balanophoraceae	Balanophora	coralliformis Pelser, Tandang\n& Barcelona	\N	\N	coral plant	Angiosperm	Critically Endangered	Endemic	LUZON: Aurora (Mt. Mingan), Benguet
24	Buxbaumiaceae	Buxbaumia	javanica Muell. Hal.	\N	\N	\N	Bryophyte	Critically Endangered	Indigenous	No available information.
25	Casuarinaceae	Ceuthostoma	palawanense L.A.S.Johnson	\N	\N	Paróngpong	Angiosperm (Tree)	Critically Endangered	Endemic	PALAWAN: Aborlan: Malasgao River
26	Casuarinaceae	Ceuthostoma	terminale L.A.S.Johnson	\N	\N	\N	Angiosperm (Tree)	Critically Endangered	Indigenous	PALAWAN. Primary and secondary forest on ultramafic soils
27	Cyatheaceae	Cyathea	curranii Copel.	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	LUZON: Quezon.
28	Cyatheaceae	Cyathea	latipinnula Copel.	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	SIBUYAN.
29	Cyatheaceae	Cyathea	microchlamys Holttum	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	CATANDUANES.
30	Cyatheaceae	Cyathea	obliqua Copel.	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	SIBUYAN.
31	Cyatheaceae	Cyathea	sibuyanensis Copel.	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	SIBUYAN.
32	Cycadaceae	Cycas	aenigma K.D.Hill & A.Lindstr	\N	\N	\N	Gymnosperm (Tree)	Critically Endangered	Endemic	Puerto Princesa City, Palawan.
33	Cycadaceae	Cycas	curranii (J Schust.) KD Hill	\N	\N	Curran pitogo	Gymnosperm (Tree)	Critically Endangered	Endemic	PALAWAN (Puerto Princesa; Aborlan; Narra).
34	Cycadaceae	Cycas	sancti-lasallei Agoo & Madulid	\N	\N	\N	Gymnosperm (Tree)	Critically Endangered	Endemic	PALAWAN (Puerto Princesa; Aborlan; Narra).
35	Cycadaceae	Cycas	saxatilis KD. Hill & Lindstr.	\N	\N	\N	Gymnosperm (Tree)	Critically Endangered	Endemic	Palawan: St Paul’s Bay
36	Cycadaceae	Cycas	zambalensis Madulid & Agoo	\N	\N	\N	Gymnosperm (Tree)	Critically Endangered	Endemic	Luzon: Zambales prov., San Antonio, Kawag, Bucao.
37	Dipteridaceae	Dipteris	lobbiana (Hook.) Moore, Ind. Fil.	\N	\N	\N	Pteridophyte	Critically Endangered	Indigenous	NEGROS.
38	Dipterocarpaceae	Hopea	basilanica Foxw.	\N	\N	Basilan Yakal	Angiosperm (Tree)	Critically Endangered	Endemic	MINDANAO, BASILAN, SIBUTU. Primary lowland forests on undulating hills below 70m.
39	Dipterocarpaceae	Hopea	brachyptera (Foxw.) Sloot.	\N	\N	Mindanao narek	Angiosperm (Tree)	Critically Endangered	Endemic	MINDANAO: Zamboanga. Primary lowland forests. 
40	Dipterocarpaceae	Hopea	cagayanensis (Foxw.) Sloot.	\N	\N	Cagayan narek	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Apayao, Cagayan. Primary lowland semi-evergreen forests.
41	Dipterocarpaceae	Hopea	foxworthyi Elmer	\N	\N	Dalindingan	Angiosperm (Tree)	Critically Endangered	Endemic	SIBUYAN. Locally common on red sticky volcanic soil along ridges at 600-700m, in seasonal semi-evergreen forest. 
42	Dipterocarpaceae	Hopea	malibato Foxw.	\N	\N	Yakal-kaliot	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Quezon, NEGROS, MINDANAO: Agusan del Norte. Primary evergreen dipterocarp forests in aseasonal areas. Ascending up to 600m.
43	Dipterocarpaceae	Hopea	mindanensis Foxw.	\N	\N	Yakal-magasusu	Angiosperm (Tree)	Critically Endangered	Endemic	MINDANAO: Zamboanga. Primary lowland evergreen forests.
44	Dipterocarpaceae	Hopea	philippinensis Dyer	\N	\N	Gisok-gisok	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Laguna, Quezon, Camarines, Albay, SAMAR, BILIRAN, LEYTE, PANAY, NEGROS, SAMAR, MINDANAO: Zamboanga, Lanao, Agusan. Primary evergreen forests on hills in aseasonal areas, ascending to 500m, often common. 
45	Dipterocarpaceae	Hopea	quisumbingiana Gutierrez	\N	\N	Quisumbing gisok	Angiosperm (Tree)	Critically Endangered	Endemic	SAMAR. Low elevation everwet primary forest. 
46	Dipterocarpaceae	Hopea	samarensis Gutierrez	\N	\N	Samar gisok	Angiosperm (Tree)	Critically Endangered	Endemic	SAMAR. Mixed dipterocarp forests in moist lowland valleys
47	Dipterocarpaceae	Shorea	astylosa Foxw.	\N	\N	Yakal	Angiosperm (Tree)	Critically Endangered	Endemic	 LUZON: Quezon, Camarines, NEGROS, BILIRAN, SAMAR, MINDANAO: Zamboanga, Davao, Agusan. Local in primary lowland evergreen dipterocarp forests.
48	Dipterocarpaceae	Shorea	malibato Foxw.	\N	\N	Yakal-malibato	Angiosperm (Tree)	Critically Endangered	Endemic	 LUZON: Quezon, Camarines, LEYTE, MINDANAO: Zamboanga, Agusan del Norte. Local in lowland primary forests in aseasonal areas, c. 450m in Agusan del Norte. 
49	Dipterocarpaceae	Vatica	elliptica Foxw.	\N	\N	Kaladis narig	Angiosperm (Tree)	Critically Endangered	Endemic	MINDANAO: Zamboanga, twice collected.
50	Dipterocarpaceae	Vatica	pachyphylla Merr.	\N	\N	Thick-leafed narig	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Cagayan; Quezon, Camarines Norte, POLILLO. Scattered in aseasonal, primary dipterocarp forests below 80m.
51	Dryopteridaceae	Ctenitis	paleolata Copel.	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	LUZON: Benguet (Pauai).
52	Dryopteridaceae	Dryopteris	zhuweimingii Li Bing Zhang	\N	\N	\N	Pteridophyte	Critically Endangered	Indigenous	Luzon: Benguet: Mt Pulag
53	Ebenaceae	Diospyros	brideliifolia Elmer	\N	\N	Malinoag	Angiosperm (Tree)	Critically Endangered	Endemic	 Negros: Negros Oriental prov., Cuernos Mtns, in moist dense woods at 4000ft,
54	Ebenaceae	Diospyros	longiciliata Merr.	\N	\N	Itom-itom	Angiosperm (Tree)	Critically Endangered	Endemic	MINDANAO: Surigao, DINAGAT. Lowland primary forests. 
55	Ebenaceae	Diospyros	poncei Merr.	\N	\N	Ponce kamagong	Angiosperm (Tree)	Critically Endangered	Endemic	Mindanao: Surigao prov., Combot, on semi-open slopes, c. 15m
56	Ericaceae	Rhododendron	acrophilum Merr. & Quisumb.	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	PALAWAN: Mt Mantalingahan. 
57	Ericaceae	Rhododendron	javanicum (Blume) Benn.	ssp. Palawanense	\N	Malagos	Angiosperm	Critically Endangered	Endemic	Palawan: Mt Mantalingahan
58	Ericaceae	Rhododendron	mendumiae Argent	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	PALAWAN: Cleopatra Needle.
59	Ericaceae	Rhododendron	reynosoi Argent	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	PALAWAN: Cleopatra Needle.
60	Ericaceae	Rhododendron	taxifolium Merr.	\N	\N	yew-leaf rhododendron	Angiosperm	Critically Endangered	Endemic	LUZON: Benguet (Mt Pulag), 2700m. Epiphytic shrub on trees in the mossy forest.
61	Fabaceae	Cynometra	cebuensis Seidenschwarz	\N	\N	\N	Angiosperm (Tree)	Critically Endangered	Endemic	Cebu: Tabunan forest.
62	Fabroniaceae	Macgregorella	indica (Broth) W.R. Buck	\N	\N	\N	Bryophyte	Critically Endangered	Indigenous	No available information.
63	Fabroniaceae	Merrilliobryum	fabronioides Broth.	\N	\N	\N	Bryophyte	Critically Endangered	Endemic	LUZON.
64	Hypericaceae	Hypericum	pulogense Merr.	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Benguet (Mt Pulag, Mt Tabayoc). Open grassland above the timber line, c. 2800m.
65	Isoetaceae	Isoetes	philippinensis Merr. & Perry	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	MINDANAO (Lanao del Norte, near Momungan, vicinity of Olangu).
66	Lauraceae	Cinnamomum	mendozae Kosterm	\N	\N	Mendoza kalíngag	Angiosperm (Tree)	Critically Endangered	Endemic	MINDANAO.
67	Lauraceae	Cinnamomum	oroi Quisumb.	\N	\N	Oro kalingag	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Tayabas. Forest, c. 300m.
68	Lembophyllaceae	Porotrichodendron	mahahaicum\n(Muell.Hal.) M.Fleisch.	\N	\N	\N	Bryophyte	Critically Endangered	Endemic	No available information.
69	Liliaceae	Tricyrtis	imeldae Gut.	\N	\N	amutmagiso	Angiosperm	Critically Endangered	Endemic	MINDANAO: South Cotabato. Primary forest, along stream at c. 1300m.
70	Loranthaceae	Thaumasianthes	amplifolia (Merr.) Danser	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LEYTE, SAMAR (Catbalogan; Caminiwan on the Catubig River). Lowlands.
71	Lycopodiaceae	Phlegmariurus	whitfordii (Herter)	\N	\N	salindugok	Pteridophyte	Critically Endangered	Endemic	LUZON.
72	Matoniaceae	Phanerosorus	major Diels	\N	\N	\N	Pteridophyte	Critically Endangered	Indigenous	SAMAR.
73	Melastomataceae	Medinilla	dallciana Fernando & Balete	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Camarines Sur.
74	Melastomataceae	Medinilla	magnifica Lindl.	\N	\N	kapa-kapa	Angiosperm	Critically Endangered	Endemic	BATAN (Mt Iraya), BABUYAN ISLS (CAMIGUIN), LUZON: Rizal, Laguna (Mt Makiling), Quezon, MINDORO: Mindoro Oriental (Mt Halcon), PANAY, NEGROS: Negros Oriental (Cuernos Mtns), MINDANAO.
75	Meliaceae	Aglaia	pyriformis Merr.	\N	\N	Kanining peneras	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Aurora (Mt Dingalan), Nueva Ecija (Mt Umingan = Mingan). Primary forests, 300-400m.
76	Myristicaceae	Knema	ridsdaleana de Wilde	\N	\N	Ridsdale tambalau	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Isabela (Palanan). Streamside forest over ultramafics, c. 50m. 
77	Myristicaceae	Myristica	colinridsdalei de Wilde	\N	\N	Ridsdale duguan	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Isabela (Palanan). Forest on ultramafics, low stature forest with many large-girth trees, streamside forests, or high canopy forest on low coastal hills; locally common on coastal flat, riverine areas; c. 50m.
78	Myrtaceae	Xanthostemon	bracteatus Merr.	\N	\N	\N	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Camarines Norte (Paracale, Mambulao), SAMAR. Lowland primary forests. 
79	Myrtaceae	Xanthostemon	fruticosus Peter G Wilson & Co	\N	\N	\N	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Isabela (Divilacan, Palanan, Dinapigue). Stunted scrub vegetation from near the coast to c. 1000m.
80	Myrtaceae	Xanthostemon	philippinensis Merr.	\N	\N	Bago-adlau	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Camarines Norte (Paracale), SAMAR. Lowland primary forests
81	Nepenthaceae	Nepenthes	abalata Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	PANAY: Antique (Marasison Isl), PALAWAN (Cuyo Isl, Culion Isl).
82	Nepenthaceae	Nepenthes	abgracilis Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Surigao.
83	Nepenthaceae	Nepenthes	alzapan Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Tayabas (Mt. Alzapan).
84	Nepenthaceae	Nepenthes	argentii M Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	SIBUYAN (Mt Guiting-guiting). Subalpine shrubbery with smooth wind-clipped canopy 30cm tall on a ridge of ultramafic rocks, 1400m. 
85	Nepenthaceae	Nepenthes	armin Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	SIBUYAN.
86	Nepenthaceae	Nepenthes	attenboroughii A.S. Robinson, McPherson & Heinrich	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	Palawan: Mt Victoria.
87	Nepenthaceae	Nepenthes	barcelonae Tandang & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Aurora.
88	Nepenthaceae	Nepenthes	cid Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Bukidnon.
89	Nepenthaceae	Nepenthes	deaniana Macfarl	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	PALAWAN (Mt Pulgar, Cabatuan River). Reportedly very common at the 1300 m summit of Mt Pulgar. 
90	Nepenthaceae	Nepenthes	extincta Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: boundary of Surigao del Sur & Surigao del Norte.
91	Nepenthaceae	Nepenthes	kitanglad Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Bukidnon.
92	Nepenthaceae	Nepenthes	kurata Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	CAMIGUIN, MINDANAO: Misamis Occidental, Surigao del Norte, NEGROS
93	Nepenthaceae	Nepenthes	leonardoi S.McPherson et al	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	PALAWAN.
94	Nepenthaceae	Nepenthes	leyte Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LEYTE.
95	Nepenthaceae	Nepenthes	merrilliana Macfarl.	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Agusan del Norte (Mt Urdaneta), Surigao, DINAGAT. Forests, steep slopes near the coast. Apparently restricted to ultramafics, sometimes epiphytic.
96	Nepenthaceae	Nepenthes	micramphora Heinrich, et.al.	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Davao Oriental (Mt Hamiguitan). On ultramafic substrates. 
97	Nepenthaceae	Nepenthes	mira Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	PALAWAN (Cleopatra’s Needle).
98	Nepenthaceae	Nepenthes	negros Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	BILIRAN, NEGROS.
99	Nepenthaceae	Nepenthes	palawanensis S.McPherson et al.	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	PALAWAN (Sultan Peak)
100	Nepenthaceae	Nepenthes	peltata Sh. Kurata	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Davao Oriental (Mt Hamiguitan), on ultramafic substrates. 
101	Nepenthaceae	Nepenthes	pulchra Gronem. et al	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO.
102	Nepenthaceae	Nepenthes	ramos Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	CAMIGUIN, MINDANAO: Misamis Occidental, Surigao del Norte, NEGROS
103	Nepenthaceae	Nepenthes	robcantleyi Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO.
104	Nepenthaceae	Nepenthes	samar Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	SAMAR.
105	Nepenthaceae	Nepenthes	sibuyanensis J Nerz	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	 SIBUYAN: Mt Guiting-guiting, 1300-2058m, grows quite sparsely on open grassy slopes among Dipteris conjugata and high grasses in ultramafic soils. 
106	Nepenthaceae	Nepenthes	tboli Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: South Cotabato.
107	Nepenthaceae	Nepenthes	zygon Jebb & Cheek	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Agusan del Norte, Davao Oriental.
108	Oleaceae	Chionanthus	clementis (Quisumb. & Merr.) Kiew	\N	\N	Kayantol	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Isabela (Mt Moises). 
109	Oleaceae	Chionanthus	remotinervius (Merr.) Kiew	\N	\N	Pamoplasin	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Isabela (Palanan, ISU 434 & 438, L), Pangasinan (Mt San Isidro Labrador), Zambales (Masinloc, along Lawis River, PNH 191386 Busemeyer, Ippolito & Barcelona). Open grassy slopes near forest edge, also along streams, near sea-level to 600m
110	Oleaceae	Olea	palawanensis Kiew	\N	\N	Palawan olive	Angiosperm (Tree)	Critically Endangered	Endemic	PALAWAN: Mt Bloomfield; Victoria Peaks. Open, disturbed vegetation on ultramafics, low elevation.
111	Ophioglossaceae	Helminthostachys	zeylanica (L.) Hook	\N	\N	tungkod-langit	Pteridophyte	Critically Endangered	Indigenous	PALAWAN. Throughout the Philippines.
112	Orchidaceae	Amesiella	monticola J Cootes & DP Banks	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	 LUZON: Nueva Vizcaya, ?Benguet. Fringes of montane forest, 1800-2200m. 
113	Orchidaceae	Bulbophyllum	cootesii M.A.Clem	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	DINAGAT.
114	Orchidaceae	Ceratocentron	fesselii Senghas	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Nueva Ecija, Nueva Vizcaya. Epiphytic, c. 1000m. 
115	Orchidaceae	Dendrobium	schuetzei Rolfe	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Surigao del Norte, Surigao del Sur. Epiphytic, up to 300m elevation. 
116	Orchidaceae	Gastrochilus	calceolaris (Buch.-Ham. ex Sm.) D.Don	\N	\N	\N	Angiosperm	Critically Endangered	Indigenous	LUZON: Benguet (Baguio), MINDANAO: Misamis.
117	Orchidaceae	Grammatophyllum	speciosum Blume	\N	\N	\N	Angiosperm	Critically Endangered	Indigenous	LUZON: Camarines, Nueva Ecija, Quezon, Sorsogon, MINDORO, LEYTE, MINDANAO: Davao, Surigao.
118	Orchidaceae	Grammatophyllum	ravanii D.Tiu	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDORO.
119	Orchidaceae	Grammatophyllum	walisii Rchb.f	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Quezon, LEYTE, NEGROS, MINDANAO: Surigao, SAMAR.
120	Orchidaceae	Mycaranthes	leonardoi Ferreras & Suarez	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Nueva Ecija. Epiphytic, c. 1500m.
121	Orchidaceae	Paphiopedilum	acmodontum MW Wood	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	NEGROS: Negros Oriental (Cuernos Mtns). Terrestrial, to c. 1000m. 
122	Orchidaceae	Paphiopedilum	adductum Asher	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Davao Oriental (Mt Hamiguitan).
123	Orchidaceae	Paphiopedilum	argus (Reichb.f.) Stein	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Mountain Province, Benguet, Quezon, NEGROS: Negros Oriental, BOHOL. Grassy slopes, 600-2200m. 
124	Orchidaceae	Paphiopedilum	ciliolare (Reichb.f.) Stein	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Mountain Province, CAMIGUIN, MINDANAO: Agusan del Norte, Agusan del Sur, Surigao del Norte, Surigao del Sur, DINAGAT. Terrestrial, usually at the bases of shrubs, 310-1830m
125	Orchidaceae	Paphiopedilum	fowliei Birk	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	PALAWAN. Terrestrial at medium elevation of c. 700m.
126	Orchidaceae	Paphiopedilum	haynaldianum (Reichb.f.) Stein	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Apayao, Kalinga, Mountain Province, Benguet, Nueva Ecija, Tarlac, Rizal, NEGROS: Negros Occidental, MINDANAO: Surigao del Norte, Surigao del Sur. Usually lithophytic and frequently epiphytic, near sea level to 1500m
127	Orchidaceae	Paphiopedilum	hennisianum (MW Wood) Fowlie	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Bukidnon. Terrestrial, c. 500m. 
128	Orchidaceae	Paphiopedilum	philippinense (Rchb.f.)\nStein	\N	var. philippinense	\N	Angiosperm	Critically Endangered	Endemic	S LUZON, PALAWAN (APULIT Isl), NEGROS: Negros Occidental, CEBU, BOHOL, MINDANAO: Agusan del Norte, Surigao del Norte.
129	Orchidaceae	Paphiopedilum	randsii Fowlie	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Agusan del Norte, Agusan del Sur, Surigao del Norte, Surigao del Sur. Epiphytic, low to c. 500m
130	Orchidaceae	Paphiopedilum	urbanianum Fowlie	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDORO: Mindoro Oriental.
131	Orchidaceae	Paphiopedilum	usitanum O.Gruss & Roeth	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Tarlac.
132	Orchidaceae	Paphiopedilum	barbatum (Lindl.) Pfitzer	\N	\N	\N	Angiosperm	Critically Endangered	Indigenous	PALAWAN: Mt Victoria, forest on ultramafics
133	Orchidaceae	Paphiopedilum	lowii (Lindl.) Stein,	\N	\N	\N	Angiosperm	Critically Endangered	Indigenous	PALAWAN.
134	Orchidaceae	Phalaenopsis	micholitzii Rolfe	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Camarines Sur, MINDANAO: Zamboanga del Norte, Zamboanga del Sur. Epiphyte, to 400m.
135	Orchidaceae	Phragmorchis	teretifolia LO Williams	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	Luzon
136	Orchidaceae	Renanthera	caloptera (Rchb.f.) Kocyan & Schuit.	\N	\N	\N	Angiosperm	Critically Endangered	Indigenous	DINAGAT.
137	Orchidaceae	Vanda	lamellata Lindl.	\N	v. calayan Valmayor & D Tiu	\N	Angiosperm	Critically Endangered	Endemic	Luzon: Manila. Batanes
138	Orchidaceae	Vanda	sanderiana (Reichb.f) Schltr.	\N	\N	Waling-waling	Angiosperm	Critically Endangered	Endemic	MINDANAO: Cotabato, Davao, Zamboanga.
139	Podocarpaceae	Podocarpus	palawanensis de Laub. & Silba	\N	\N	Palawan malakauayan	Gymnosperm (Tree)	Critically Endangered	Endemic	Palawan: Pagdanan Range, Ibangley Brookside Hill.
140	Polypodiaceae	Goniophlebium	terrestre Copel.	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	LUZON: Isabela, Laguna, Quirino.
141	Polypodiaceae	Platycerium	coronarium (König ex Müller) Desv.	\N	\N	staghorn fern	Pteridophyte	Critically Endangered	Indigenous	LUZON, MINDANAO.
142	Polypodiaceae	Platycerium	grande (Fee) Kunze	\N	\N	giant staghorn fern	Pteridophyte	Critically Endangered	Endemic	MASBATE, MINDANAO: Zamboanga, Lanao, Davao (Mt Apo).
143	Polypodiaceae	Podosorus	angustatus Holttum	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	Luzon: Isabela Prov, San Mariano, Brgy Disulap.
144	Pteridaceae	Pteris	calocarpa (Copel.) MG Price	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	MINDANAO: Zamboanga.
145	Pteridaceae	Pteris	pachysora (Copel.) MG Price	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	MINDANAO: Zamboanga.
146	Pterobryaceae	Euptychium	setigerum (Sull.) Broth.	\N	\N	\N	Bryophyte	Critically Endangered	Indigenous	No available information.
147	Rafflesiaceae	Rafflesia	aurantia Barcelona, Co & Balete	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Quirino (Nagtipunan).
148	Rafflesiaceae	Rafflesia	mixta Barcelona, Manting,\nArbolonio et al.	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Surigao del Norte (Mainit: Mt Cantugas; Lanuza).
149	Rafflesiaceae	Rafflesia	schadenbergiana Goeppert ex Hieron.	\N	\N	Boo	Angiosperm	Critically Endangered	Endemic	MINDANAO: South Cotabato (Mt Temlofung), Davao (Mt Apo), Bukidnon (lower slopes of Mt Kitanglad at Baungon). Primary as well as degraded secondary forest. 
150	Rafflesiaceae	Rafflesia	verrucosa Balete et al.	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDANAO: Davao Oriental (Mt Kampalili), Misamis Oriental (Mt Balatukan), South Cotabato (Mt. Matutum)
151	Rhizophoraceae	Kandelia	candel Druce	\N	\N	Baler bakauan	Angiosperm (Tree)	Critically Endangered	Indigenous	LUZON: Aurora (Baler and Casiguran Bay, Cozo).
152	Rubiaceae	Antherostele	callophylla Bremek.	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Ilocos Norte (Mt Palimlim).
153	Rubiaceae	Antherostele	luzoniensis (Merr.) Bremek.	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	LUZON: Isabela (Mt Moises), Aurora (Mt Dingalan). Primary forests, probably above 300m. 
154	Rubiaceae	Antherostele	samarensis Obico & Alejandro	\N	\N	\N	Angiosperm	Critically Endangered	Endemic	MINDORO, SAMAR: Basey.
155	Rubiaceae	Atractocarpus	obscurinervius (Merr.)	\N	\N	Kalinigi	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Laguna, Sorsogon, CATANDUANES, MINDANAO: Sultan Kudarat. In primary forest at low elevation. Reportedly epiphytic.
156	Rubiaceae	Badusa	palawanensis Ridsd.	\N	\N	Palawan palak	Angiosperm (Tree)	Critically Endangered	Endemic	PALAWAN: Quezon, Lipuun Point. Rocky summit of limestone hill. 
157	Rubiaceae	Bikkia	montoyae Mejillano et al.	\N	\N	\N	Angiosperm (Tree)	Critically Endangered	Endemic	DINAGAT.
158	Rubiaceae	Bikkia	philippinensis Valeton	\N	\N	\N	Angiosperm (Tree)	Critically Endangered	Endemic	CEBU, SULU ARCHIPELAGO (SIBUTU), MINDANAO: Surigao.
159	Rubiaceae	Greeniopsis	discolor Merr.	\N	\N	Pangalimanan	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Nueva Ecija. In primary forest at or above 300m elevation. 
160	Rubiaceae	Greeniopsis	euphlebia Merr.	\N	\N	Buhon-buhon	Angiosperm (Tree)	Critically Endangered	Endemic	BUCAS GRANDE. Lowland open forests. 
161	Rubiaceae	Greeniopsis	megalantha Merr.	\N	\N	Humagos	Angiosperm (Tree)	Critically Endangered	Endemic	MINDANAO: Surigao del Norte. Low and medium elevation forests
162	Rubiaceae	Greeniopsis	pubescens Merr.	\N	\N	Paluay-mabolo	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON. 
163	Rubiaceae	Psydrax	puberula Arriola & Alejandro	\N	\N	\N	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Camarines Sur, Quezon, POLILLO.
164	Rubiaceae	Villaria	acutifolia (Elmer) Merr.	\N	\N	Tango	Angiosperm (Tree)	Critically Endangered	Endemic	DINAGAT, MINDANAO: Davao. Forest at low elevation.
165	Rubiaceae	Villaria	fasciculiflora Quisumb. & Merr.	\N	\N	Otto	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Isabela (San Mariano; Palanan), Rizal. Alejandro et al. (2011): in secondary forest, on forest margins, on clayey-sandy soils, 700m.
166	Rubiaceae	Villaria	leytensis Alejandro & Meve	\N	\N	\N	Angiosperm (Tree)	Critically Endangered	Endemic	LEYTE.
167	Rubiaceae	Villaria	uniflora Arriola & Alejandro	\N	\N	\N	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Cavite.
168	Rutaceae	Swinglea	glutinosa (Blanco) Merr.	\N	\N	Kabuyok	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Isabela to Quezon. Low and medium elevation thickets and secondary forests. 
307	Melastomataceae	Medinilla	calcicola Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Cagayan.
169	Sapindaceae	Gongrospermum	philippinense Radlk.	\N	\N	Kasau-kasau	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Laguna. Forested slopes, low elevation
170	Sapindaceae	Guioa	palawanica Welzen	\N	\N	Palawan alahan	Angiosperm (Tree)	Critically Endangered	Endemic	PALAWAN. Lowland forest on ultramafics, in stunted montane forest with many epiphytes, and along rivers, 200-815m.
171	Sapindaceae	Guioa	parvifoliola Merr.	\N	\N	Angset	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Ilocos Norte. Dry slopes, c. 700m. 
172	Sapindaceae	Guioa	reticulata Radlk.	\N	\N	Alahan-sinima	Angiosperm (Tree)	Critically Endangered	Endemic	 LUZON: Ilocos Sur, Abra, Benguet, Nueva Ecija. Secondary forests and forested slopes, 600-1200m.
173	Stemonuraceae	Gomphandra	bracteata Schori	\N	\N	\N	Angiosperm (Tree)	Critically Endangered	Endemic	PALAWAN.
174	Stemonuraceae	Gomphandra	conklinii Schori	\N	\N	Conklin mabunót	Angiosperm (Tree)	Critically Endangered	Endemic	LUZON: Ifugao.
175	Stemonuraceae	Gomphandra	dinagatensis Schori	\N	\N	Dinagat mabunót	Angiosperm (Tree)	Critically Endangered	Endemic	DINAGAT.
176	Stemonuraceae	Gomphandra	halconensis Schori	\N	\N	Halcon mabunót	Angiosperm (Tree)	Critically Endangered	Endemic	MINDORO: Oriental Mindoro.
177	Tectariaceae	Heterogonium	wenzelii (Copel.) Holttum	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	LEYTE.
178	Thelypteridaceae	Chingia	urens Holttum	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	LUZON: Laguna, MINDANAO: Bukidnon.
179	Thelypteridaceae	Coryphopteris	borealis Holttum	\N	\N	\N	Pteridophyte	Critically Endangered	Endemic	LUZON: Benguet, Ifugao.
180	Anacardiaceae	Mangifera	merrillii Mukherji	\N	\N	Pahong-liitan	Angiosperm (Tree)	Endangered	Endemic	LUZON: Zambales. Lowland forest. 
181	Anacardiaceae	Mangifera	odorata Griff., Notul.	\N	\N	huani	Angiosperm (Tree)	Endangered	Indigenous	BALABAC, JOLO, BASILAN, MINDANAO (Zamboanga).
182	Annonaceae	Goniothalamus	palawanensis C.C.Tang &\nR.M.K.Saunders	\N	\N	\N	Angiosperm (Tree)	Endangered	Endemic	Palawan: Puerto Princesa
183	Apocynaceae	Hoya	alagensis Kloppenb.	\N	\N	\N	Angiosperm	Endangered	Endemic	MINDORO: Mindoro Oriental.
184	Apocynaceae	Hoya	angustisepala CM Burton	\N	\N	\N	Angiosperm	Endangered	Endemic	Mindanao: Mt Apo (Todaya), along Sibulan River, 3000ft.
185	Apocynaceae	Hoya	burtoniae Kloppenb.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Rizal (Montalban).
186	Apocynaceae	Hoya	crassicaulis (Elmer) Kloppenb.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Sorsogon (Mt. Bulusan)
187	Apocynaceae	Hoya	curtisii King &Gamble	\N	\N	\N	Angiosperm	Endangered	Indigenous	PALAWAN.
188	Apocynaceae	Hoya	diversifolia Blume Kloppenb.	ssp. el-nidicus (Kloppenb.) Kloppenb.	\N	\N	Angiosperm	Endangered	Endemic	Palawan: El Nido
189	Apocynaceae	Hoya	estrellaensis T.Green & Kloppenb	\N	\N	\N	Angiosperm	Endangered	Endemic	Palawan: Narra, Estrella Waterfall.
190	Apocynaceae	Hoya	gigantanganensis Kloppenb.	\N	\N	\N	Angiosperm	Endangered	Endemic	Leyte: Gigantangan
191	Apocynaceae	Hoya	greenii Kloppenb.	\N	\N	\N	Angiosperm	Endangered	Endemic	Mindanao: Mt Apo, trail to hot springs lake, 4000ft.
192	Apocynaceae	Hoya	halconensis Kloppenb.	\N	\N	\N	Angiosperm	Endangered	Endemic	MINDORO: Mindoro Oriental prov., Mt Halcon, 900m.
193	Apocynaceae	Hoya	heuschkeliana Kloppenb.	\N	\N	\N	Angiosperm	Endangered	Endemic	Luzon: Sorsogon prov., Lake Bulusan
194	Apocynaceae	Hoya	imperialis Lindl.	\N	\N	\N	Angiosperm	Endangered	Indigenous	PALAWAN. In mangroves.
195	Apocynaceae	Hoya	panchoi Kloppenb.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Sorsogon (Mt Bulusan).
196	Apocynaceae	Hoya	pulgarensis Elmer	\N	\N	\N	Angiosperm	Endangered	Endemic	No available information.
197	Apocynaceae	Hoya	quinquenervia Warb.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Isabela (Malunu), Sorsogon.
198	Apocynaceae	Hoya	quisumbingii Kloppenb.	\N	\N	\N	Angiosperm	Endangered	Endemic	Batanes: Itbayat Is.
199	Apocynaceae	Hoya	rizaliana Kloppenb.	\N	\N	\N	Angiosperm	Endangered	Endemic	Luzon: Rizal prov., Montalban
200	Apocynaceae	Hoya	wayetii Kloppenb.	\N	\N	\N	Angiosperm	Endangered	Endemic	Luzon: Benguet prov., Baguio
201	Apocynaceae	Kibatalia	puberula Merr.	\N	\N	Paslit-mabolo	Angiosperm (Tree)	Endangered	Endemic	 SAMAR. Dipterocarp forests or river banks, elevation 100-250m. 
202	Apocynaceae	Kibatalia	stenopetala Merr.	\N	\N	Paslit-kitid	Angiosperm (Tree)	Endangered	Endemic	 LUZON: Laguna, NE MINDANAO: Surigao del Norte, DINAGAT.
203	Apocynaceae	Marsdenia	purpurella Fernando & Rodda	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Zambales, PALAWAN.
204	Araceae	Alocasia	sanderiana W Bull.	\N	\N	Sander's alocasia	Angiosperm	Endangered	Endemic	MINDANAO: Misamis, Agusan. Damp low elevation primary forests
205	Araliaceae	Schefflera	agamae Merr.	\N	\N	Agama galamay-amo	Angiosperm	Endangered	Endemic	PALAWAN.
206	Araliaceae	Schefflera	albido-bracteata Elmer	\N	\N	Makinging	Angiosperm	Endangered	Endemic	MINDANAO: Bukidnon, Agusan. Forests, 700-1000m.
207	Araliaceae	Schefflera	curranii Merr.	\N	\N	Curran galamay-amo	Angiosperm	Endangered	Endemic	PALAWAN: Victoria Peak, along river banks, 1200m
208	Araliaceae	Schefflera	foxworthyi Merr.	\N	\N	Foxworthy galamay-amo	Angiosperm	Endangered	Endemic	No available information.
209	Araliaceae	Schefflera	palawanensis Merr.	\N	\N	Palawan galamay-amo	Angiosperm	Endangered	Endemic	PALAWAN. Thickets bordering open grasslands at low elevation.
210	Arecaceae	Areca	camarinensis Becc.	\N	\N	Mono	Angiosperm (Tree)	Endangered	Endemic	LUZON: Camarines Norte (Bicol National Park), Camarines Sur (Mt Isarog).
211	Arecaceae	Calamus	balerensis Fernando	\N	\N	Malatandulang-parang	Angiosperm	Endangered	Endemic	LUZON: Aurora (Baler: Digisit & Semento).
212	Arecaceae	Calamus	flexilis W.J.Baker	\N	\N	\N	Angiosperm	Endangered	Endemic	PALAWAN.
213	Arecaceae	Calamus	foxworthyi Becc.	\N	\N	\N	Angiosperm	Endangered	Endemic	PALAWAN.
214	Arecaceae	Calamus	caesius Blume	\N	\N	sika	Angiosperm	Endangered	Indigenous	PALAWAN.
215	Arecaceae	Heterospathe	brevicaulis Fernando	\N	\N	Marighoi-baba	Angiosperm (Tree)	Endangered	Endemic	LUZON: Aurora (Baler, Saipon).
216	Arecaceae	Oncosperma	platyphyllum Becc.	\N	\N	Anibong	Angiosperm (Tree)	Endangered	Endemic	NEGROS: Gimagaan River.
217	Arecaceae	Pinanga	sobolifera Fernando, Kew Bull.	\N	\N	\N	Angiosperm (Tree)	Endangered	Endemic	LUZON: Quezon (General Nakar).
218	Arecaceae	Pinanga	glaucifolia Fernando	\N	\N	Abiking-puti	Angiosperm (Tree)	Endangered	Endemic	LUZON: Camarines Norte (Mt Labo; Bicol National Park).
219	Arecaceae	Salacca	clemensiana Becc.	\N	\N	lakaúbi	Angiosperm	Endangered	Endemic	MINDANAO: Zamboanga del Norte (La Paz, Camp Susana; Siocon, Laclacan), Misamis Occidental (Mt Malindang), Misamis Oriental, Lanao del Sur, Davao.
220	Arecaceae	Salacca	ramosiana Mogea	\N	\N	parutungun	Angiosperm	Endangered	Indigenous	PALAWAN, TAWI-TAWI.
221	Athyriaceae	Diplazium	costulisorum (Copel.) C.Chr.	\N	\N	\N	Pteridophyte	Endangered	Endemic	MINDANAO: Davao (Mt Apo).
222	Athyriaceae	Diplazium	egenolfioides M.G.Price	\N	\N	\N	Pteridophyte	Endangered	Endemic	LUZON: Luzon (Mt Makiling, several collections from this type locality), Nueva Vizcaya (Sta Fe, mtns N of Imugan, c. 1200m)
223	Athyriaceae	Diplazium	propinquum (Copel.) Alderw.	\N	\N	\N	Pteridophyte	Endangered	Endemic	MINDANAO: Agusan.
224	Begoniaceae	Begonia	acclivis C.Coyle	\N	\N	\N	Angiosperm	Endangered	Endemic	PALAWAN.
225	Begoniaceae	Begonia	aequata A.Gray	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Laguna (Mt Makiling).
226	Begoniaceae	Begonia	androturba C.Coyle	\N	\N	\N	Angiosperm	Endangered	Endemic	No available information.
227	Begoniaceae	Begonia	apayaoensis Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Apayao.
228	Begoniaceae	Begonia	brevipes Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Cagayan, MINDANAO: Lanao.
229	Begoniaceae	Begonia	casiguranensis Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Aurora (Casiguran, Cabulig River). Along streams in open places at low elevation.
230	Begoniaceae	Begonia	gracilipes Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Cagayan, CATANDUANES.
231	Begoniaceae	Begonia	macgregorii Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Isabela, Nueva Vizcaya.
232	Begoniaceae	Begonia	megalantha Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Aurora, Ifuago, Mountain Province.
233	Begoniaceae	Begonia	palawanensis Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	PALAWAN. Along small streams in low elevation primary forests.
234	Begoniaceae	Begonia	platyphlla Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Aurora, Nueva Vizcaya.
235	Begoniaceae	Begonia	ramosii Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Laguna.
236	Begoniaceae	Begonia	rubiteae M.Hughes	\N	\N	\N	Angiosperm	Endangered	Endemic	PALAWAN: Busuanga Isl.
237	Blechnaceae	Brainea	insignis (Hook.) J.Sm	\N	\N	cycad fern	Pteridophyte	Endangered	Indigenous	MINDORO.
238	Centrolepidaceae	Centrolepis	philippinensis Merr.	\N	\N	\N	Angiosperm	Endangered	Indigenous	LUZON: Mt. Pulag, MINDORO: Mt Halcon.
239	Cibotiaceae	Cibotium	barometz (L.) J.Sm., London J. Bot.	\N	\N	golden fern	Pteridophyte	Endangered	Indigenous	LUZON: Mountain Province (near Bontoc).
240	Cibotiaceae	Cibotium	cumingii Kunze, Farrnkräuter	\N	\N	golden fern	Pteridophyte	Endangered	Indigenous	LUZON, MINDANAO, MINDORO.
241	Combretaceae	Terminalia	darlingii Merr.	\N	\N	Malaputat	Angiosperm (Tree)	Endangered	Endemic	LUZON: Isabela, Aurora, Camarines, SAMAR. Primary forests at low elevation.
242	Cyatheaceae	Cyathea	acuminata Copel.	\N	\N	\N	Pteridophyte	Endangered	Endemic	PANAY, SAMAR.
243	Cyatheaceae	Cyathea	apoensis Copel.	\N	\N	\N	Pteridophyte	Endangered	Endemic	LUZON: Aurora, Laguna, Quezon, MINDANAO: Davao, Misamis Occidental, MINDORO, NEGROS.
244	Cyatheaceae	Cyathea	atropurpurea Copel.	\N	\N	\N	Pteridophyte	Endangered	Endemic	MINDANAO: Agusan del Norte, Davao, MINDORO.
245	Cyatheaceae	Cyathea	binuangensis Alderw.	\N	\N	\N	Pteridophyte	Endangered	Endemic	LUZON, TAWI-TAWI.
246	Cyatheaceae	Cyathea	christii Copel.	\N	\N	\N	Pteridophyte	Endangered	Endemic	MINDANAO: Bukidnon, Davao Oriental, North Cotabato, NEGROS.
247	Cyatheaceae	Cyathea	contaminans (Wall. ex Hook.) Copel.	\N	\N	\N	Pteridophyte	Endangered	Indigenous	Throughout the Philippines. Usually common in open places and light forests from near sea-level to 1300m.
248	Cyatheaceae	Cyathea	edanoi Copel.	\N	\N	\N	Pteridophyte	Endangered	Endemic	LUZON: Cagayan, Quezon.
249	Cyatheaceae	Cyathea	ferruginea Christ	\N	\N	\N	Pteridophyte	Endangered	Endemic	BALABAC, NEGROS, PALAWAN.
250	Cyatheaceae	Cyathea	lepifera (J.Sm. ex Hook.) Copel.	\N	\N	\N	Pteridophyte	Endangered	Indigenous	BABUYAN, LUZON, MINDORO, PANAY.
251	Cyatheaceae	Cyathea	masapilidensis Copel.	\N	\N	\N	Pteridophyte	Endangered	Endemic	LUZON: Benguet, MINDANAO: Bukidnon.
252	Cyatheaceae	Cyathea	rufopannosa Christ	\N	\N	\N	Pteridophyte	Endangered	Endemic	MINDANAO: Zamboanga.
253	Cyatheaceae	Cyathea	zamboangana Copel.	\N	\N	\N	Pteridophyte	Endangered	Endemic	MINDANAO: Agusan, Zamboanga, NEGROS, SAMAR.
254	Cycadaceae	Cycas	lacrimans KD. Hill & Lindst.	\N	\N	\N	Gymnosperm (Tree)	Endangered	Endemic	MINDANAO: Davao Oriental (Mati; San Isidro, Mt Galintan; Mt Hamiguitan).
255	Cycadaceae	Cycas	nitida KD. Hill & Lindstr.	\N	\N	\N	Gymnosperm (Tree)	Endangered	Endemic	LUZON: Quezon, POLILLO, ALABAT, RAPU-RAPU.
256	Cycadaceae	Cycas	wadei Merr.	\N	\N	Culion pitogo	Gymnosperm (Tree)	Endangered	Endemic	CULION. Culion Is.
257	Dennstaedtiaceae	Dennstaedtia	articulata Copel.	\N	\N	\N	Pteridophyte	Endangered	Endemic	No available information.
258	Dennstaedtiaceae	Dennstaedtia	fusca Copel.	\N	\N	\N	Pteridophyte	Endangered	Endemic	PANAY.
259	Dennstaedtiaceae	Microlepia	protracta Copel.	\N	\N	\N	Pteridophyte	Endangered	Endemic	BALUT.
260	Dicksoniaceae	Dicksonia	mollis Holttum	\N	\N	\N	Pteridophyte	Endangered	Indigenous	Negros: Negros Oriental, Dumaguete, Cuernos
261	Dilleniaceae	Dillenia	sibuyanensis Merr.	\N	\N	Sibuyan katmon	Angiosperm (Tree)	Endangered	Endemic	SIBUYAN (Mt Giting-giting), PANAY: Aklan.
262	Dipterocarpaceae	Anisoptera	costata Korth.	\N	\N	Mindanao palosapis	Angiosperm (Tree)	Endangered	Indigenous	MINDANAO (Zamboanga, one record). Primary lowland forest.
263	Dipterocarpaceae	Dipterocarpus	eurhynchus Miq.	\N	\N	Basilan apitong	Angiosperm (Tree)	Endangered	Indigenous	BASILAN. Local, on undulating land in lowland primary dipterocarp forest.
264	Dipterocarpaceae	Hopea	acuminata Merr.	\N	\N	Manggachapui	Angiosperm (Tree)	Endangered	Endemic	MINDORO, SAMAR, LEYTE, MINDANAO: Zamboanga, Misamis, Cotabato, Davao. Common in semi-evergreen and evergreen forests
265	Dipterocarpaceae	Shorea	ovata Dyer ex Brandis	\N	\N	tiaong	Angiosperm (Tree)	Endangered	Indigenous	MINDANAO: Misamis Oriental, Agusan del Norte (Tungao), Primary forests at medium elevations to c. 900m.
266	Dipterocarpaceae	Vatica	mangachapoi Blanco	ssp.obtusifolia\n(Elmer) Ashton	\N	Palawan Narig	Angiosperm (Tree)	Endangered	Endemic	PALAWAN.
267	Dipterocarpaceae	Vatica	maritima Slooten	\N	\N	narig laut	Angiosperm (Tree)	Endangered	Indigenous	PALAWAN (Taytay, NE foot of Mt Capoas).
268	Dryopteridaceae	Dryopteris	chrysocoma C.Chr.	\N	\N	\N	Pteridophyte	Endangered	Indigenous	No available information.
269	Dryopteridaceae	Dryopteris	permagna M.G.Price	\N	\N	\N	Pteridophyte	Endangered	Endemic	LUZON: Benguet, Kalinga, Mountain Province, MINDANAO: South Cotabato.
270	Dryopteridaceae	Polystichum	nudum Copel.	\N	\N	\N	Pteridophyte	Endangered	Endemic	No available information.
271	Ericaceae	Rhododendron	javanicum (Blume) Benn.	ssp. palawanense Argent	\N	malagos	Angiosperm	Endangered	Indigenous	LUZON: Apayao (Mt Magnas), Kalinga (Tinglayan), Ifugao (Mt Polis), Abra, Mountain Province, Benguet, PALAWAN (Mt Mantalingahan), CAMIGUIN (Hibok-hibok Volcano), JOLO, MINDANAO: Zamboanga (Sax River); Lanao del Sur (Camp Keithley, along Lake Lanao), Bukidnon (Kaatoan), Davao (Mt Apo; Mt Calelan), South Cotabato (Mt Matutum).
272	Ericaceae	Rhododendron	madulidii Argent	\N	\N	\N	Angiosperm	Endangered	Endemic	PALAWAN: Mt Mantalingahan, near Brookes Point.
273	Ericaceae	Rhododendron	xanthopetalum Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Nueva Vizcaya (Caraballo Sur Mtns), Bataan (Mt Mariveles), Rizal (Montalban), MINDORO: (Ibolo). In Bataan, an epiphyte in mossy forest, 1200m. 
274	Fabaceae	Afzelia	rhomboidea (Blanco) S.Vidal	\N	\N	tindalo	Angiosperm (Tree)	Endangered	Indigenous	N LUZON to PALAWAN and MINDANAO.
275	Fabaceae	Koompassia	excelsa (Becc.) Taub.	\N	\N	manggis	Angiosperm (Tree)	Endangered	Indigenous	PALAWAN: Puerto Princesa Subterranean River Natural Park; Aborlan (Sagpangan).
276	Fabaceae	Sindora	supa Merr.	\N	\N	supa	Angiosperm (Tree)	Endangered	Endemic	LUZON: Aurora (Baler), Nueva Ecija, Quezon (Lagumanoc; Pagbilao; Atimonan, Guinayangan), Camarines, Albay, MINDORO.
277	Fabaceae	Strongylodon	macrobotrys A.Gray	\N	\N	tayabak, jade vine	Angiosperm	Endangered	Endemic	LUZON: Benguet (Baguio), Cagayan (Baguio Cove; Peñablanca), Aurora (Casiguran), Bataan (Lamao River), Rizal (Mt Irid), Laguna (Mt Makiling; Paete-Piapi), Cavite, Quezon (Mt Binuang; Lucban; Guinayangan; Sampaloc; Kabibihan), Sorsogon (Mt Bulusan), CATANDUANES, MINDORO: Mindoro Occidental (Mt Calavite), Mindoro Oriental (Baco River; Mansalay, Mt Yagaw).
278	Fabaceae	Sympetalandra	densiflora (Elmer) Steenis	\N	\N	kamatog	Angiosperm (Tree)	Endangered	Endemic	LUZON: Cagayan, Rizal, Quezon (Lucban; Bulin; Dugatan; Guinayangan), Camarines, Sorsogon, PALAWAN, SAMAR, MINDANAO: Zamboanga, Lanao.
279	Gesneriaceae	Aeschynanthus	firmus Kraenzl.	\N	\N	Lanao lipstick plant	Angiosperm	Endangered	Endemic	MINDANAO: Lanao del Sur. Forests at or above 500m.
280	Gesneriaceae	Aeschynanthus	littoralis Schltr.	\N	\N	Davao lipstick plant	Angiosperm	Endangered	Endemic	MINDANAO: Davao. On trees overhanging the seashore.
281	Gesneriaceae	Aeschynanthus	nervosus Schltr.	\N	\N	Chila	Angiosperm	Endangered	Endemic	LUZON: Mountain Province, Benguet. Damp shaded ravines and in the mossy forest, 1400-2400m.
282	Gesneriaceae	Aeschynanthus	ovatus Schltr.	\N	\N	round-leafed lipstick plant	Angiosperm	Endangered	Endemic	MINDANAO: Lanao del Sur (Camp Keithley). Forests, c. 600m. 
283	Gesneriaceae	Agalmyla	bilirana Hilliard & BL Burtt	\N	\N	\N	Angiosperm	Endangered	Endemic	BILIRAN (Mt Suiro (N slope); Naval, Libtong). Possible variants in LEYTE. 
284	Gesneriaceae	Agalmyla	montis-tomasii Hilliard & BL Burtt	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Benguet (Mt Sto Tomas). Stunted ridge forest, 1800m.
285	Hamamelidaceae	Embolanthera	spicata Merr.	\N	\N	Paningit	Angiosperm (Tree)	Endangered	Endemic	PALAWAN: Mt Victoria. Along rocky riverbanks and in forests, 50-250m. 
286	Hookeriaceae	Distichophyllum	noguchianum B.C.Tan	\N	\N	\N	Bryophyte	Endangered	Endemic	No available information.
287	Lamiaceae	Tectona	philippinensis Benth. & Hook.f.	\N	\N	bunglas, Philippine teak	Angiosperm (Tree)	Endangered	Endemic	LUZON: Batangas, ILIN (off SW coast of Mindoro Occidental prov.).
288	Lamiaceae	Vitex	parviflora Juss.	\N	\N	molave	Angiosperm (Tree)	Endangered	Indigenous	Throughout the Philippines in most islands and provinces.
289	Lauraceae	Cinnamomum	cebuense Kosterm.	\N	\N	Cebu kalingag	Angiosperm (Tree)	Endangered	Endemic	CEBU: Cantipla. Mountain forest, 800m. 
290	Lauraceae	Cryptocarya	palawanensis Merr.	\N	\N	Paren	Angiosperm (Tree)	Endangered	Endemic	PALAWAN: Taytay; Mt Pulgar; Irawan River Valley. Lowland forests
291	Lauraceae	Litsea	leytensis Merr.	\N	\N	Batikuling	Angiosperm (Tree)	Endangered	Endemic	LUZON: Bataan, Quezon, Sorsogon, NEGROS, LEYTE. Lowland forests.
292	Lejeuneaceae	Drepanolejeunea	bakeri Herzog	\N	\N	\N	Bryophyte	Endangered	Endemic	No available information.
293	Lycopodiaceae	Phlegmariurus	carinatus (Desv. ex Poir.) Ching	\N	\N	\N	Pteridophyte	Endangered	Indigenous	No available information.
294	Lycopodiaceae	Phlegmariurus	elmeri (Herter) A.R.Field & Bostock	\N	\N	\N	Pteridophyte	Endangered	Endemic	LUZON: Benguet, Tayabas, MINDANAO: Cotabato, Davao, MINDORO, PALAWAN.
295	Lycopodiaceae	Phlegmariurus	phlegmaria (L.) Holub	\N	\N	tagulaylay	Pteridophyte	Endangered	Indigenous	PALAWAN.
296	Lycopodiaceae	Phlegmariurus	salvinioides (Herter) Ching	\N	\N	tagulaylay	Pteridophyte	Endangered	Indigenous	LUZON: Cagayan, PALAWAN, PANAY
297	Lycopodiaceae	Phlegmariurus	squarrosa (G.Forst.) Á.Löve & D.Löve	\N	\N	\N	Pteridophyte	Endangered	Indigenous	MINDANAO: Bukidnon, PALAWAN.
298	Lythraceae	Pemphis	acidula J.R.Forst. & G.Forst.	\N	\N	bantigi	Angiosperm (Tree)	Endangered	Indigenous	Throughout the Philippines along seashores.
299	Malvaceae	Camptostemon	philippinense (S.Vidal) Becc.	\N	\N	gapas-gapas	Angiosperm (Tree)	Endangered	Indigenous	LUZON: Quezon, PALAWAN, MASBATE, PANAY, NEGROS, BOHOL, BASILAN, MINDANAO: Zamboanga. Edges of mangroves and tidal streams.
300	Malvaceae	Durio	graveolens Becc.	\N	\N	red durian	Angiosperm (Tree)	Endangered	Indigenous	PALAWAN.
301	Marattiaceae	Christensenia	aesculifolia (Blume) Maxon	\N	\N	bungau	Pteridophyte	Endangered	Indigenous	PALAWAN
302	Matoniaceae	Matonia	foxworthyi Copel.	\N	\N	\N	Pteridophyte	Endangered	Indigenous	MINDORO, SIBUYAN.
303	Melastomataceae	Astrocalyx	calycina (Vidal) Merr.	\N	\N	bungau	Angiosperm (Tree)	Endangered	Endemic	LUZON: Laguna, Quezon, Camarines Norte (Maniba River near Daet), Albay, Rizal, Sorsogon, CATANDUANES, LEYTE (Dagami) SAMAR, MINDANAO: Bukidnon, Davao del Sur, Lanao del Norte, ?Misamis Occidental. Primary forests, often in damp areas, 550-1700m.
304	Melastomataceae	Medinilla	apayaoensis Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Apayao.
305	Melastomataceae	Medinilla	banahaensis Elmer	\N	\N	Kalambog-lambog	Angiosperm	Endangered	Endemic	LUZON: Rizal, Quezon (Mt Banahaw), MINDANAO: Bukidnon, Davao. Mossy forests, 1200-2000m.
306	Melastomataceae	Medinilla	binaria Elmer	\N	\N	\N	Angiosperm	Endangered	Endemic	NEGROS: Negros Oriental (Cuernos Mtns)
308	Melastomataceae	Medinilla	calelanensis Elmer	\N	\N	Tiualos tatana	Angiosperm	Endangered	Endemic	MINDANAO: Bukidnon (Mt Candoon and Mt Lipa), Davao (Mt Apo; Mt Calelan). Mossy forests along streams, 1800-2300m
309	Melastomataceae	Medinilla	capitata Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	DINAGAT.
310	Melastomataceae	Medinilla	clementis Merr.	\N	\N	Gubangbang	Angiosperm	Endangered	Endemic	LUZON: Kalinga, Ifugao (Mt Polis), Mountain Province, Benguet, Isabela, Rizal, Sorsogon, Endemic to the Philippines. MINDORO, PANAY, NEGROS, LEYTE, MINDANAO: Lanao del Sur (Camp Keithley), Bukidnon, Mt. Apo. Exposed ridges or slopes, along streams in mossy forests or on summits at 1000-2000(-2300)m. 
311	Melastomataceae	Medinilla	compressicaulis Merr.	\N	\N	Salanakad	Angiosperm	Endangered	Endemic	LUZON: Abra (trail to Balbalasang), Ifugao, Mountain Province, Benguet. Mossy forests, 1000-2200m
312	Melastomataceae	Medinilla	coronata Regalado	\N	\N	Pagirang	Angiosperm	Endangered	Endemic	LUZON: Cagayan (Mt Cetaceo), Ifugao (Mt Polis), Benguet, Pampanga. Thickets & forests, 1000-1700m.
313	Melastomataceae	Medinilla	lagunae S.Vidal & Fern.-Vill.	\N	\N	palikpik-hito	Angiosperm	Endangered	Endemic	LUZON, CATANDUANES.
314	Melastomataceae	Medinilla	miniata Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Camarines Norte, CATANDUANES, LEYTE.
315	Melastomataceae	Medinilla	palawanensis Regalado	\N	\N	Palawan medinilla	Angiosperm	Endangered	Endemic	PALAWAN: Mt Bloomfield; Victoria Mtns at Narra and Panacan; Mt Mantalingahan. Epiphytic on forests over ultramafics, 150-1000m.
316	Melastomataceae	Medinilla	pendula Merr.	\N	\N	Baladu	Angiosperm	Endangered	Endemic	LUZON: Abra, Mountain Province, Benguet, Isabela, Pampanga (Mt Pinatubo), MINDORO, SIBUYAN (Mt Giting-giting), CEBU, MINDANAO: Lanao, Davao (Mt Apo). In mossy forests; along creeks and streams, damp ravines and overhanging damp banks, also epiphytic, (450-)1000-2000m. Common in the Cordillera Highlands of N LUZON
317	Melastomataceae	Medinilla	stenobotrys Merr.	\N	\N	Lalanug	Angiosperm	Endangered	Endemic	LUZON: Apayao, Kalinga, Isabela (Palanan), Quezon. Forests along streams, (40-)600-800m. 
318	Melastomataceae	Medinilla	surigaoensis Regalado	\N	\N	hagod	Angiosperm	Endangered	Endemic	LUZON, POLILLO, MINDANAO: Surigao del Norte. Lowland forests, 0-150m
319	Melastomataceae	Medinilla	tayabensis Merr.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Ilocos Norte, Quezon (Mt Binuang). Mossy forests, c. 700m.
320	Meliaceae	Walsura	monophylla Merr.	\N	\N	Bukalau	Angiosperm (Tree)	Endangered	Endemic	 PALAWAN: Puerto Princesa (Mt Bloomfield; Langogan; Bacungan), Aborlan (Malasgao River; Mt Victoria), Brooke’s Point. Often in stunted ultramafic forests.
321	Myrtaceae	Xanthostemon	verdugonianus Naves	\N	\N	Mangkono	Angiosperm (Tree)	Endangered	Endemic	IBUYAN, LEYTE, HOMONHON, DINAGAT, BUCAS GRANDE, SIARGAO, MINDANAO: Surigao del Sur. Lowland and medium elevation forests and regrowths on ultramafics. 
322	Nepenthaceae	Nepenthes	bellii Kondo	\N	\N	\N	Angiosperm	Endangered	Endemic	MINDANAO: Surigao del Norte, Surigao del Sur. Marshy forests, possibly on ultramafic substrate, 250-800m.
323	Nepenthaceae	Nepenthes	burkei Mast.	\N	\N	\N	Angiosperm	Endangered	Endemic	MINDORO: Mindoro Oriental (Mt Halcon), PANAY: Antique (Mt Madia-as). Mossy forests, 1000-1600m. 
324	Nepenthaceae	Nepenthes	ceciliae Gronem. et al.	\N	\N	\N	Angiosperm	Endangered	Endemic	Mindanao: Bukidnon, Mount Kiamo, trail from Barangay Kibalabag (Malaybalay City)
325	Nepenthaceae	Nepenthes	copelandii Merrill ex Macfarl.	\N	\N	\N	Angiosperm	Endangered	Endemic	CAMIGUIN, MINDANAO: Davao del Sur (Mt Apo), epiphytic at elevations from 2500-3000 m.
326	Nepenthaceae	Nepenthes	gantungensis S.McPherson et al.	\N	\N	\N	Angiosperm	Endangered	Endemic	PALAWAN: Mt. Gantung
327	Nepenthaceae	Nepenthes	mantalingajanensis J. Nerz & A. Wistuba	\N	\N	\N	Angiosperm	Endangered	Endemic	PALAWAN (Mt Mantalingahan). On ultramafic soils.
328	Nepenthaceae	Nepenthes	petiolata Danser	\N	\N	\N	Angiosperm	Endangered	Endemic	MINDANAO: Agusan del Norte (Mt Urdaneta), Surigao del Sur. Montane or submontane forest including Agathis and oak, possibly on ultramafic soil in Surigao, 1500-1600m.
329	Nepenthaceae	Nepenthes	philippinensis Macfarl.	\N	\N	Kuong-kuong	Angiosperm	Endangered	Endemic	PALAWAN (Mt. Pulgar (Thumb Peak); Victoria Mtns), on scrub over ultramafic soils, 25-1600m.
330	Nepenthaceae	Nepenthes	saranganiensis Sh.Kurata	\N	\N	\N	Angiosperm	Endangered	Endemic	Mindanao: Sarangani Prov.
331	Nepenthaceae	Nepenthes	sumagaya Cheek	\N	\N	\N	Angiosperm	Endangered	Endemic	Mindanao: Misamis Oriental, Claveria, Mt. Sumagaya
332	Nepenthaceae	Nepenthes	surigaoensis Elmer	\N	\N	\N	Angiosperm	Endangered	Endemic	MINDANAO: Agusan del Norte (Mt. Urdaneta).
333	Nepenthaceae	Nepenthes	truncata Macfarl.	\N	\N	Sandaoua	Angiosperm	Endangered	Endemic	MINDANAO: Agusan del Norte (Mt Hilong-hilong), Surigao del Norte (Cansuran; Samsolang). Wet forests, ridges, exposed rock cliff among tall grasses, on ultramafics in Surigao del Norte, 225-600m. 
334	Nepenthaceae	Nepenthes	ultra Jebb & Cheek	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Aurora, Isabela, Zambales.
335	Nepenthaceae	Nepenthes	ventricosa Blanco	\N	\N	Kako	Angiosperm	Endangered	Endemic	 LUZON: Aurora, Cagayan, Ilocos Norte, Ifugao, Nueva Ecija, Nueva Vizcaya, Mountain Province, Bataan, Quezon, Rizal, Camarines, Albay, Sorsogon. Usually on mossy oak forests, 600-1500m.
336	Nepenthaceae	Nepenthes	viridis Micheler et al.	\N	\N	\N	Angiosperm	Endangered	Endemic	SAMAR, DINAGAT.
337	Ophioglossaceae	Botrychium	lanuginosum Wall. ex Hook. & Grev.	\N	\N	grape fern	Pteridophyte	Endangered	Indigenous	No available information.
338	Ophioglossaceae	Ophioglossum	pendulum L.	\N	\N	\N	Pteridophyte	Endangered	Indigenous	Throughout the Philippines.
339	Ophioglossaceae	Ophioglossum	ramosii Copel.	\N	\N	\N	Pteridophyte	Endangered	Endemic	CAMIGUIN, MINDANAO: Bukidnon
340	Orchidaceae	Aerides	lawrenciae Reichb.f.	\N	\N	\N	Angiosperm	Endangered	Endemic	CEBU, LEYTE, MINDANAO: Bukidnon, Cotabato, Davao, Misamis Oriental. Epiphyte up to 500m.
341	Orchidaceae	Amesiella	philippinensis (Ames) Garay	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Benguet, Mountain Province, Nueva Vizcaya, Albay, MINDORO: Mindoro Oriental (Mt Halcon). Epiphytic, 400-1400m.
342	Orchidaceae	Arachnis	flos-aeris (L.) Rchb.f.	\N	\N	\N	Angiosperm	Endangered	Indigenous	LUZON: Quezon, BILIRAN, LEYTE, PALAWAN, MINDANAO: Surigao.
343	Orchidaceae	Bulbophyllum	facetum Garay, Hamer &\nSiegerist	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Nueva Ecija, Nueva Vizcaya.
344	Orchidaceae	Bulbophyllum	nymphopolitanum Kraenzl.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Albay, MINDORO.
345	Orchidaceae	Bulbophyllum	philippinense Ames	\N	\N	\N	Angiosperm	Endangered	Endemic	MINDORO, LEYTE.
346	Orchidaceae	Bulbophyllum	piestoglossum J.J.Verm.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Laguna, Quezon.
347	Orchidaceae	Bulbophyllum	stellatum Ames	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Nueva Ecija, Nueva Vizcaya.
348	Orchidaceae	Cirrhopetalum	cumingii Lindl.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Aurora, Cagayan, Rizal, Cavite, Laguna, Quezon, PALAWAN: Lake Manguao, PANAY: Capiz, NEGROS: Negros Occidental, LEYTE, SAMAR
349	Orchidaceae	Cirrhopetalum	loherianum Kranzl.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Aurora, Laguna, Quezon, Camarines Sur, Nueva Vizcaya, Nueva Ecija, LEYTE, MINDANAO: Surigao del Norte, Surigao del Sur, SAMAR.
350	Orchidaceae	Cleisostoma	sagittatum Blume,	\N	\N	\N	Angiosperm	Endangered	Indigenous	PALAWAN, MINDANAO: Agusan.
351	Orchidaceae	Coelogyne	confusa Ames	\N	\N	\N	Angiosperm	Endangered	Endemic	Ramos, Camiguin.
352	Orchidaceae	Coelogyne	palawanensis Ames	\N	\N	\N	Angiosperm	Endangered	Endemic	PALAWAN (Mt Capoas), 1000m.
353	Orchidaceae	Corybas	laceratus LO Williams	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Rizal. 
354	Orchidaceae	Corybas	merrillii (Ames) Ames	\N	\N	\N	Angiosperm	Endangered	Endemic	 LUZON: Bataan (Mt Mariveles), Laguna (Mt Makiling). Terrestrial on mossy cliffs. 
355	Orchidaceae	Corybas	ramosianus J Dransf.	\N	\N	\N	Angiosperm	Endangered	Endemic	No available information.
356	Orchidaceae	Cymbidium	aliciae Quisumb.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Nueva Vizcaya, Rizal, MINDORO, NEGROS: Negros Occidental, SAMAR. Terrestrial in shaded sites, 300-2750m.
357	Orchidaceae	Cymbidium	ensifolium (L.) Sw.	\N	\N	\N	Angiosperm	Endangered	Endemic	No available information.
358	Orchidaceae	Dendrobium	bullenianum Rchb.f	\N	\N	\N	Angiosperm	Endangered	Endemic	No available information.
359	Orchidaceae	Dendrobium	goldschmidtianum Kraenzl.	\N	\N	\N	Angiosperm	Endangered	Indigenous	BATANES, CAMIGUIN DE BABUYANES.
360	Orchidaceae	Dendrobium	lunatum Lindl.	\N	\N	\N	Angiosperm	Endangered	Endemic	PALAWAN. Epiphytic, sea-level to 500m.
361	Orchidaceae	Grammatophyllum	martae Quisumb. ex\nValmayor & D.Tiu	\N	\N	\N	Angiosperm	Endangered	Endemic	NEGROS.
362	Orchidaceae	Grammatophyllum	measuresianum Sander	\N	\N	\N	Angiosperm	Endangered	Indigenous	LUZON: Batangas, Cavite, MINDORO, PALAWAN, LUMBUCAN.
363	Orchidaceae	Phalaenopsis	hieroglyphica (Reichb.f.) HR Sweet	\N	\N	\N	Angiosperm	Endangered	Endemic	POLILLO, PALAWAN, MINDANAO: Surigao del Norte, Surigao del Sur. Epiphyte in deep shade, to 500m.
364	Orchidaceae	Phalaenopsis	lindenii Loher	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Mountain Province, Benguet, Isabela, Nueva Vizcaya, Nueva Ecija. Epiphyte, 1000-1500m.
365	Orchidaceae	Phalaenopsis	lueddemanniana Reichb.f.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Apayao, Kalinga, Nueva Vizcaya, Pangasinan, Bataan, Bulacan, Rizal, Laguna, Laguna, Camarines Norte, Sorsogon, POLILLO, PALAWAN, LEYTE, MINDANAO: Lanao del Norte, Lanao del Sur, Bukidnon, Davao del Norte, Davao del Sur, Davao Oriental, Agusan del Norte, Agusan del Sur, SAMAR. Epiphyte, to 500m. 
366	Orchidaceae	Phalaenopsis	pallens (Lindl.) Reichb.f.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Nueva Vizcaya, Bataan (Mt Mariveles), Bulacan, Rizal, PALAWAN, MINDANAO: Bukidnon. Epiphyte, to 500m.
367	Orchidaceae	Phalaenopsis	philippinensis (Golamco) ex Fowlie & C.Z.Tsang	\N	\N	\N	Angiosperm	Endangered	Endemic	No available information.
368	Orchidaceae	Phalaenopsis	pulchra (Reichb.f) HR Sweet	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Nueva Vizcaya, Nueva Ecija, LEYTE. Epiphyte, to 500m.
369	Orchidaceae	Phalaenopsis	reichenbachiana Reichb.f. & Sander	\N	\N	\N	Angiosperm	Endangered	Endemic	No available information.
370	Orchidaceae	Phalaenopsis	sanderiana Reichb.f.	\N	\N	\N	Angiosperm	Endangered	Endemic	MINDANAO: Zamboanga del Norte, Zamboanga del Sur, Lanao del Sur, South Cotabato, Davao del Sur. Epiphytic, to 500m. 
371	Orchidaceae	Phalaenopsis	schilleriana Reichb.f.	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Rizal, Laguna, Quezon, Albay, Sorsogon, MARINDUQUE, BILIRAN. Epiphyte, up to 800m.
372	Orchidaceae	Phalaenopsis	stuartiana Reichb.f.	\N	\N	\N	Angiosperm	Endangered	Endemic	MINDANAO: Misamis Oriental, Bukidnon, Agusan del Norte, Agusan del Sur, Surigao del Norte, Surigao del Sur. Epiphytic at low elevation to 300m.
373	Orchidaceae	Phalaenopsis	x veitchiana Rchb.f	\N	\N	\N	Angiosperm	Endangered	Endemic	No available information.
374	Orchidaceae	Phalaenopsis	amabilis (L.) Blume	\N	\N	\N	Angiosperm	Endangered	Indigenous	No available information.
375	Orchidaceae	Renanthera	monachica Ames	\N	\N	\N	Angiosperm	Endangered	Endemic	No available information.
376	Orchidaceae	Renanthera	philippinensis (Ames &\nQuisumb.) L.O.Williams	\N	\N	\N	Angiosperm	Endangered	Endemic	No available information.
377	Orchidaceae	Renanthera	storiei Rchb.f.	\N	\N	\N	Angiosperm	Endangered	Endemic	No available information.
378	Orchidaceae	Staurochilus	leytensis (Ames) Christenson	\N	\N	\N	Angiosperm	Endangered	Endemic	No available information.
379	Orchidaceae	Trichoglottis	loheriana (Kraenzl.) L.O.Williams	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Quezon, Rizal, SAMAR.
380	Orchidaceae	Trichoglottis	luzonensis (Ames) Ames	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Quezon, Camarines Sur, MINDANAO: Agusan.
381	Orchidaceae	Vanda	javierae D Tiu ex Fessel & Lückel	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Pangasinan. Epiphyte, usually close to water, c. 1200m.
382	Orchidaceae	Vanda	luzonica Loher ex Rolfe	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Zambales, Bulacan, Rizal. Epiphyte, c. 500m.
383	Orchidaceae	Vanda	merrillii Ames & Quisumb.	\N	\N	\N	Angiosperm	Endangered	Endemic	No available information.
384	Orchidaceae	Vanda	scandens Holttum	\N	\N	\N	Angiosperm	Endangered	Indigenous	No available information.
385	Poaceae	Rytidosperma	oreoboloides (F.Muell.) H.P.Linder	\N	\N	Pulag carpet grass	Angiosperm	Endangered	Indigenous	LUZON: Benguet (near summit of Mt Pulag).
386	Podocarpaceae	Podocarpus	costalis C.Presl	\N	\N	igem-dagat	Gymnosperm (Tree)	Endangered	Indigenous	BATANES, BABUYAN ISLS, LUZON: Isabela, POLILLO. Coastal bluffs near sea-level to at least 300m.
387	Podocarpaceae	Podocarpus	macrocarpus de Laub.	\N	\N	igem-lakibunga	Gymnosperm (Tree)	Endangered	Endemic	LUZON: Benguet, Ilocos Norte, Mountain Province, Queson, Zambales.
388	Podocarpaceae	Podocarpus	ramosii R.R.Mill	\N	\N	igem-bilogan	Gymnosperm (Tree)	Endangered	Indigenous	LUZON: Camarines Sur, Laguna (Mt Banahaw), Quezon (Mt Banahaw de Lucban).
389	Polypodiaceae	Lecanopteris	luzonensis Hennip.	\N	\N	ant fern	Pteridophyte	Endangered	Endemic	LUZON: Pangasinan, Pampanga, Bataan (Mt Mariveles), Laguna, Quezon, Camarines Norte.
390	Polypodiaceae	Lecanopteris	deparioides (Cesati) Baker	\N	\N	\N	Pteridophyte	Endangered	Indigenous	MINDANAO: Lanao del Sur, Davao (Mt Apo), Davao Oriental (Mt Hamiguitan).
391	Polypodiaceae	Lecanopteris	sarcopus (Teijsm. & Binn.) Copel.	\N	\N	\N	Pteridophyte	Endangered	Indigenous	LUZON: Nueva Ecija, Nueva Vizcaya.
392	Polypodiaceae	Lecanopteris	sinuosa (Wall. ex Hook.) Copel.	\N	\N	\N	Pteridophyte	Endangered	Indigenous	PALAWAN.
393	Polypodiaceae	Lepisorus	platyrhynchos (Kunze) Li Wang	\N	\N	tailed fern	Pteridophyte	Endangered	Indigenous	LUZON, MINDANAO: Agusan del Norte, Bukidnon, Davao, MINDORO.
394	Psilotaceae	Psilotum	complanatum Sw.	\N	\N	flat whisk fern	Pteridophyte	Endangered	Indigenous	No available information.
395	Psilotaceae	Tmesipteris	zamorae Gruezo & Amoroso,	\N	\N	Zamora whisk fern	Pteridophyte	Endangered	Endemic	LUZON: Benguet (Mt Pulog), Mountain Province (Mt Data), Quezon (Mt Banahaw), MINDANAO: Bukidnon (Mt Kitanglad), Cotabato-Davao (Mt Apo), Davao (Mt McKinley), Misamis Occidental (Mt Malindang), South Cotabato (Mt Matutum), MINDORO: Mt Halcon.
396	Pteridaceae	Adiantum (= Pteris)	mindanaoense Copel.	\N	\N	Mindanao maindenhair fern	Pteridophyte	Endangered	Endemic	MINDANAO: Bukidnon.
397	Pteridaceae	Ceratopteris	thalictroides (L.) Brongn.	\N	\N	\N	Pteridophyte	Endangered	Indigenous	LUZON, MINDANAO.
398	Pteridaceae	Doryopteris	concolor (Langsd & Fisch) Kuhn	\N	\N	\N	Pteridophyte	Endangered	Indigenous	No available information.
399	Pteridaceae	Pteris	endoneura MG Price	\N	\N	\N	Pteridophyte	Endangered	Endemic	LUZON: Camarines Norte, Quezon, SAMAR.
400	Rafflesiaceae	Rafflesia	baletei Barcelona & Cajano	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Camarines Sur (Mt Isarog National Park, ridge along Luksohon and Tabuan Rivers; Mt Iriga/Asog). Rocky riparian habitats and secondary vegetation covered with Musa textilis and bamboos, 500-560m.
401	Rafflesiaceae	Rafflesia	manillana Teschem.	\N	\N	Malaboo	Angiosperm	Endangered	Endemic	SAMAR: Western Samar (Basey). Lowland forests, up to c. 1000m.
402	Rafflesiaceae	Rafflesia	mira Fernando & Ong	\N	\N	\N	Angiosperm	Endangered	Endemic	MINDANAO: Compostela Valley (Mun. Maragusan, Mt Candalaga). In semi-open habitats, especially near waterfalls, in mid-montane rain forests at c. 900 m.
403	Rafflesiaceae	Rafflesia	philippensis Blanco ex Llanos	\N	\N	\N	Angiosperm	Endangered	Endemic	LUZON: Quezon (Dolores, base of Mt Banahaw). Disturbed lowland dipterocarp forest, on steep slopes, along trails and beside seasonal creeks and rivers on well-drained sandy soil with dense herbaceous covering or thick leaf litter. 
404	Rafflesiaceae	Rafflesia	speciosa Barcelona & Fernando	\N	\N	Uruy	Angiosperm	Endangered	Endemic	PANAY: Antique, Iloilo (Central Panay Mountain Range), NEGROS: Negros Occidental (Mt Kanlaon). 
405	Rhachitheciaceae	Rhachithecium	papillosum (Williams) Wijk & Margard.	\N	\N	\N	Bryophyte	Endangered	Endemic	No available information.
406	Rubiaceae	Antherostele	banahaensis (Elmer) Bremek.	\N	\N	\N	Angiosperm (Tree)	Endangered	Endemic	 LUZON: Isabela (Palanan), Rizal (Mt Lumutan), Quezon (Mt Binuang; Mt Banahaw de Lucban), Laguna (Mt Makiling), Sorsogon (Mt Bulusan). In damp primary forests at low and medium elevation, ascending to 1000m. 
407	Rubiaceae	Antherostele	grandistipula (Merr.) Bremek.	\N	\N	\N	Angiosperm (Tree)	Endangered	Endemic	 LUZON: Camarines, MINDORO, CATANDUANES, LEYTE: Leyte (Mtns near Dagami), Southern Leyte (Cabalian), SAMAR: Catubig River. In damp primary forests at low or medium elevation.
408	Rubiaceae	Boholia	nematostylis Merr.	\N	\N	\N	Angiosperm (Tree)	Endangered	Indigenous	BOHOL (Bilar; Kalingohan), CEBU.
409	Sapindaceae	Cubilia	cubili (Blanco) Adelb.	\N	\N	kubili	Angiosperm (Tree)	Endangered	Indigenous	LUZON: Benguet, Cagayan, Bataan, Bulacan, Rizal, Laguna, MINDORO, BILIRAN, SAMAR, MINDANAO: Zamboanga, Agusan, Surigao.
410	Sapindaceae	Gloeocarpus	patentivalvis (Radlk.) Radlk.	\N	\N	Tamaho	Angiosperm (Tree)	Endangered	Endemic	LUZON, LEYTE, SAMAR, MINDANAO. Lowland primary dipterocarp forest, along ridges, riverbanks, 60-400m. 
411	Sapindaceae	Guioa	acuminata Radlk.	\N	\N	Pasi	Angiosperm (Tree)	Endangered	Endemic	C & E LUZON, POLILLO. Lowland secondary forests up to 100m
412	Sapotaceae	Madhuca	betis (Blanco) JT McBride	\N	\N	Betis	Angiosperm (Tree)	Endangered	Endemic	LUZON: Cagayan, Isabela, Aurora, Quezon, Cavite, Camarines, MINDORO, MINDANAO: Cotabato. Primary Lowland rainforests
413	Sapotaceae	Madhuca	lanceolata Merr.	\N	\N	Malalóno	Angiosperm (Tree)	Endangered	Endemic	DINAGAT.
414	Sapotaceae	Madhuca	monticola (Merr.) Merr	\N	\N	bétis-bundók	Angiosperm (Tree)	Endangered	Endemic	PALAWAN, SIBUYAN.
415	Sapotaceae	Madhuca	oblongifolia (Merr.) Merr.	\N	\N	Malabetis	Angiosperm (Tree)	Endangered	Endemic	LUZON: Quezon (Infanta & Llavac), Camarines Norte (Paracale). Lowland primary forests
416	Sapotaceae	Madhuca	obovatifolia (Merr.)	\N	\N	Pianga	Angiosperm (Tree)	Endangered	Endemic	LUZON: Quezon (Guinayangan), Camarines Norte (near Daet).
417	Schizaeaceae	Actinostachys	inopinata (Selling) C.F.Reed	\N	\N	\N	Pteridophyte	Endangered	Indigenous	BOHOL.
418	Schizaeaceae	Schizaea	malaccana Baker	\N	\N	\N	Pteridophyte	Endangered	Indigenous	No available information.
419	Selaginellaceae	Selaginella	apoensis Hieron.	\N	\N	\N	Pteridophyte	Endangered	Endemic	MINDORO, MINDANAO.
420	Selaginellaceae	Selaginella	magnifica Warb.	\N	\N	\N	Pteridophyte	Endangered	Endemic	MINDANAO.
421	Selaginellaceae	Selaginella	pricei BC Tan & Jermy	\N	\N	\N	Pteridophyte	Endangered	Endemic	LEYTE, SAMAR.
422	Selaginellaceae	Selaginella	tamariscina (P.Beauv.) Spring	\N	\N	\N	Pteridophyte	Endangered	Indigenous	LUZON.
423	Simaroubaceae	Eurycoma	longifolia Jack	ssp. eglandulosa (Merr.) Noot.	\N	Linatog	Angiosperm (Tree)	Endangered	Endemic	MINDANAO: Surigao del Norte, DINAGAT. Lowland forests on ultramafics.
424	Stemonuraceae	Gomphandra	coi Schori	\N	\N	Co mabunót	Angiosperm (Tree)	Endangered	Endemic	LUZON.
425	Stemonuraceae	Gomphandra	psilandra Schori	\N	\N	\N	Angiosperm (Tree)	Endangered	Endemic	LUZON: Quezon.
426	Stemonuraceae	Gomphandra	ultramafiterrestris Schori	\N	\N	\N	Angiosperm (Tree)	Endangered	Endemic	DINAGAT, MINDANAO: Davao Oriental (Mt Hamiguitan).
427	Tectariaceae	Psomiocarpa	apiifolia C Presl	\N	\N	\N	Pteridophyte	Endangered	Endemic	BOHOL, LUZON: Cagayan, Isabela, Bataan, Rizal, Laguna (Mt Makiling), Quezon, POLILLO, MASBATE, LEYTE, PANAY, SAMAR, MINDANAO: Zamboanga (San Ramon).
428	Tectariaceae	Tectaria	lobbii (Hook.) Copel.	\N	\N	\N	Pteridophyte	Endangered	Indigenous	BOHOL, MINDANAO: Surigao del Sur.
429	Tectariaceae	Tectaria	macleanii (Copel.) S.Y.Dong	\N	\N	\N	Pteridophyte	Endangered	Indigenous	LEYTE, LUZON: Cagayan, Camarines Sur, Isabela, Quezon, PANAY, SAMAR.
430	Tectariaceae	Tectaria	stalactica MG Price	\N	\N	\N	Pteridophyte	Endangered	Endemic	LUZON: Cagayan, Ilocos Norte, Isabela, POLILLO.
431	Thymelaeaceae	Aquilaria	malaccensis Lam.	\N	\N	agarwood/bari	Angiosperm (Tree)	Endangered	Indigenous	LUZON.
432	Violaceae	Rinorea	niccolifera Fernando	\N	\N	\N	Angiosperm (Tree)	Endangered	Endemic	LUZON: Zambales.
433	Zingiberaceae	Hedychium	philippense K Schum.	\N	\N	Dainsuli	Angiosperm	Endangered	Endemic	LUZON: Rizal, Laguna, Quezon, Sorsogon, POLILLO, NEGROS, LEYTE, JOLO, MINDANAO. Lowland and medium elevation humid forests, ascending to 1100m, often epiphytic or pseudoepiphytic.
434	Acanthaceae	Gymnostachyum	palawanense Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: Puerto Princesa, Mt. Pulgar
435	Acanthaceae	Gymnostachyum	pictum Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
436	Acanthaceae	Justicia	addisoniensis (Elmer) C.M.Gao & Y.F.Deng	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN (Addison’s Peak; Ulugan Bay)
437	Acanthaceae	Justicia	pulgarensis (Elmer) C.M.Gao & Y.F. Deng	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN (Mt Pulgar; Aborlan, Mt Apis).
438	Acanthaceae	Lepidagathis	palawanensis Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: Taytay
439	Acanthaceae	Pseuderanthemum	minutiflorum (Elmer)\nMerr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: Puerto Princesa, Mt Pulgar (= Thumb Peak)
440	Acanthaceae	Ptyssiglottis	aequifolia (C.B.Clarke) Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: Puerto Princesa
441	Acanthaceae	Ptyssiglottis	elmeri Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: Mt Pulgar.
442	Acanthaceae	Ruellia	philippinensis Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN, BASILAN.
443	Acanthaceae	Staurogyne	nudispica (C.B.Clarke) Bremek.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: forests near Puerto Princesa
444	Acanthaceae	Strobilanthes	palawanensis Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN: Puerto Princesa (Mt Pulgar; Babuyan).
445	Actinidiaceae	Saurauia	bontocensis Merr.	\N	\N	Dagwey	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Abra, Mountain Province, Kalinga, Ifugao.
446	Actinidiaceae	Saurauia	longistyla Merr.	\N	\N	mutá-mutá	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: San Antonio Bay, in forests
447	Anacardiaceae	Dracontomelon	dao (Blanco) Merr. & Rolfe	\N	\N	Dao	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Cagayan to Sorsogon, MINDORO, PALAWAN, NEGROS, LEYTE, SAMAR, BASILAN, MINDANAO: Lanao, Cotabato, Agusan, Surigao.
448	Anacardiaceae	Mangifera	monandra Merr.	\N	\N	Malapaho	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Ilocos Norte, Pangasinan, Zambales, Bataan, Rizal, Laguna, Camarines, TICAO, GUIMARAS, LEYTE, SAMAR. Lowland primary forests. 
449	Anacardiaceae	Mangifera	altissima Blanco	\N	\N	pahutan	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Ilocos Sur, Cagayan, Nueva Ecija, Zambales, Rizal, Laguna, Quezon, Camarines, MINDORO, PALAWAN, SIBUYAN.
450	Anacardiaceae	Mangifera	longipes Griff.	\N	\N	apali	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN.
451	Anacardiaceae	Semecarpus	paucinervius Merr.	\N	\N	ligas-ilanan	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN: Mt Pulgar and Mt Victoria.
452	Anacardiaceae	Swintonia	acuta Engl.	\N	\N	lomarau	Angiosperm (Tree)	Vulnerable	Indigenous	CAMIGUIN DE BABUYANES, LUZON: Isabela, Aurora, Camarines, PALAWAN: Mt Pulgar and other sites in Palawan, PANAY.
453	Annonaceae	Dasymaschalon	scandens Merr.	\N	\N	kalabúyo	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Taytay-Bantolan trail, forested slopes
454	Annonaceae	Desmos	palawanensis (Elmer) Merr.	\N	\N	Palawan pirángat	Angiosperm (Tree)	Vulnerable	Endemic	LUZON, ALABAT, MINDORO PALAWAN, PANAY, CEBU
455	Annonaceae	Miliusa	horsfieldii (Benn.) Baill. ex Pierre	\N	\N	ubáran	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Brooks Point, Addison Peak
456	Annonaceae	Mitrephora	fragrans Merr.	\N	\N	lanútan-bangúhan	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Taytay
457	Annonaceae	Orophea	creaghii (Ridl.) Leonardia & Kessler	\N	\N	tabingálang	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Puerto Princesa, densely forested slopes along Balsahan River.
458	Annonaceae	Polyalthia	elmeri Merr.	\N	\N	Bangar	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN. Thin forests near the seashore.
459	Annonaceae	Polyalthia	palawanensis Merr.	\N	\N	Palawan lanutan	Angiosperm	Vulnerable	Endemic	PALAWAN.
460	Annonaceae	Uvaria	lurida Hook.f. & Thomson	\N	\N	\N	Angiosperm	Vulnerable	Indigenous	LUZON: Bataan, Benguet, Laguna, LEYTE, MINDANAO: Zamboanga, Agusan del Norte, PALAWAN.
461	Apocynaceae	Alstonia	iwahigensis Elmer	\N	\N	silhigan	Angiosperm	Vulnerable	Indigenous	PALAWAN (Mt Pulgar, Irawan River Valley), BALABAC.
462	Apocynaceae	Hoya	meliflua (Blanco) Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Apayao, La Union, Bataan, Rizal, Laguna, MINDANAO, MINDORO, PALAWAN (Taytay, Talimbobog), PANAY, NEGROS, LEYTE.
463	Apocynaceae	Hoya	paziae Kloppenb.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Quezon, MINDORO: Mindoro Oriental (Mt Halcon), PANAY: Antique (Mt Madya-as).
464	Apocynaceae	Kibatalia	merrilliana Woodson	\N	\N	Merrill pasnit	Angiosperm (Tree)	Vulnerable	Endemic	LEYTE, SAMAR. Forests at low elevation. 
465	Apocynaceae	Quisumbingia	merrillii (Schltr.) Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Mountain Province, Benguet.
466	Apocynaceae	Tabernaemontana	cordata Merr.	\N	\N	Sakang-manok/alibótbot	Angiosperm (Tree)	Vulnerable	Endemic	MINDANAO: Agusan, Surigao. Low elevation thickets, old clearings, etc.
467	Apocynaceae	Urceola	laevis (Elmer) Merr.	\N	\N	\N	Angiosperm	Vulnerable	Indigenous	PALAWAN (Mt Bloomfield, Mt Pulgar: Irawan River valley, Mt Victoria: Trident Mine).
468	Apocynaceae	Willughbeia	sarawacensis (Pierre) K.Schum.	\N	\N	tabo	Angiosperm	Vulnerable	Indigenous	PALAWAN.
469	Apocynaceae	Wrightia	palawanensis D.J.Middleton	\N	\N	Palawan lanéte	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Irawan Valley head on the lower slopes of Mt Beaufort.
470	Aquifoliaceae	Ilex	palawanica Loes. ex Elmer	\N	\N	Palawan kalásan	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN: Mt Pulgar.
471	Araceae	Alocasia	micholitziana Sander	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Apayao, Benguet. Thickets about limestone boulders, c. 1300m.
472	Araceae	Alocasia	zebrina Schott ex van Houtte	\N	\N	Badiang	Angiosperm	Vulnerable	Endemic	LUZON: Laguna, Quezon, Sorsogon. Primary forests at low and medium elevation. 
473	Araceae	Homalomena	palawanensis Engl.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
474	Araliaceae	Polyscias	pulgarense Elmer	\N	\N	Higin	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN (Mt Pulgar = Thumb Peak). Montane thickets, 1200m. 
475	Araliaceae	Schefflera	microphylla Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Abra, Ifugao, Mountain Province, Benguet.
476	Araucariaceae	Agathis	dammara (Lamb.) Rich. & A.Rich.	\N	\N	Bagtik	Gymnosperm (Tree)	Vulnerable	Indigenous	PALAWAN, SAMAR, possibly other parts of S Philippines.
477	Araucariaceae	Agathis	philippinensis Warb.	\N	\N	almaciga	Gymnosperm (Tree)	Vulnerable	Indigenous	BABUYAN ISLS, N LUZON to MINDANAO.
478	Arecaceae	Adonidia	merrillii (Becc.) Becc	\N	\N	búngang Jolo,\nManila palm	Angiosperm (Tree)	Vulnerable	Endemic	CORON, CALAMIANES, LANGEN, PALAWAN (Taytay Bay: APULIT; Brookes Point).
479	Arecaceae	Areca	hutchinsoniana Becc.	\N	\N	Pisa, sambulayan	Angiosperm (Tree)	Vulnerable	Endemic	SIASI, BASILAN (Maliqui; Mt Bulanting), MINDANAO: Zamboanga del Sur (Port Banga; Kabasalan, Dipala; Muralong Mt.; Malangas), Zamboanga del Norte (Malayal; Siocon, Laclacan); Lanao.
480	Arecaceae	Areca	ipot Becc.	\N	\N	Bungang-ipot	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Aurora, Laguna (Nagcarlan, Luisiana), Quezon (Lucban; Sampaloc), POLILLO: Burdeos.
481	Arecaceae	Areca	vidaliana Becc.	\N	\N	boga, pita	Angiosperm (Tree)	Vulnerable	Indigenous	BUSUANGA, PALAWAN (Puerto Princesa: St Paul’s Bay National Park, Mt Beaufort; Mt Binohan; Bagumbayan; Brookes Point, Aribungos).
482	Arecaceae	Calamus	curranii (Becc.) W.J.Baker	\N	\N	pit-pit, saranoi	Angiosperm	Vulnerable	Endemic	PALAWAN.
483	Arecaceae	Calamus	diepenhorstii Miq.	\N	var. exulans Becc.	abuan	Angiosperm	Vulnerable	Endemic	Palawan: Mt Victoria. LUZON: Quezon, POLILLO, PALAWAN.
484	Arecaceae	Calamus	ornatus Blume	\N	var. pulverulentus Fernando	\N	Angiosperm	Vulnerable	Endemic	Mindanao: Zamboanga del Norte prov., La Paz. PALAWAN (Puerto Princesa, Bagumbayan; Aborlan, Talakaigan River), MINDANAO: Zamboanga del Norte (Malayal; La Paz).
485	Arecaceae	Calamus	javensis Blume	\N	\N	arorog	Angiosperm	Vulnerable	Indigenous	DINAGAT, PALAWAN.
486	Arecaceae	Calamus	jenkinsianus Griff.	\N	\N	pin-pin	Angiosperm	Vulnerable	Indigenous	Palawan: Iwahig.
487	Arecaceae	Calamus	subinermis Wendl. ex Becc.	\N	\N	bugtong	Angiosperm	Vulnerable	Indigenous	PALAWAN, BASILAN.
488	Arecaceae	Korthalsia	merrillii Becc.	\N	\N	buragat	Angiosperm	Vulnerable	Endemic	Palawan: Malampaya Bay.
489	Arecaceae	Korthalsia	robusta Blume	\N	\N	kalalias	Angiosperm	Vulnerable	Indigenous	PALAWAN, BALABAC.
490	Arecaceae	Licuala	spinosa Wurmb.	\N	\N	balatbat	Angiosperm (Tree)	Vulnerable	Indigenous	BUSUANGA, CULION, PALAWAN, BALABAC, TAWITAWI.
491	Arecaceae	Oncosperma	tigillarium (Jack) Ridl.	\N	\N	anibong	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN.
492	Arecaceae	Orania	decipiens Becc.	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	Widespread, but absent from Palawan. LUZON: Cagayan, Isabela, Quezon, MINDORO, MINDANAO, SAMAR, BASILAN.
493	Arecaceae	Pinanga	curranii Becc.	\N	\N	Curran abíki	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN: (St Paul’s Bay, Kabayugan; Puerto Princesa; Bagumbayan; Iwahig River, Tagkauarim), DUMARAN, BUSUANGA.
494	Arecaceae	Saribus	merrillii (Becc.) Bacon &\nW.J.Baker	\N	\N	Merrillanaháu	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Aurora, Cagayan, Zambales, Quezon, Camarines, POLILLO.
495	Aspleniaceae	Asplenium	vittaeforme Cav.	\N	\N	dahu	Pteridophyte	Vulnerable	Indigenous	PALAWAN.
496	Begoniaceae	Begonia	chingipengii R.Rubite	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Luzon: Nueva Ecija, Gabaldon, Barangay Malinao, Maplud River
497	Begoniaceae	Begonia	cleopatrae C.Coyle	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: Cleopatra’s Needle
498	Begoniaceae	Begonia	coronensis Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	CORON, CULION. Lowland forests on limestone, on rocks and ledges along small streams.
499	Begoniaceae	Begonia	cumingiana (Klotzsch.) A.DC	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Albay, Cagayan, Sorsogon.
500	Begoniaceae	Begonia	georgei C.Coyle	\N	\N	\N	Angiosperm	Vulnerable	Endemic	No available information.
501	Begoniaceae	Begonia	gutierrezii C.Coyle	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
502	Begoniaceae	Begonia	oxysperma A DC	\N	\N	\N	Angiosperm	Vulnerable	Endemic	MINDORO. Primary forests, on trees or cliffs, 400-1900m. 
503	Begoniaceae	Begonia	suborbiculata Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: Malampaya Bay
504	Begoniaceae	Begonia	tandangii C.-I.Peng & R.Rubite	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Luzon: Aurora, Baler, Barangay Zabali
505	Begoniaceae	Begonia	wilkiei C.Coyle	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: Cleopatra's Needle
506	Begoniaceae	Begonia	woodii Merr	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: Malampaya Bay (Sound)
507	Berberidaceae	Berberis	barandana S.Vidal	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Mountain Province, Benguet, NEGROS.
508	Bignoniaceae	Radermachera	coriacea Merr.	\N	\N	labayanan	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Isabela (Divilacan; Palanan), Aurora (Baler). Ultramafic forests, usually near the coast. 
509	Blechnaceae	Blechnum	egregium Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	PALAWAN.
510	Blechnaceae	Blechnum	fraseri (A.Cunn.) Luerss.	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	LUZON, MINDORO.
511	Bryoxiphiaceae	Bryoxiphium	norvegicum (Brid.) Mitt.	\N	\N	\N	Bryophyte	Vulnerable	Indigenous	No available information.
512	Burseraceae	Protium	connarifolium (Perkins) Merr.	\N	\N	Marangub	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN. Forests along streams at low elevation.
513	Callophyllaceae	Calophyllum	pentapetalum (Blanco) Merr	\N	var. pentapetalum	pamitóyen	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Ilocos Norte, Ilocos Sur (Candon), La Union (San Fernando), Pangasinan, Benguet, Zambales (Sta Cruz: Barrio Binabag), PALAWAN (Km 112, Pinagbatuan).
514	Callophyllaceae	Calophyllum	pentapetalum (Blanco) Merr	\N	var. pulgarense (Elmer) P.F.Stevens	bintaúgan	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN: Thumb Peak; Mt Mantalingahan. Mossy summit scrub
515	Callophyllaceae	Calophyllum	laticostatum P.F.Stevens	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Quezon (Dolores, Mt Calvario; FB 30019, UC).
516	Casuarinaceae	Gymnostoma	nobile (Whitmore) L.A.S. Johnson	\N	\N	Palawan agoho	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN. Ultramafic sites, to 1000m.
517	Celastraceae	Glyptopetalum	palawanense Merr.	\N	\N	Palawan surag	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN, CUYO ISLAND GROUP (PAMALICAN). Low elevation primary forest and coastal thickets. 
518	Celastraceae	Salacia	cymosa Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
519	Celastraceae	Salacia	marginata Ding Hou	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN: Puerto Princesa and Mt Victoria.
520	Clethraceae	Clethra	pulgarensis Elmer	\N	\N	Tagobáhi	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN. Low woody vegetation on summit of Mt Pulgar
521	Clusiaceae	Garcinia	sulphurea Elmer	\N	\N	bunóg-diláu	Angiosperm (Tree)	Vulnerable	Endemic	BUSUANGA, PALAWAN.
522	Combretaceae	Terminalia	macrantha Merr. & Quisumb. ex Rojo	\N	\N	Bongoran	Angiosperm (Tree)	Vulnerable	Endemic	 SAMAR: Eastern Samar (Wright, Mt Calbiga). Summit of flat ridge, 300m. 
523	Combretaceae	Terminalia	surigaensis Merr.	\N	\N	Dalinsoi	Angiosperm (Tree)	Vulnerable	Endemic	MINDANAO: Surigao. Along streams at low elevation. 
524	Cyatheaceae	Cyathea	callosa Christ	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	CAMIGUIN, CATANDUANES, LUZON: Bataan, Benguet, Camarines Sur, Kalinga, Laguna, Quezon, PALAWAN.
525	Cyatheaceae	Cyathea	caudata (J Sm.) Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON, MINDANAO, MINDORO, NEGROS, PALAWAN.
526	Cyatheaceae	Cyathea	cinerea Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	MINDANAO: Agusan, Misamis Occidental.
527	Cyatheaceae	Cyathea	elmeri (Copel.) Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	BILIRAN, LEYTE, MINDANAO, NEGROS, PALAWAN.
528	Cyatheaceae	Cyathea	fenicis (C. Chr.) Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	LUZON.
529	Cyatheaceae	Cyathea	fuliginosa (Christ) Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	BILIRAN, LEYTE, LUZON, MINDANAO, NEGROS.
530	Cyatheaceae	Cyathea	halconensis Christ	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON: Benguet, Mountain Province, Nueva Vizcaya, MINDORO.
531	Cyatheaceae	Cyathea	heterochlamydea Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON, MINDANAO, NEGROS, PANAY.
532	Cyatheaceae	Cyathea	negrosiana Christ	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	BILIRAN, LEYTE, NEGROS. Conservation status: Vulnerable (DAO 2017-11).
533	Cyatheaceae	Cyathea	philippinensis Baker	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON: Mountain Province, Quirino (Mt Alzapan), Aurora (Mt Camatis), Quezon (Mt Banahaw), Camarines Sur (Mt Isarog, apparently common), Sorsogon (Mt Bulusan), MINDORO: Mindoro Oriental (Mt Halcon).
534	Cyatheaceae	Cyathea	robinsonii Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON: Aurora, Ilocos Norte, Isabela, Quezon, MINDANAO, TAWI-TAWI.
535	Cyatheaceae	Cyathea	setulosa Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON: Isabela, Kalinga, Quezon.
536	Cycadaceae	Cycas	edentata de Laub.	\N	\N	Pitogong-dagat	Gymnosperm	Vulnerable	Endemic	LUZON, MINDORO, CULION, PALAWAN, BANCALAN, PANAY, NEGROS, OLANGO, HAMORAON (part of Masbate prov.), BASILAN, MINDANAO.
537	Cycadaceae	Cycas	vespertilio KD. Hill & Lindstr.	\N	\N	\N	Gymnosperm (Tree)	Vulnerable	Endemic	LUZON: Camarines Sur (Panagan River), MINDORO: Mindoro Oriental (Mt Yagaw), MARINDUQUE (Torrijos, Bonliw, Talisay), PANAY: Iloilo (Barotac Viejo, Nagpana), NEGROS: Negros Oriental, CEBU, LEYTE: Leyte (Gigantangan), SAMAR.
538	Cycadaceae	Cycas	riuminiana Porte ex Regel	\N	\N	pitogo	Gymnosperm (Tree)	Vulnerable	Indigenous	BATAN, LUZON: Cagayan, Isabela (Mt Dipalayag), Pampanga (Mt Arayat), Bataan (Mt Mariveles, Lamao River), Cavite, Laguna, Batangas, MINDORO.
539	Cyrtopodaceae	Bescherellia	elegantissima Duby	\N	\N	\N	Bryophyte	Vulnerable	Endemic	No available information.
540	Cystopteridaceae	Gymnocarpium	oyamense (Baker) Ching	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	LUZON.
541	Dilleniaceae	Dillenia	cauliflora Merr	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	SAMAR, LEYTE, MINDANAO (NE coast).
542	Dilleniaceae	Dillenia	fischeri Merr.	\N	\N	Fischer katmon	Angiosperm (Tree)	Vulnerable	Endemic	MINDANAO: Agusan del Norte. Known only from two collections from the type locality. Semi-open forests, c. 20m
543	Dilleniaceae	Dillenia	luzoniensis (S.Vidal) Merr. PJS	\N	\N	Malakatmon	Angiosperm (Tree)	Vulnerable	Indigenous	Luzon: Bataan prov., Mt Mariveles, Lamao River. Endemic to the Philippines. LUZON: Ilocos Norte (Bangui), Cagayan (Claveria), Aurora (Baler, Cemento), Zambales, Bataan (Bagac), Rizal (Montalban, Mt Paningtingan; Balacbac), PALAWAN (St Paul’s Bay National Park; Mt Bloomfield; Sta. Cruz; Thumb Peak; Mt Beaufort; Irawan; Iwahig; Aborlan, Malasgao River; Victoria Mtns; Narra, Trident Mines; Rio Tuba, Balanjao Range), BALABAC (Cape Melville).
544	Dilleniaceae	Dillenia	monantha Merr	\N	\N	kátmon-bugtóng	Angiosperm (Tree)	Vulnerable	Endemic	BUSUANGA, CULION, DUMARAN, PALAWAN (Taytay; Lake Manguao; Binohan Mt near Puerto Princesa).
545	Dioscoreaceae	Dioscorea	palawana Prain & Burkill	\N	\N	Palawan ube	Angiosperm	Vulnerable	Endemic	Northern Palawan.
546	Dipterocarpaceae	Dipterocarpus	caudatus Foxw.	\N	\N	tailed-leaf panáu	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Camarines, Quezon, Albay, Sorsogon, SINUYAN, PALAWAN (St Paul Bay National Park), MINDANAO.
547	Dipterocarpaceae	Dipterocarpus	alatus Roxb. ex G.Don.	\N	\N	hairy-leaf apitong	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Abra, Nueva Vizcaya, Bataan.
548	Dipterocarpaceae	Dipterocarpus	gracilis Blume	\N	\N	Panau	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Zambales, Bataan (Mt Mariveles, Lamao River), Bulacan (Sibul Forest, Sitio Binalangoan), Rizal (Bosoboso; Antipolo), Quezon (Umiray), POLILLO, MINDORO, MARINDUQUE, PALAWAN (Pagdanan Range, Ibangley Brookside Hill; Quezon, Barangay Tuangan;), NEGROS: Negros Occidental, MINDANAO: Zamboanga del Norte (Duhinid), Cotabato, Davao, Surigao.
549	Dipterocarpaceae	Dipterocarpus	grandiflorus (Blanco) Blanco	\N	\N	Apitong	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON (widespread in most provinces), MINDORO, PALAWAN, SIBUYAN, BILIRAN, SAMAR, PANAY, NEGROS, MINDANAO: Misamis, Agusan.
550	Dipterocarpaceae	Dipterocarpus	hasseltii Blume	\N	\N	Hasselt's panau	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Isabela, Nueva Ecija, Laguna, PALAWAN, NEGROS, BILIRAN, LEYTE, MINDANAO: Zamboanga, BASILAN.
551	Dipterocarpaceae	Dipterocarpus	kunstleri King.	\N	\N	broad-leaf apitong	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Cagayan, Isabela, Quezon, Camarines, Albay, POLILLO, NEGROS, SAMAR, BASILAN.
552	Dipterocarpaceae	Hopea	plagata (Blanco) S.Vidal	\N	\N	yakal-saplungan	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Cagayan, Nueva Vizcaya, Nueva Ecija, Pangasinan, Bulacan, Bataan, Rizal, Laguna, Quezon, Camarines, Sorsogon, MINDORO, TABLAS, BOHOL, MINDANAO, BASILAN, TAWI-TAWI.
553	Dipterocarpaceae	Hopea	rudiformis P.S.Ashton	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN (Narra, Marihuera, Narra-Aboabo Road, Soejarto et al. 6587, A, F, PNH).
554	Dipterocarpaceae	Shorea	almon Foxw.	\N	\N	almon	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Bataan, Quezon, Camarines, Albay, Sorsogon, NEGROS, SAMAR, MINDANAO: Zamboanga, Misamis, Lanao, Agusan, Surigao, BASILAN.
585	Euphorbiaceae	Trigonostemon	merrillii Elmer	\N	\N	Merill katap	Angiosperm (Tree)	Vulnerable	Indigenous	Palawan: Puerto Princesa, Mt Pulgar.
555	Dipterocarpaceae	Shorea	contorta Vidal	\N	\N	White lauan	Angiosperm (Tree)	Vulnerable	Endemic	BABUYAN ISLS (CALAYAN), LUZON (in most provinces), POLILLO, MINDORO, SIBUYAN, MARINDUQUE, MASBATE, NEGROS, LEYTE, SAMAR, MINDANAO: Zamboanga, Lanao, Agusan, BASILAN. Common in primary lowland forests from semi-seasonal to everwet areas, in the former often semi-gregarious.
556	Dipterocarpaceae	Shorea	falciferoides Foxw.	\N	\N	yakál-yambán	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Pangasinan, Zambales, Bulacan, Quezon, Camarines, Albay, SAMAR, CEBU, SIBUYAN, LEYTE, MINDANAO: Zamboanga, Agusan, BASILAN.
557	Dipterocarpaceae	Shorea	negrosensis Foxw.	\N	\N	Red lauan	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Cagayan, Isabela, Aurora, Nueva Ecija, Laguna, Quezon, Camarines, Albay, Sorsogon, POLILLO, NEGROS, CEBU, LEYTE, BILIRAN, SAMAR, MINDANAO: Zamboanga, Lanao, Cotabato, Bukidnon, Davao, Surigao, Agusan, BASILAN. Primary evergreen and semi-evergreen lowland forests, common and often gregarious. 
558	Dipterocarpaceae	Shorea	polysperma (Blanco) Merr.	\N	\N	Tanguile	Angiosperm (Tree)	Vulnerable	Endemic	BABUYAN ISLS (CALAYAN), LUZON: Cagayan, Ilocos Norte, Pangasinan, Nueva Ecija, Bulacan, Zambales, Bataan, Laguna, Quezon, Camarines, Albay, Sorsogon, POLILLO, MINDORO, PANAY, NEGROS, CEBU, BILIRAN, LEYTE, SAMAR, MINDANAO: Zamboanga, Misamis, Lanao, Cotabato, Bukidnon, Davao, Agusan, Surigao, BASILAN. Often common in lowland and medium elevation primary forests, ascending to 1000m (exceptionally to 1200m).
559	Dipterocarpaceae	Shorea	seminis (Vriese) Slooten	\N	\N	malayakal	Angiosperm (Tree)	Vulnerable	Indigenous	MINDANAO: Zamboanga.
560	Dipterocarpaceae	Vatica	mangachapoi Blanco	ssp. Mangachapoi	\N	Narig	Angiosperm (Tree)	Vulnerable	Indigenous	CAMIGUIN DE BABUYANES, LUZON (widespread in most provinces), LEYTE, SAMAR, MINDANAO: Lanao, Davao.
561	Dipterocarpaceae	Vatica	umbonata (Hook.f.) Burck	ssp. Umbonata	\N	Blanco Narig	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN (Mt Pulgar), MINDANAO: Zamboanga, BASILAN.
562	Dryopteridaceae	Dryopteris	polita Rosenst.	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	No available information.
563	Ebenaceae	Diospyros	cauliflora Blume	\N	\N	aponan	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Cagayan, Isabela, Aurora, Laguna, MINDORO, PALAWAN, NEGROS, CEBU (Asturias), BASILAN, MINDANAO: Zamboanga, Agusan del Norte, Surigao.
564	Ebenaceae	Diospyros	discolor Willd.	\N	\N	kamagong	Angiosperm (Tree)	Vulnerable	Indigenous	BATAN, N LUZON to PALAWAN. In most or all islands and provinces.
565	Ebenaceae	Diospyros	ferrea (Willd.) Bakh.	\N	\N	bantulinau	Angiosperm (Tree)	Vulnerable	Indigenous	Throughout the Philippines in most islands and provinces.
566	Ebenaceae	Diospyros	philippinensis A.DC.	\N	\N	oi-oi	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Pangasinan, Zambales, Bataan, Rizal, Laguna, Camarines, MINDORO, MINDANAO.
567	Ebenaceae	Diospyros	pilosanthera Blanco	\N	\N	bolong-eta	Angiosperm (Tree)	Vulnerable	Indigenous	Luzon: Batangas prov., Punta Santiago, in dry forest
568	Ebenaceae	Diospyros	pyrrhocarpa Miq.	\N	\N	anang	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Isabela, Nueva Vizcaya, Aurora, Rizal, Laguna, Camarines, Sorsogon, MINDORO, NEGROS, BILIRAN, LEYTE, SAMAR, BASILAN, MINDANAO: Agusan.
569	Ericaceae	Rhododendron	edanoi Merr. & Quisumb	subsp. edanoi	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN: Cleopatra Needle; Thumb Peak; Mt Mantalingahan.
570	Ericaceae	Rhododendron	jasminiflorum Hook.	subsp.\ncopelandii (Merr.) Sleumer	\N	\N	Angiosperm	Vulnerable	Endemic	MINDANAO: Davao (Mt Apo).
571	Ericaceae	Rhododendron	kochii Stein	\N	\N	Koch's malagos	Angiosperm	Vulnerable	Endemic	Mindanao: Davao, Mt Apo, Todaya, Aug-1909. Endemic to the Philippines. LUZON: Mountain Province, Bataan (Mt Mariveles), Laguna (Mt San Cristobal; Mt Banahaw), MINDORO: Mindoro Oriental (Mt Halcon; Ilong Peak), NEGROS: Negros Occidental (Mt Kanlaon), MINDANAO: Davao (Mt Apo; Mt McKinley), Lanao del Sur (Camp Keithley along Lake Lanao), Misamis Occidental (Mt Malindang). Copeland also mentions BS 692 Foxworthy from PALAWAN (Mt Victoria) as possibly conspecific but because material is merely in fruit, cannot be positively identified. Nonetheless, this is the only Rhododendron seen by him from PALAWAN. On ridges on mossy forest, 1000-2300m. 
572	Ericaceae	Rhododendron	loboense H. F. Copel.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	 LUZON: Batangas (Lobo Mtns), MINDORO: Mindoro Oriental (Mt Halcon), NEGROS (photos), CAMIGUIN (Mt Hibok-hibok). 
573	Ericaceae	Rhododendron	subsessile Rendle	\N	\N	Ausip	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Abra (Mt Paraga), Mountain Province (Mt Data; Bauko; Mt Sisipitan), Ifugao (Mt Polis; Banaue), Benguet (Pauai; Halsema Road; Mt Malaya; Mt Pulag; Mt Baudan; Bucao; Baguio; Mt Sto Tomas). Rather common in the pine region and the pine-oak association below the mossy forest, rare in the mossy forest (Mt Pulag), again on exposed grass-covered slopes above the moss forest, often in clumps or masses, 1300-2400m.
574	Ericaceae	Rhododendron	vidalii Rolfe	subsp. vidalii	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Mountain Province (Bontoc; Bontoc-Banaue Road; Mt Caua; Mt Data; Bauko, Sabangan), Benguet (Loo; Bandschan; Tabbak), Abra, Cagayan (Mt Cagua), Isabela (Bayabat), Zambales (Mt Tapulao), Bataan (Mt Mariveles), Laguna (Mt Makiling), Quezon (Mt Banahaw de Lucban), Batangas. (Mt Malarayat).
575	Ericaceae	Rhododendron	wilkei Argent	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN: Thumb Peak.
576	Ericaceae	Vaccinium	brachytrichum Sleumer	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN: Mt Capoas
577	Ericaceae	Vaccinium	gitingense Elmer	\N	\N	Pagangpang	Angiosperm (Tree)	Vulnerable	Endemic	SIBUYAN, MINDANAO: Surigao del Norte (Tubungan-Dayan; Iron Deposit), DINAGAT.
578	Ericaceae	Vaccinium	palawanense Merr.	\N	var.\nfoxworthyi (H.F.Copel.) Sleum.	\N	Angiosperm	Vulnerable	Endemic	PALAWAN (Mt Victoria).
579	Ericaceae	Vaccinium	palawanense Merr.	\N	var.\npalawanense	Iualus	Angiosperm	Vulnerable	Endemic	MINDANAO: Davao (Mt Apo).
580	Erpodiaceae	Erpodium	luzonense (Bartr.) H.A. Crum	\N	\N	\N	Bryophyte	Vulnerable	Indigenous	No available information.
581	Erpodiaceae	Solmsiella	biseriata (Austin) Steere	\N	\N	\N	Bryophyte	Vulnerable	Indigenous	No available information.
582	Euphorbiaceae	Balakata	luzonica (S.Vidal) Esser	\N	\N	balakat-gubat	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Ilocos Sur, Bataan, Bulacan, Rizal, Laguna, MINDORO, PALAWAN, TICAO, MINDANAO, BUCAS GRANDE. Primary or secondary lowland semi-deciduous forests, also on limestone hills. May be locally very common and conspicuous on account of straight boles with scaly peeling bark. On clay, sand, or volcanic soils, 10-120m.
583	Euphorbiaceae	Euphorbia	trigona Mill.	\N	\N	súda-súda	Angiosperm	Vulnerable	Endemic	No available information.
584	Euphorbiaceae	Reutealis	trisperma (Blanco) Airy Shaw	\N	\N	Bagilumbáng	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: La Union, Rizal, Laguna, Quezon, Cavite, Batangas, Camarines, Pampanga, NEGROS, MINDANAO: Davao.
586	Fabaceae	Cynometra	inaequifolia A Gray	\N	\N	Dila-dila	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: La Union, Cagayan, Isabela, Zambales, Bataan, Rizal, Laguna, Quezon, Cavite, Batangas, PANAY, NEGROS.
587	Fabaceae	Intsia	bijuga (Colebr.) Kuntze	\N	\N	Ipil	Angiosperm (Tree)	Vulnerable	Indigenous	Throughout the Philippines from BABUYAN ISLS, N LUZON to PALAWAN and MINDANAO.
588	Fabaceae	Intsia	palembanica Miq.	\N	\N	Palawan Ipil	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Isabela (Palanan, ISU 147, L), PALAWAN: Taytay (Pagdanan Range, Ibangley; Lake Manguao), San Vicente (between Roxas & Port Barton).
589	Fabaceae	Kingiodendron	alternifolium (Elmer) Merr. & Rolfe	\N	\N	Batete	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Cagayan, Quezon (Guinayangan; Mulanaw; San Narciso), Camarines, Albay, MASBATE, TICAO, PANAY: Iloilo (Miag-ao), NEGROS, LEYTE, SAMAR, MINDANAO: Zamboanga del Sur (Port Banga).
590	Fabaceae	Kunstleria	forbesii Prain	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
591	Fabaceae	Pericopsis	mooniana Thwaites	\N	\N	makapilit	Angiosperm (Tree)	Vulnerable	Indigenous	MINDANAO: Zamboanga del Sur.
592	Fabaceae	Phanera	semibifida (Roxb.)	\N	var. perkinsiae\n(Merr.) Bandyop., P.P. Ghoshal & M.K. Pathak	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
593	Fabaceae	Phanera	aherniana (Perkins) de Wit	\N	var. subglabra (Merr.) Bandyop., Ghoshal & M.K.Pathak	\N	Angiosperm	Vulnerable	Indigenous	PALAWAN.
594	Fabaceae	Pterocarpus	indicus Willd.	forma indicus	\N	smooth narra	Angiosperm (Tree)	Vulnerable	Indigenous	Throughout the Philippines. Batanes.
595	Fabaceae	Pterocarpus	indicus Willd.	forma echinatus	\N	prickly narra	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON (Ilocos Norte, Ilocos Sur, Cagayan, Isabela, Bulacan, Laguna, Quezon, Camarines, Sorsogon), MINDORO.
596	Fabaceae	Sindora	inermis Merr.	\N	\N	Kayugalo	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Camarines, SIBUTU, JOLO, MINDANAO: Zamboanga, Saranggani, DINAGAT.
597	Fabaceae	Strongylodon	elmeri Merr.	\N	\N	Bindanugan	Angiosperm	Vulnerable	Endemic	Luzon: Benguet prov., Sablan. LUZON: Ilocos Norte (Burgos), Benguet (Baguio; Sablan), Cagayan (Peñablanca), Isabela (San Mariano; Mt Moises; Palanan), Rizal.
598	Fabaceae	Teyleria	tetragona (Merr.) J.A.Lackey & Maesen	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
599	Fabaceae	Wallaceodendron	celebicum Koord.	\N	\N	banuyo	Angiosperm (Tree)	Vulnerable	Indigenous	BABUYAN ISLS (CAMIGUIN), LUZON: Benguet (Baguio), Cagayan, Isabela, Aurora, Quezon, Camarines, BURIAS, MASBATE, NEGROS, CEBU, SAMAR.
600	Fagaceae	Lithocarpus	apoensis (Elmer) Rehd.	\N	\N	Apo oak	Angiosperm (Tree)	Vulnerable	Endemic	LUZON, CATANDUANES, PANAY, SAMAR, MINDANAO: Davao (Mt Apo). Forests, 1000-1700m.
601	Fagaceae	Lithocarpus	jordanae (Fern.-Villar) Rehd.	\N	\N	Katiluk	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Abra, Mountain Province (Mt Data), Benguet (Pauai; Mt Pulog; Mt Sto Tomas; Baguio), Nueva Vizcaya. Mossy forests on the higher mountains, 1200-2400m
602	Gesneriaceae	Aeschynanthus	cuernosensis Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	NEGROS: Negros Oriental (Cuernos Mtns). Ravines, c. 800m.
603	Gesneriaceae	Aeschynanthus	curvicalyx Mendum	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN: Cleopatra’s Needle.
604	Gesneriaceae	Aeschynanthus	elmeri Mendum	\N	\N	\N	Angiosperm	Vulnerable	Endemic	MINDANAO: Agusan del Norte (Mt Urdaneta). Exposed peaks, c. 1500m.
605	Gesneriaceae	Aeschynanthus	madulidii Mendum	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN: Puerto Princesa, Thumb Peak. 
606	Gesneriaceae	Aeschynanthus	miniaceus BL Burtt & PJB Woods	\N	\N	Pamingkauan	Angiosperm	Vulnerable	Endemic	MINDANAO: Agusan del Norte (Mt Hilong-hilong). Forested ridges, c. 900m
607	Gesneriaceae	Aeschynanthus	pergracilis Kraenzl.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	NEGROS: Negros Occidental (Kanlaon Volcano). Primary forests, c. 1200m. 
608	Gesneriaceae	Aeschynanthus	truncatus Schltr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	NEGROS: Negros Oriental prov. (Cuernos Mtns). Forested ravines, c. 800m.
609	Gesneriaceae	Agalmyla	biflora (Elmer) Hilliard & BL Burtt	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN (Mt Capoas; Tagimburg (possibly a misspelled locality); Thumb Peak; Mt Mantalingahan)
610	Gesneriaceae	Agalmyla	calelanensis (Elmer) Hilliard & BL Burtt	\N	\N	Tasik sa lomot	Angiosperm	Vulnerable	Endemic	MINDANAO: Davao (Mt Apo), N Cotabato (Kidapawan Mun., Ilomavis, Mt Apo above Marber Hot Springs). In mossy forest, 1800–2600m. 
611	Gesneriaceae	Agalmyla	glabra (Merr.) Hilliard & BL Burtt	\N	\N	\N	Angiosperm	Vulnerable	Endemic	MINDANAO: Bukidnon (Mt Kitanglad; Mt Candoon), Davao (Mt Apo; Mt McKinley), South Cotabato (Lake Parker). Montane forests, 1160-2000m.
612	Gesneriaceae	Agalmyla	parvilimba Hilliard & BL Burtt	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LEYTE: Mt Lobi, submontane forest, 800m.
613	Gesneriaceae	Agalmyla	persimilis Hilliard & BL Burtt	\N	\N	\N	Angiosperm	Vulnerable	Endemic	MINDANAO: Agusan del Norte (Mt Hilong-hilong; Mt Urdaneta), Diuata Mtns.
614	Gesneriaceae	Agalmyla	rotundiloba Hilliard & BL Burtt	\N	\N	\N	Angiosperm	Vulnerable	Endemic	MINDANAO: Davao Oriental (Mt Kampalili). Summit, 750m. 
615	Gesneriaceae	Agalmyla	samarica Hilliard & BL Burtt	\N	\N	\N	Angiosperm	Vulnerable	Endemic	SAMAR: Eastern Samar (Mt Apoy), Mt Calbiga. In forest, 180-300m.
616	Gesneriaceae	Agalmyla	sibuyanensis Hilliard & BL Burtt	\N	\N	\N	Angiosperm	Vulnerable	Endemic	SIBUYAN. Submontane forest, 1300m.
617	Gesneriaceae	Agalmyla	urdanetensis (Elmer) Hilliard & BL Burtt	\N	\N	Balibadon	Angiosperm	Vulnerable	Endemic	MINDANAO: Agusan del Norte (Mt Hilong-hilong), Surigao del Norte (Mt Kabatuan). In mossy forest, 700-1800m.
618	Gesneriaceae	Codonoboea	corrugata (Mendum)\nD.J.Middleton	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN: Cleopatra’s Needle.
619	Gesneriaceae	Codonoboea	woodii (Merr.) A.Weber	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: Malampaya Bay
620	Gesneriaceae	Cyrtandra	cleopatrae H.J.Atkins & Cronk	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: Cleopatra’s Needle
621	Gesneriaceae	Cyrtandra	elatostemmoides Elmer	\N	\N	\N	Angiosperm	Vulnerable	Indigenous	PALAWAN (Malampaya Bay; Mt Pulgar)
622	Gesneriaceae	Cyrtandra	hirtigera H.J.Atkins & Cronk	\N	var. chlorina H.J.Atkins & Cronk	\N	Angiosperm	Vulnerable	Endemic	Palawan: Thumb Peak. PALAWAN (Thumb Peak; Mt Mantalingahan; Pagdanan Range; San Vicente).
623	Gesneriaceae	Cyrtandra	hirtigera H.J.Atkins & Cronk	\N	var. hirtigera	\N	Angiosperm	Vulnerable	Endemic	PALAWAN: Cleopatra’s Needle; Malampaya Bay
624	Gesneriaceae	Cyrtandra	inaequifolia Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
625	Gesneriaceae	Cyrtandra	livida Kraenzl.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
759	Rubiaceae	Hedyotis	bambusetorum Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
626	Gesneriaceae	Cyrtandra	pulgarensis Elmer ex H.J.Atkins & Cronk	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: Mt Pulgar.
627	Gesneriaceae	Cyrtandra	rupicola Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan.
628	Hookeriaceae	Bryobrothera	crenulata (Broth. & Par.) Ther.	\N	\N	\N	Bryophyte	Vulnerable	Indigenous	No available information.
629	Hookeriaceae	Ephemeropsis	tjibodensis Goeb.	\N	\N	\N	Bryophyte	Vulnerable	Indigenous	No available information.
630	Lamiaceae	Clerodendrum	macrocalyx HJ Lam	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	MINDANAO: Lanao del Sur, Davao (Mt Apo), Surigao del Norte.
631	Lamiaceae	Clerodendrum	mindorense Merr.	\N	\N	Bagab	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Isabela (Palanan), Sorsogon, MINDORO, SEMIRARA, NEGROS, MINDANAO: Misamis.
632	Lamiaceae	Clerodendrum	quadriloculare (Blanco) Merr.	\N	\N	bagauak-morado	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Pangasinan, Benguet, Nueva Vizcaya, Zambales, Pampanga, Bataan, Rizal, Laguna, Batangas, MINDORO, TICAO, PANAY, NEGROS, SIARGAO, BUCAS GRANDE.
633	Lamiaceae	Gmelina	philippensis Cham.	\N	\N	Alipúng	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Pangasinan, Benguet, Cagayan, Zambales, Bataan, Pampanga, Bulacan, Rizal, Laguna, PANAY.
634	Lauraceae	Cinnamomum	rupestre Kosterm.	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN: Mt Beaufort, Malasgao, Victoria Peaks
635	Lauraceae	Cryptocarya	ampla Merr.	\N	\N	Bagarilau	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Ilocos Sur, Cagayan, Nueva Ecija, Pampanga (Mt Arayat), Rizal (Antipolo), Laguna (Mt Makiling), Camarines Norte (Paracale), Camarines Sur (Pasacao), Sorsogon, CATANDUANES, PANAY: Aklan (Libacao), MINDANAO: Davao: Mt Apo, Davao del Sur (Sta Cruz). Primary forests at low and medium elevation, ascending to 1000m.
636	Lecythidaceae	Barringtonia	palawanensis Chantar.	\N	\N	Palawan pútat	Angiosperm (Tree)	Vulnerable	Endemic	Palawan, Puerto Princesa, c. 37km N of the city, near Sta Cruz Resthouse
637	Lecythidaceae	Barringtonia	ridsdalei Chantar.	\N	\N	Ridsdale pútat	Angiosperm (Tree)	Vulnerable	Endemic	Palawan, Pulot, Massin River, 12km N of Brook's Point.
638	Liliaceae	Lilium	longiflorum Thunb.	\N	\N	Vonitan	Angiosperm	Vulnerable	Indigenous	N Philippines.
639	Liliaceae	Lilium	philippinense Baker	\N	\N	Luplupak	Angiosperm	Vulnerable	Indigenous	LUZON: Ilocos Norte (photos) Mountain Province, Benguet, Pangasinan.
640	Linaceae	Philbornea	magnifolia (Stapf) Hallier f.	\N	\N	\N	Angiosperm	Vulnerable	Indigenous	No available information.
641	Lindsaeaceae	Lindsaea	hamiguitanensis Karger &\nV.B.Amoroso	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	MINDANAO: Mt. Hamiguitan.
642	Loganiaceae	Strychnos	oleifolia A.W.Hill	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
643	Malvaceae	Durio	macrophyllus (King) Ridl.	\N	\N	Panugianon	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN.
644	Malvaceae	Grewia	palawanensis Merr.	\N	\N	Bagún	Angiosperm (Tree)	Vulnerable	Endemic	No available information.
645	Maranthaceae	Phrynium	minutiflorum Suksathan &\nBorchs.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	CATANDUANES, PANAY.
646	Marsileaceae	Marsilea	minuta L.	\N	\N	clover fern	Pteridophyte	Vulnerable	Indigenous	No available information.
647	Melastomataceae	Beccarianthus	ickisii Merr.	\N	\N	Ickis tungau	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Sorsogon, CATANDUANES, PANAY, NEGROS: Negros Oriental (Cuernos Mtns), LEYTE (Buenavista near Jaro), SAMAR, SIARGAO, MINDANAO: Agusan del Norte (Umuwayan River near Waloe). Moist primary forests, 50-500m.
648	Melastomataceae	Beccarianthus	pulcherrimus (Merr.) Maxw.	\N	\N	Malintungau	Angiosperm (Tree)	Vulnerable	Endemic	Mindanao: Misamis Occidental prov., Mt Malindang, 1400m, May-1906. Endemic to the Philippines. CATANDUANES, SAMAR, LEYTE (Dagami), NEGROS: Negros Occidental (Mt Silay; Kanlaon Volcano), Negros Oriental (Cuernos Mtns), MINDANAO: Misamis Occidental (Mt Malindang), Davao (Mt Apo). Primary forests, 300-1400m.
649	Melastomataceae	Medinilla	cumingii Naudin	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Cordillera Highlands, Nueva Ecija, Quezon (Mt Banahaw), Albay, Sorsogon.
650	Melastomataceae	Medinilla	dolichophylla Merr.	\N	\N	Gunang	Angiosperm	Vulnerable	Endemic	LUZON: Cordillera and Sierra Madre Mtn Ranges, Kalinga, Ifugao, Mountain Province, Benguet (Baguio), Isabela. Over limestone outcrops in pine forests or in mossy forests between 1000-1800m.
651	Melastomataceae	Memecylon	odoratum Elmer	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Puerto Princesa, between forks of Iwahig River, along a woodland stream
652	Meliaceae	Aglaia	angustifolia Miq.	\N	\N	kaniuing-kitid	Angiosperm (Tree)	Vulnerable	Indigenous	SAMAR (Catubig River), MINDANAO: Agusan.
653	Meliaceae	Aglaia	tenuicaulis Hiern	\N	\N	oksa	Angiosperm (Tree)	Vulnerable	Indigenous	SAMAR.
654	Meliaceae	Azadirachta	excelsa (Jack) Jacobs	\N	\N	maranggo	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN, MASBATE, BASILAN.
655	Meliaceae	Dysoxylum	cauliflorum Hiern	\N	\N	tarublang	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN: Mt Beaufort, Pulgar, Irawan River Valley, Victoria Mtns (Trident Mines area).
656	Meliaceae	Toona	calantas Merr. & Rolfe	\N	\N	Kalantas	Angiosperm (Tree)	Vulnerable	Indigenous	BATANES, LUZON: Cagayan to Sorsogon, MINDORO, NEGROS, CEBU, LEYTE, SAMAR, MINDANAO.
657	Myristicaceae	Horsfieldia	samarensis de Wilde	\N	\N	Samar yabnob	Angiosperm (Tree)	Vulnerable	Endemic	 SAMAR: Eastern Samar (Mt Apoy). 
658	Myristicaceae	Knema	latericia Elmer	\N	v. latericia	duhao	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN.
659	Myristicaceae	Knema	latericia Elmer	\N	var. subtilis W.J.de Wilde	\N	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN.
660	Myrtaceae	Syzygium	borneense (Miq.) Miq.	\N	\N	Kalaum	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN.
661	Myrtaceae	Syzygium	ecostulatum (Elmer) Merr.	\N	\N	lamútong-linís	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN.
662	Myrtaceae	Syzygium	iwahigense (Elmer) Merr.	\N	\N	Iwahig malarúhat	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN.
663	Myrtaceae	Syzygium	nitidum Benth.	\N	\N	Makaasim	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: La Union, Isabela, Bataan, Nueva Ecija, Bulacan, Rizal, Laguna, Quezon, Camarines, MINDORO, MANGSI.
664	Myrtaceae	Tristaniopsis	decorticata (Merr.) Peter G Wilson & Waterhouse	\N	\N	Malabayabas	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Cagayan, Ilocos Norte (Mt Palimlim), Bataan, Aurora, Quezon (Infanta), Rizal, Camarines, POLILLO, MINDANAO: Davao. Primary forests, chiefly at low and medium elevation
665	Myrtaceae	Tristaniopsis	littoralis (Merr.) Peter G Wilson & Waterhouse	\N	\N	Taba	Angiosperm (Tree)	Vulnerable	Endemic	SAMAR, MINDANAO: Zamboanga, BASILAN (Maluso: Abong-abong). Forests behind mangroves, but also ascending to 500m.
666	Myrtaceae	Xanthostemon	speciosus Merr.	\N	\N	Malapiga	Angiosperm (Tree)	Vulnerable	Endemic	BUSUANGA, CULION, MANAMOC, PALAWAN. Lowland thickets and scrub, also open pyrogenic grasslands with scattered trees. On Palawan commonly seen on ultramafics, on Busuanga and Manamoc on chert. 
667	Nepenthaceae	Nepenthes	cornuta Marwinski et al.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Mindanao: Bukidnon, Pantaron mountain range, Malaybalay City, Brgy. St. Peter
668	Nepenthaceae	Nepenthes	hamiguitanensis Gronem. et al	\N	\N	\N	Angiosperm	Vulnerable	Endemic	MINDANAO (Mt. Hamiguitan, Davao Oriental).
669	Nepenthaceae	Nepenthes	mindanaoensis Sh.Kurata	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Mindanao: Surigao del Sur prov., Mt Carrascal
670	Nepenthaceae	Nepenthes	pantaronensis Gieray et al.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Mindanao: Bukidnon, Pantaron mountain range, Malaybalay City, Brgy. St. Peter
671	Nepenthaceae	Nepenthes	talaandig Gronem. et al.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Mindanao: Bukidnon, Pantaron mountain range, Malaybalay City, Brgy. St. Peter
672	Ochnaceae	Brackenridgea	palustris Bartell.	\N	var foxworthyi	bansilai	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN.
673	Ophioglossaceae	Botrychium	daucifolium Wall. ex Hook. & Grev.	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	No available information.
674	Orchidaceae	Aerides	leeana Reichb.f.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Bataan, Rizal, Quezon, Cavite, Camarines Norte, Camarines Sur, SAMAR. Epiphytic at c. 800m.
675	Orchidaceae	Aerides	quinquevulnera Lindl.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	BABUYAN, CALAYAN, LUZON: Bataan, Benguet, Bulacan, Rizal, Cavite, Laguna, Mountain Province, Quezon, Zambales, MINDORO, NEGROS.
676	Orchidaceae	Ascidieria	palawanensis (Ames) W.Suarez & Cootes	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN: Thumb Peak (Mt Pulgar).
677	Orchidaceae	Bulbophyllum	curranii Ames	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Benguet, Rizal, MINDORO.
678	Orchidaceae	Bulbophyllum	papulosum Garay	\N	\N	\N	Angiosperm	Vulnerable	Endemic	NEGROS.
679	Orchidaceae	Dendrobium	nemorale L.O.Williams	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Aurora, Quezon, Rizal, MINDORO.
680	Orchidaceae	Dendrobium	sanderae Rolfe	\N	\N	\N	Angiosperm	Vulnerable	Endemic	BABUYAN ISLS (CALAYAN), LUZON: Mountain Province, Ifugao, Benguet, Cagayan, Nueva Vizcaya, Rizal, PALAWAN, MINDANAO: Surigao del Norte, Surigao del Sur. Epiphytic, up to 1700m. 
681	Orchidaceae	Dendrobium	usterioides Ames	\N	\N	\N	Angiosperm	Vulnerable	Endemic	MINDORO.
682	Orchidaceae	Dendrobium	victoria-reginae Loher	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Mountain Province, Ifugao, Nueva Vizcaya, Pampanga, Quezon, MINDORO: Mindoro Oriental, NEGROS, CAMIGUIN, MINDANAO: Davao del Sur.
683	Orchidaceae	Dendrobium	secundum (Blume) Lindl. in Wall.	\N	\N	\N	Angiosperm	Vulnerable	Indigenous	LUZON: Bataan, Camarines, Rizal, LEYTE, NEGROS, MINDANAO: Agusan, Davao, Lanao, Surigao.
684	Orchidaceae	Dendrochilum	kingii (Hook.f.) J.J.Sm.	\N	\N	\N	Angiosperm	Vulnerable	Indigenous	PALAWAN: Mt Pulgar (Thumb Peak), Mt Mantalingahan.
685	Orchidaceae	Epigeneium	treacherianum (Rchb.f ex Hook.f.) Summerh.	\N	\N	\N	Angiosperm	Vulnerable	Indigenous	LUZON: Apayao, Kalinga, Nueva Vizcaya, Nueva Ecija, Bataan, Quezon, Rizal, Laguna, MINDORO: Mindoro Oriental, NEGROS, SAMAR.
686	Orchidaceae	Grammatophyllum	multiflorum Lindl.	\N	\N	rosa mia	Angiosperm	Vulnerable	Endemic	LUZON: Albay, Camarines, Cavite, Laguna, Quezon, Sorsogon, CATANDUANES, MINDORO, PALAWAN, LEYTE, SAMAR.
687	Orchidaceae	Grammatophyllum	scriptum (L.) Blume	\N	\N	\N	Angiosperm	Vulnerable	Indigenous	MINDANAO: Zamboanga, SARANGGANI.
688	Orchidaceae	Liparis	palawanensis Ames	\N	\N	\N	Angiosperm	Vulnerable	Endemic	No available information.
689	Orchidaceae	Phalaenopsis	aphrodite Rchb.f	\N	\N	\N	Angiosperm	Vulnerable	Endemic	No available information.
690	Orchidaceae	Phalaenopsis	bastianii O.Gruss & Roellke	\N	\N	\N	Angiosperm	Vulnerable	Endemic	No available information.
691	Orchidaceae	Phalaenopsis	equestris (Schauer) Rchb.f	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Luzon: Manila.
692	Orchidaceae	Phalaenopsis	fasciata Reichb.f.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Bataan, Albay, Sorsogon, BOHOL, MINDANAO: Davao del Sur. Epiphyte, to 300m. 
693	Orchidaceae	Phalaenopsis	x intermedia	\N	\N	\N	Angiosperm	Vulnerable	Endemic	No available information.
694	Orchidaceae	Phalaenopsis	x leucorrhoda	\N	\N	\N	Angiosperm	Vulnerable	Endemic	No available information.
695	Orchidaceae	Phalaenopsis	cornu-cervi (Breda) Blume & Rchb.f.	\N	\N	\N	Angiosperm	Vulnerable	Indigenous	No available information.
696	Orchidaceae	Phalaenopsis	mariae Burb. ex R.Warner & H.Williams	\N	\N	\N	Angiosperm	Vulnerable	Indigenous	LUZON: Nueva Vizcaya, MINDANAO: Lanao, Bukidnon, Cotabato, Davao, JOLO.
697	Orchidaceae	Pinalia	curranii (Leav.) W.Suarez & Cootes	\N	\N	\N	Angiosperm	Vulnerable	Endemic	No available information.
698	Orchidaceae	Vandopsis	lissochiloides (Gaudich.) Pfitzer in Engl. & Prantl	\N	\N	\N	Angiosperm	Vulnerable	Indigenous	No available information.
699	Pandanaceae	Sararanga	philippinensis Merr.	\N	\N	Bagaas, abasanay/Malapandan	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Quezon, Camarines Norte, Albay, Sorsogon, SIBUYAN, SAMAR, DINAGAT, MINDANAO: Bukidnon, Surigao del Sur. Chiefly in secondary forests, 0-750m. 
700	Pentaphragmataceae	Pentaphragma	platyphyllum Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	DINAGAT.
701	Phyllanthaceae	Baccaurea	lanceolata (Miq.) Müll.Arg. in DC.	\N	\N	limpahung	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN, JOLO
702	Phyllanthaceae	Glochidion	cenabrei Merr.	\N	\N	Cenabre bágna	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Palawan prov., Puerto Princesa
703	Phyllanthaceae	Glochidion	dolichostylum Merr	\N	\N	Tabángo	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN.
704	Phyllanthaceae	Glochidion	palawanense Elmer	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN.
705	Phyllanthaceae	Glochidion	pulgarense Elmer	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN: Mt Pulgar (Thumb Peak).
706	Phyllanthaceae	Phyllanthus	balgooyi Petra Hoffm. & A.J.M.Baker	\N	\N	Manglas	Angiosperm (Tree)	Vulnerable	Indigenous	Palawan: Puerto Princesa, Bacungan.
707	Phyllanthaceae	Phyllanthus	glochidioides Elmer	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Puerto Princesa (Mt. Pulgar)
708	Pinaceae	Pinus	merkusii Jungh. & Vriese	\N	\N	Mindoro pine	Gymnosperm (Tree)	Vulnerable	Indigenous	LUZON: Zambales, MINDORO: Mindoro Occidental.
709	Poaceae	Cyrtochloa	puser (Gamble) S.Dransf	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Abra (Bangued).
760	Rubiaceae	Hedyotis	capitellata Wall. ex G.Don	\N	\N	\N	Angiosperm	Vulnerable	Indigenous	PALAWAN.
710	Poaceae	Dimeria	chloridiformis (Gaudich)\nK.Schum. & Lauterb.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
711	Poaceae	Dinochloa	palawanensis S.Dransf	\N	\N	Palawan bíkal	Angiosperm	Vulnerable	Endemic	PALAWAN.
712	Poaceae	Ischaemum	glaucescens Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
713	Podocarpaceae	Podocarpus	lophatus de Laub.	\N	\N	Igem-pugot	Gymnosperm (Tree)	Vulnerable	Endemic	LUZON: Zambales (Mt Tapulao).
714	Podocarpaceae	Podocarpus	polystachyus R.Br. ex Endl.	\N	\N	dilang-butiki	Gymnosperm (Tree)	Vulnerable	Indigenous	BATANES, BUCAS GRANDE, LUZON: Benguet, Ilocos Norte, Quezon, Tayabas, MINDORO, PALAWAN, SIARGAO.
715	Podocarpaceae	Podocarpus	rumphii Blume	\N	\N	Malakauayan	Gymnosperm (Tree)	Vulnerable	Indigenous	LUZON: Bataan, Bulacan, Laguna, Pampanga, Quezon, MINDANAO: Agusan del Norte, North Cotabato (Mt Apo), MINDORO (Mt Halcon), PALAWAN.
716	Polygalaceae	Securidaca	atroviolacea Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN.
717	Polypodiaceae	Aglaomorpha	acuminata (Willd.) Hovenkamp	\N	\N	libagod	Pteridophyte	Vulnerable	Indigenous	Palawan.
718	Polypodiaceae	Aglaomorpha	cornucopia (Copel.) Roos	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON: Abra, Benguet, Kalinga, Mountain Province, MINDANAO: Bukidnon, Cotabato, Davao, Misamis Occidental, Zamboanga.
719	Polypodiaceae	Aglaomorpha	meyeniana Schott	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	CATANDUANES, CEBU, LUZON, MINDORO.
720	Polypodiaceae	Aglaomorpha	splendens (Hook. & Bauer) Copel	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON, MINDANAO, NEGROS.
721	Polypodiaceae	Aglaomorpha	heraclea (Kunze) Copel.	\N	\N	saraukong	Pteridophyte	Vulnerable	Indigenous	No available information.
722	Polypodiaceae	Aglaomorpha	pilosa (J.Sm. ex Kunze) Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	LUZON, MINDANAO, NEGROS.
723	Polypodiaceae	Microsorum	sarawakense (Baker) Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	No available information.
724	Polypodiaceae	Pyrrosia	splendens (Presl) Ching	\N	\N	Turko	Pteridophyte	Vulnerable	Endemic	BOHOL, LEYTE, LUZON, MINDANAO, SAMAR.
725	Polypodiaceae	Selliguea	sagitta (Christ) Fraser-Jenk.	\N	\N	Cacam-cam	Pteridophyte	Vulnerable	Endemic	Luzon: La Trinidad. Mindanao
726	Polypodiaceae	Xiphopterella	nudicarpa (P.M.Zamora & Co) Parris	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	PALAWAN.
727	Primulaceae	Ardisia	iwahigensis Elmer	\N	\N	samadódai	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN: Puerto Princesa (Mt Pulgar = Thumb Peak).
728	Primulaceae	Ardisia	romanii Elmer	\N	\N	Roman tagpo	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN
729	Primulaceae	Ardisia	squamulosa C Presl	\N	\N	tagpo	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Ilocos Norte, Cagayan, Isabela, Pangasinan, Tayabas, Cavite, Batangas, MINDORO, PALAWAN, PANAY, MINDANAO: Davao.
730	Primulaceae	Ardisia	taytayensis Merr.	\N	\N	tágpong-kapalan	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN, BALABAC.
731	Psilotaceae	Psilotum	nudum (L.) Griseb.	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	No available information.
732	Pteridaceae	Adiantum	cupreum Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	SIBUYAN.
733	Pteridaceae	Adiantum	monosorum Baker	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	MINDANAO.
734	Pteridaceae	Adiantum	stenochlamys Baker	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	PALAWAN.
735	Pteridaceae	Pteris	brevis Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	BASILAN.
736	Pteridaceae	Pteris	dataensis Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON.
737	Pteridaceae	Pteris	macgregorii Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON.
738	Pteridaceae	Pteris	micracantha Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON.
739	Pteridaceae	Pteris	mucronulata Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	PALAWAN.
740	Pteridaceae	Pteris	ramosii Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON.
741	Pteridaceae	Pteris	squamipes Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	MINDANAO.
742	Pteridaceae	Pteris	taenitis Copel.	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	BOHOL, LUZON: Tayabas, MINDANAO, PALAWAN, SAMAR.
743	Pteridaceae	Taenitis	cordata (Gaudich.) Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	No available information.
744	Rafflesiaceae	Rafflesia	lagascae Blanco	\N	\N	Malabóo	Angiosperm	Vulnerable	Endemic	LUZON: Albay (Mt Masaraga), Cagayan (Bolos Point), Bataan (Mt Natib), Laguna (Mt Makiling; Majayjay), Quezon (General Nakar, Mt Kayapo; Mt Banahaw), Camarines Norte (Mt Labo).
745	Rafflesiaceae	Rafflesia	leonardi Barcelona & Pelser	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Kalinga-Apayao (Balbalasang National Park), Cagayan (Baggao, Bolos Point).
746	Rafflesiaceae	Rafflesia	lobata Galang & Madulid	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PANAY: Antique (Pandan, Mt Igtuog; Sebaste, Mt Sakpaw; San Remigio), Iloilo (Leon, Mt Agua Coloña). Intact to severely degraded rainforest, 400-800m, mostly in gullies, on roots and climbing shoots of its host. 
747	Rhachidosoraceae	Rhachidosorus	stramineus (Copel.) Ching	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	No available information.
748	Rhamnaceae	Ventilago	palawanensis Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Mt Bloomfield; Mt Pulgar; Irawan River Valley.
749	Rhamnaceae	Ziziphus	palawanensis Elmer	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Mt Pulgar
750	Rosaceae	Prunus	pulgarensis (Elmer) Kalkm.	\N	\N	Gúpit	Angiosperm (Tree)	Vulnerable	Endemic	LUZON, PALAWAN. Montane forests, c. 1000-1200m.
751	Rosaceae	Prunus	rubiginosa (Elmer) Kalkm.	\N	\N	Bakad pula	Angiosperm (Tree)	Vulnerable	Endemic	LUZON, MINDORO, SIBUYAN, MINDANAO. Forests, 250-1200m.
752	Rosaceae	Prunus	subglabra (Merr.) Kalkm.	\N	\N	Kanumog	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Benguet (Mt Pulag; Mt Tabayoc). Mossy forests, 2400-2700m
753	Rosaceae	Prunus	grisea (Blume) Kalkm.	\N	var. tomentosa (Koord. & Valenton) Kalkm.	lagong-liitan	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN.
754	Rubiaceae	Antirhea	livida Elmer	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Palawan prov., Puerto Princesa, Mt Pulgar (Thumb Peak)
755	Rubiaceae	Antirhea	ternata Chaw	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	SIARGAO.
756	Rubiaceae	Exallage	perhispida (Elmer) Bremek.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN (Iwahig River; Thumb Peak).
757	Rubiaceae	Gardenia	ornata K.M.Wong	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	Samar: Central Samar, Paranas, Campo Uno, rolling mountain/limestone, primary forest
758	Rubiaceae	Gardenia	vulcanica K.M.Wong	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Sorsogon (Mt. Bulusan).
761	Rubiaceae	Hydnophytum	angustifolium Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	MINDANAO: Zamboanga, Lanao del Sur, PANAY
762	Rubiaceae	Hydnophytum	brachycladum Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Camarines, MINDANAO: Agusan del Norte, Davao, Cotabato, Surigao del Norte, Zamboanga, MINDORO.
763	Rubiaceae	Hydnophytum	intermedium Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	DINAGAT, LEYTE, LUZON: Bataan, Laguna, Quezon, Sorsogon, POLILLO, MINDANAO: Agusan del Norte, Davao del Sur (Mt Apo), MINDORO.
764	Rubiaceae	Hydnophytum	membranaceum Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	DINAGAT, LEYTE, LUZON: Bataan, Laguna, Quezon, Sorsogon, POLILLO, MINDANAO: Agusan del Norte, Davao del Sur (Mt Apo), MINDORO.
765	Rubiaceae	Hydnophytum	mindanaense Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Camarines, MINDANAO: Agusan del Norte, Davao, Cotabato, Surigao del Norte, Zamboanga, MINDORO.
766	Rubiaceae	Hydnophytum	mindorense Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	DINAGAT, LEYTE, LUZON: Bataan, Laguna, Quezon, Sorsogon, POLILLO, MINDANAO: Agusan del Norte, Davao del Sur (Mt Apo), MINDORO.
767	Rubiaceae	Hydnophytum	nitidum Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	DINAGAT, LEYTE, LUZON: Bataan, Laguna, Quezon, Sorsogon, POLILLO, MINDANAO: Agusan del Norte, Davao del Sur (Mt Apo), MINDORO.
768	Rubiaceae	Mussaenda	acuminatissima Merr.	\N	\N	Katudai	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Batangas, Ilocos Norte (Mt Nangapatan).
769	Rubiaceae	Mussaenda	attenuifolia Elmer	\N	\N	Bungag	Angiosperm (Tree)	Vulnerable	Endemic	MINDANAO: Agusan del Norte (Mt Urdaneta). Along wooded stream embankments, 150-450m.
770	Rubiaceae	Mussaenda	chlorantha Merr.	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Benguet (Mt Sto Tomas; Twin Peaks), Ifugao, Mountain Province, Pampanga (Mt Pinatubo, Camp Stotsenburg), Rizal, NEGROS: Negros Oriental.
771	Rubiaceae	Mussaenda	setosa Merr.	\N	\N	Sigidago	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN: Mt Capoas. Forested ridge, c. 700m.
772	Rubiaceae	Mussaenda	grandifolia Elmer	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Paragua prov., Point Separation
773	Rubiaceae	Mussaenda	lanata C.B.Rob	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Abra, Apayao, Benguet (Sabangan; Sablan; Baguio; Itogon; Antamok), Ilocos Sur (Concepcion, Mt Tirad; Cervantes Trail), Mountain Province, Zambales.
774	Rubiaceae	Mussaenda	magallanensis Elmer	\N	\N	Agboi	Angiosperm (Tree)	Vulnerable	Endemic	BASILAN, LUZON: Isabela (San Mariano; Palanan), Laguna (Mt Banahaw), Pampanga, MINDORO: Mindoro Occidental (Sablayan, Ligaya), Mindoro Oriental (Puerto Galera; Calapan; Baco River; Bongabon and Pinamalayan; SIBUYAN (foothills of Mt Giting-giting), PANAY: Capiz, LEYTE: Leyte (Dagami).
775	Rubiaceae	Mussaenda	milleri Elmer	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Nueva Ecija (Mingan Mtns).
776	Rubiaceae	Mussaenda	nervosa Elmer	\N	\N	Buyan	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Nueva Ecija, MINDANAO: Bukidnon, Davao del Sur (Mt Apo), Misamis Occidental, North Cotabato.
777	Rubiaceae	Mussaenda	scandens Elmer	\N	\N	Buai	Angiosperm	Vulnerable	Endemic	BASILAN, MINDANAO: Agusan del Norte, Bukidnon, Zamboanga del Sur (Malangas), Davao del Sur (Mt Apo), Surigao del Norte, Surigao del Sur.
778	Rubiaceae	Mussaenda	vidalii Elmer	\N	\N	Ananayop	Angiosperm (Tree)	Vulnerable	Endemic	BILIRAN, LEYTE: Leyte (Ormoc, Antilao River; Lake Danao), LUZON: Ifugao, SAMAR: Catubig River; Mt Cansayao; Western Samar (Loquilocon; Bagacay), MINDANAO: Agusan del Norte, Bukidnon (Pigtaoranan; Tangculan & vicinity, Davao del Sur (Mt Apo), Lanao del Sur.
779	Rubiaceae	Myrmephytum	beccarii Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	SIBUYAN, BILIRAN. In thickets, 225 m.
780	Rubiaceae	Pavetta	phanerophlebia Merr	\N	\N	Malagusókan	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN.
781	Rubiaceae	Pavetta	subferruginea Merr	\N	\N	gusókan-kaláuang	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN.
782	Rubiaceae	Psychotria	balabacensis Merr.	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	CAMIGUIN DE BABUYANES (Balatubat), MINDORO: Mindoro Oriental (Pinamalayan), PALAWAN (Bonabona), URSULA, BALABAC (Mt Caunayan), LUMBUCAN.
783	Rubiaceae	Psychotria	iwahigensis Elmer	\N	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN (Cleopatra Ranges; Mt Pulgar; Rizal).
784	Rubiaceae	Psychotria	pyramidata Elmer	\N	\N	gumugmug	Angiosperm (Tree)	Vulnerable	Endemic	BUSUANGA, PALAWAN (Mt Capoas; Mt Pulgar; Irawan River Valley; Quezon, Bundog, Sumindap River; Ransang, Aga; Mt Mantalingahan).
785	Rubiaceae	Timonius	ferrugineus Merr	\N	\N	bunkól-kaláuang	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Palawan prov., Taytay
786	Rubiaceae	Timonius	palawanensis Elmer	\N	\N	Bunkól	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Palawan prov., Brookes Point
787	Rubiaceae	Urophyllum	elliptifolium Merr.	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN: Mt Pulgar.
788	Rutaceae	Melicope	lunu-ankenda (Gaertn.) T.G.Hartley	\N	\N	tarungatau	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN.
789	Rutaceae	Melicope	pulgarensis (Elmer) T.G.Hartley	\N	\N	Pulgar kámal	Angiosperm (Tree)	Vulnerable	Endemic	Palawan: Palawan prov., Puerto Princesa, Mt Pulgar (Thumb Peak)
790	Santalaceae	Exocarpos	longifolius (L.) Endl.	\N	\N	Agsum	Angiosperm	Vulnerable	Indigenous	PALAWAN.
791	Sapindaceae	Glenniea	philippinensis (Radlk.) Leenh.	\N	\N	Mamoko	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Laguna (Mt Makiling), PANAY, DINAGAT.
792	Sapindaceae	Glenniea	thorelii (Pierre) Leenh.	\N	\N	Palawan sarakag	Angiosperm (Tree)	Vulnerable	Indigenous	No available information.
793	Sapindaceae	Guioa	discolor Radlk.	\N	\N	Alahan-puti	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Isabela, Aurora, SAMAR. Primary dipterocarp forests, 90-850m.
794	Sapindaceae	Guioa	myriadenia Radlk.	\N	\N	Ulas	Angiosperm (Tree)	Vulnerable	Endemic	 LUZON: Mountain Province, Benguet, Aurora. Primary forest, forested slopes, along pine crests, 270-1700m.
795	Sapindaceae	Guioa	truncata Radlk.	\N	\N	Uyos	Angiosperm (Tree)	Vulnerable	Endemic	MINDANAO: Davao (Mt Apo). Dense moist forests and mossy forests, 1300-2300m. 
796	Sapindaceae	Litchi	chinensis Sonn.	ssp. philippinensis (Radlk.) Leenh.	\N	Alupag	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON, SIBUYAN, SAMAR, MINDANAO.
797	Sapindaceae	Nephelium	cuspidatum Blume	\N	var. robustum (Radlk.) Leenh.	Panungaian	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN (Mt Pulgar = Thumb Peak).
798	Sapindaceae	Nephelium	lappaceum L.	\N	var. lappaceum.	Rambutan; usau	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN, BASILAN.
799	Sapindaceae	Nephelium	lappaceum L.	\N	var. pallens (Hiern) Leenh.	Bulauan	Angiosperm (Tree)	Vulnerable	Indigenous	PALAWAN, SULU ARCHIPELAGO.
800	Sapindaceae	Nephelium	ramboutan-ake (Labill.) Leenh.	\N	\N	Kapulasan	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON, MINDORO, PALAWAN, LEYTE, SAMAR, MINDANAO (Davao), BASILAN, SULU ARCHIPELAGO.
801	Sapotaceae	Palaquium	luzoniense (Fern.-Villar) Vidal	\N	\N	Red nato, nato	Angiosperm (Tree)	Vulnerable	Endemic	 LUZON: Ilocos Sur, Zambales, Bataan, Aurora, Rizal, MINDORO: Mindoro Oriental (Bongabong River), MASBATE, SIBUYAN, PANAY: Iloilo (Mt Balutinao; Miag-ao), GUIMARAS (Sulangun Hill), MINDANAO: Zamboanga (Sta. Maria), Lanao, Agusan, Surigao. Primary forests at low and medium elevation. 
802	Sapotaceae	Palaquium	mindanaense Merr.	\N	\N	Pinulog	Angiosperm (Tree)	Vulnerable	Endemic	MINDANAO: Lanao, Cotabato. Lowland primary rainforests. 
803	Sapotaceae	Palaquium	philippense (Perr.) C Robinson	\N	\N	Malak-malak	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Isabela, Bataan, Tarlac, Bulacan, Rizal, Batangas, Quezon, Camarines Sur, Albay, Sorsogon, MINDORO: Mindoro Occidental (Mt Calavite), PANAY: Capiz, NEGROS, LEYTE (Ormoc, Lake Danao), MINDANAO: Davao (Mt Apo). Common in lowland and medium elevation primary forests.
804	Sapotaceae	Pleioluma	foxworthyi (Elmer) Swenson	\N	\N	Alálud	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN: Mt. Pulgar, MINDANAO: Bukidnon.
805	Sapotaceae	Pouteria	villamilii (Merr.) Swenson	\N	\N	Villamil Nato, white nato	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Cagayan, Bataan, Laguna, SIARGAO.
806	Selaginellaceae	Selaginella	atimonanensis BC Tan & Jermy	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON (Quezon, Atimonan, Quezon National Park).
807	Stemonuraceae	Gomphandra	fernandoi Schori & Utteridge	\N	\N	Fernando mabunót	Angiosperm (Tree)	Vulnerable	Endemic	BILIRAN, LEYTE, SAMAR, DINAGAT, MINDANAO.
808	Taxaceae	Taxus	sumatrana (Miq.) de Laub.	\N	\N	Amugauen	Gymnosperm (Tree)	Vulnerable	Indigenous	LUZON: Mountain Province, Benguet, Laguna-Quezon (Mt Banahaw), MINDANAO: Davao.
809	Tectariaceae	Aenigmopteris	mindanaensis Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	MINDANAO.
810	Theaceae	Camellia	lanceolata (Blume) Seem.	\N	\N	haikan	Angiosperm (Tree)	Vulnerable	Indigenous	LUZON: Cagayan to Sorsogon, POLILLO, MINDORO, PANAY, NEGROS, MINDANAO: Zamboanga, Lanao.
811	Theaceae	Schima	wallichii Choisy	ssp. pulgarensis (Elmer)	\N	\N	Angiosperm (Tree)	Vulnerable	Endemic	PALAWAN.
812	Thelypteridaceae	Chingia	pricei Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON: Benguet, MINDANAO: Misamis Occidental.
813	Thelypteridaceae	Coryphopteris	squamipes (Copel.) Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON: Benguet, Zambales, MINDANAO: Bukidnon, Davao del Sur, South Cotabato.
814	Thelypteridaceae	Cyclogramma	auriculata (J.Sm.) Ching.	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	LUZON.
815	Thelypteridaceae	Cyclosorus	paucipaleatus (Holttum) Mazumdar & Mukhop.	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON: Quezon
816	Thelypteridaceae	Nannothelypteris	aoristisora (Harr.) Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON, PANAY.
817	Thelypteridaceae	Nannothelypteris	camarinensis Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON.
818	Thelypteridaceae	Nannothelypteris	inaequilobata Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON.
819	Thelypteridaceae	Nannothelypteris	nervosa (Fee) Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	MINDANAO, SAMAR.
820	Thelypteridaceae	Nannothelypteris	philippina (C Presl) Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON.
821	Thelypteridaceae	Pronephrium	bulusanicum (Holttum) Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON.
822	Thelypteridaceae	Pronephrium	hosei (Baker) Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	BASILAN, MINDANAO: Zamboanga.
823	Thelypteridaceae	Pronephrium	solsonicum Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	LUZON.
824	Thelypteridaceae	Sphaerostephanos	hernaezii Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Endemic	SAMAR.
825	Thelypteridaceae	Sphaerostephanos	angustifolius (C.Presl) Holttum	\N	\N	\N	Pteridophyte	Vulnerable	Indigenous	No available information.
826	Thymelaeaceae	Aquilaria	apiculata Merr.	\N	\N	mangód	Angiosperm (Tree)	Vulnerable	Endemic	MINDANAO: Bukidnon.
827	Thymelaeaceae	Aquilaria	brachyantha (Merr.) Hallier f	\N	\N	binúkat	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Cagayan.
828	Thymelaeaceae	Aquilaria	citrinaecarpa (Elmer) Hallier f	\N	\N	agodódan	Angiosperm (Tree)	Vulnerable	Endemic	MINDANAO: Agusan del Norte (Mt Urdaneta).
829	Thymelaeaceae	Aquilaria	parvifolia (Quisumb.) Ding Hou	\N	\N	bútlong-liítan	Angiosperm (Tree)	Vulnerable	Endemic	LUZON: Camarines Sur. (possibly not from Luzon but Leyte or NE Mindanao)
830	Thymelaeaceae	Aquilaria	urdanetensis (Elmer) Hallier f	\N	\N	makólan	Angiosperm (Tree)	Vulnerable	Endemic	MINDANAO: Agusan del Norte (Mt Urdaneta).
831	Thymelaeaceae	Aquilaria	cumingiana (Decne.) Ridley	\N	\N	butlo	Angiosperm (Tree)	Vulnerable	Indigenous	Catanduanes: Mt Abucay
832	Thymelaeaceae	Aquilaria	filaria (Oken) Merr.	\N	\N	palisan	Angiosperm (Tree)	Vulnerable	Indigenous	DINAGAT, BUCAS GRANDE.
833	Urticaceae	Elatostema	palawanense C.B.Rob	\N	\N	\N	Angiosperm	Vulnerable	Endemic	PALAWAN (Mt Victoria).
834	Zingiberaceae	Alpinia	elegans (C.Presl) K.Schum	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Apayao, Ilocos Sur, Mountain Province, Isabela, Nueva Vizcaya, Pampanga, Bulacan, Nueva Ecija, Bataan, Rizal, Laguna, Quezon, Sorsogon, PANAY, POLILLO, MINDORO, LEYTE.
835	Zingiberaceae	Alpinia	foxworthyi Ridl	\N	\N	langkawás	Angiosperm	Vulnerable	Endemic	PALAWAN.
836	Zingiberaceae	Alpinia	paradoxa (Ridl.) Merr.	\N	\N	Parapat	Angiosperm	Vulnerable	Endemic	LUZON: Pangasinan, Apayao, Mountain Province, Benguet, Nueva Ecija, Rizal, Laguna (Mt Banahaw), Quezon (Lucban), PANAY, MINDANAO: Lanao. Mossy forests and damp forested ravines, 1000-1800m.
837	Zingiberaceae	Amomum	palawanense Elmer	\N	\N	\N	Angiosperm	Vulnerable	Endemic	Palawan: Palawan prov., Puerto Princesa, Mt Pulgar (Thumb Peak)
838	Zingiberaceae	Kaempferia	philippinensis Merr	\N	\N	\N	Angiosperm	Vulnerable	Endemic	LUZON: Laguna.
839	Zingiberaceae	Leptosolena	haenkei C Presl	\N	\N	Banai	Angiosperm	Vulnerable	Endemic	LUZON: Ilocos Norte, La Union, Benguet (Twin Peaks), Mountain Province (Supan; Dandanac, Besao; Alab and Balili, Bontoc; Mt Data), Cagayan (Bauan-Mt Tabuan), Nueva Vizcaya, Zambales (Villar, Mt Pinatubo), 300-1300m.
840	Acanthaceae	Hypoestes	merrillii C.B.Clarke ex Elmer	\N	\N	\N	Angiosperm	Other Threatened Species	Endemic	PALAWAN, SIBUTU.
841	Acanthaceae	Hypoestes	palawanensis C.B.Clarke	\N	\N	\N	Angiosperm	Other Threatened Species	Endemic	LUZON: Cagayan, PALAWAN.
978	Thelypteridaceae	Sphaerostephanos	spenceri (Christ) Holttum	\N	\N	\N	Pteridophyte	Other Threatened Species	Endemic	MINDANAO.
842	Acanthaceae	Lepidagathis	amaranthoides Elmer	\N	\N	tiagang	Angiosperm	Other Threatened Species	Endemic	BUSUANGA, PALAWAN, LEYTE (Ormoc, Mt Janagdan), MINDANAO: Davao (Magdug River).
843	Anacardiaceae	Koordersiodendron	pinnatum (Blanco) Merr.	\N	\N	Amugis	Angiosperm (Tree)	Other Threatened Species	Indigenous	N LUZON (Cagayan) to PALAWAN and MINDANAO.
844	Annonaceae	Artabotrys	vidaliana Elmer	\N	\N	\N	Angiosperm	Other Threatened Species	Endemic	PALAWAN.
845	Annonaceae	Mitrephora	lanotan (Blanco) Merr.	\N	\N	Lanutan	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Ilocos Norte, Ilocos Sur, Apayao, Pangasinan, Nueva Ecija, Zambales, Bataan, Bulacan, Rizal, Laguna, Quezon, POLILLO, MINDORO, MINDANAO, PALAWAN. Dry forests at low and medium elevations
846	Annonaceae	Orophea	cumingiana S.Vidal	\N	\N	Amunat	Angiosperm (Tree)	Other Threatened Species	Indigenous	LUZON: Ilocos Norte, Cagayan, Nueva Vizcaya, Nueva Ecija, Rizal, Bataan, Laguna, Quezon, Camarines, Albay, Sorsogon), MINDORO, LEYTE, SAMAR, MINDANAO.
847	Apocynaceae	Alyxia	linearis Markgr	\N	\N	\N	Angiosperm (Tree)	Other Threatened Species	Endemic	PALAWAN (Puerto Princesa, Bacungan, Balanjao Range, Rio Tuba).
848	Apocynaceae	Kibatalia	elmeri Woodson	\N	\N	Elmer pasnit	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Ilocos Sur, Cagayan, Laguna, Batangas, Sorsogon, MINDORO, PALAWAN (Taytay), CATANDUANES. In secondary and primary forests, on hillsides and top of ridges. 
849	Apocynaceae	Wrightia	hanleyi Elmer	\N	\N	Hanley lanéte	Angiosperm (Tree)	Other Threatened Species	Endemic	PALAWAN (Taytay: Mt Bloomfield, Irawan River Valley, Narra: Bato-bato km 107, Quezon: Lipuun, Brooke’s Point).
850	Araceae	Cryptocoryne	usteriana Engl.	\N	\N	\N	Angiosperm	Other Threatened Species	Endemic	Guimaras.
851	Araceae	Rhaphidophora	korthalsii Schott	\N	\N	\N	Angiosperm	Other Threatened Species	Endemic	LUZON: Benguet, Ifugao, Laguna, PALAWAN, NEGROS: Negros Oriental (Cuernos Mtns), MINDANAO: Agusan del Sur (photos), Davao (Mt Apo).
852	Arecaceae	Arenga	brevipes Becc.	\N	\N	batbat	Angiosperm (Tree)	Other Threatened Species	Indigenous	PALAWAN: Puerto Princesa, St Paul’s Bay National Park;\nAborlan, Talakaigan Watershed.
853	Arecaceae	Calamus	daemonoropoides Fernando	\N	\N	\N	Angiosperm	Other Threatened Species	Endemic	LEYTE, LUZON, MINDANAO, SAMAR.
854	Arecaceae	Calamus	merrillii Becc.	\N	\N	palásan	Angiosperm	Other Threatened Species	Endemic	LUZON: Rizal, Laguna, Quezon, MASBATE, MINDORO, PALAWAN, PANAY, MINDANAO: Lanao, Davao, Agusan, BASILAN, SAMAR.
855	Arecaceae	Calamus	mollis Blanco	\N	\N	ditaán	Angiosperm	Other Threatened Species	Endemic	BABUYAN ISLS to MINDANAO, in most islands and provinces.
856	Arecaceae	Calamus	ornatus Blume	\N	var. ornatus	limúran	Angiosperm	Other Threatened Species	Endemic	LUZON: Cagayan, Isabela, Bataan, Rizal, Laguna, Quezon, Sorsogon, POLILLO, MINDORO, NEGROS, PANAY, LEYTE, MINDANAO: Davao, Surigao, BASILAN.
857	Arecaceae	Calamus	erinaceus (Becc.) Becc.	\N	\N	\N	Angiosperm	Other Threatened Species	Indigenous	No available information.
858	Arecaceae	Calamus	longipes Griff.	\N	\N	labsikan	Angiosperm	Other Threatened Species	Indigenous	Palawan: San Antonio Bay.
859	Arecaceae	Phoenix	loureiroi Kunth	\N	\N	voyavoi	Angiosperm (Tree)	Other Threatened Species	Indigenous	Batanes.
860	Arecaceae	Plectocomia	elongata Mart. ex Blume	\N	var.\nphilippinensis Madulid	ungang	Angiosperm	Other Threatened Species	Endemic	PALAWAN, BILIRAN, LEYTE, MINDANAO: Agusan del Sur, Surigao del Sur, SAMAR.
861	Arecaceae	Saribus	rotundifolius (Lam.) Blume	\N	\N	anahau	Angiosperm (Tree)	Other Threatened Species	Indigenous	LUZON: La Union, Benguet, Pangasinan, Zambales, Pampanga, Laguna, Quezon, Camarines, Albay, POLILLO, MINDORO, PALAWAN, NEGROS, MINDANAO: Davao.
862	Athyriaceae	Diplazium	sibuyanense (Copel.) Alderw.	\N	\N	\N	Pteridophyte	Other Threatened Species	Endemic	SIBUYAN.
863	Athyriaceae	Diplazium	calliphyllum (Copel.) M.G.Price	\N	\N	\N	Pteridophyte	Other Threatened Species	Indigenous	MINDANAO.
864	Athyriaceae	Diplazium	maximum (D.Don) C.Chr.	\N	\N	\N	Pteridophyte	Other Threatened Species	Indigenous	MINDANAO.
865	Athyriaceae	Diplazium	vestitum C.Presl	\N	\N	\N	Pteridophyte	Other Threatened Species	Indigenous	No available information.
866	Begoniaceae	Begonia	blancii M.Hughes & C.-I.Peng	\N	\N	\N	Angiosperm	Other Threatened Species	Endemic	Palawan: En route to Bulalakaw Falls, about 25 km east of El Nido, 300-400m.
867	Begoniaceae	Begonia	lagunensis Elmer	\N	\N	\N	Angiosperm	Other Threatened Species	Endemic	LUZON: Laguna, Quezon, MINDORO.
868	Burseraceae	Canarium	luzonicum (Blume) Miq.	\N	\N	píling-liítan	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON, ALABAT, MINDORO, MASBATE, TICAO, BOHOL, MINDANAO.
869	Burseraceae	Canarium	ovatum Engl.	\N	\N	Pili	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Quezon, Laguna, Camarines, Albay, Sorsogon, POLILLO, SEMIRARA (Cabuya), LEYTE, SAMAR, MINDANAO: Surigao.
870	Burseraceae	Dacryodes	rostrata (Blume) H.J.Lam	\N	\N	lunai	Angiosperm (Tree)	Other Threatened Species	Indigenous	LUZON: Camarines, PALAWAN, LEYTE, SAMAR, MINDANAO.
871	Casuarinaceae	Gymnostoma	rumphianum (Jungh. ex Vriese) L.A.S.Johnson	\N	\N	mountain agoho	Angiosperm (Tree)	Other Threatened Species	Indigenous	N LUZON to PALAWAN and MINDANAO.
872	Connaraceae	Connarus	culionensis Merr.	\N	\N	\N	Angiosperm	Other Threatened Species	Indigenous	No available information.
873	Cornaceae	Alangium	longiflorum Merr.	\N	\N	malatapai	Angiosperm (Tree)	Other Threatened Species	Indigenous	LUZON: Ilocos Norte (Bangui), Apayao (Mt Duraragan), Cagayan (Malueg; Casambalangan), Quezon (Mauban; Sampolan), Laguna (Mt Makiling; San Antonio, Mabitac), Batangas, Camarines Sur (Minalabat; Mt Isarog; Caramoan), Sorsogon (Mt Bulusan), MINDORO: Mindoro Oriental (Pinamalayan), PALAWAN (Thumb Peak), NEGROS: Negros Oriental (Cuernos Mtns), LEYTE, SAMAR (Catubig River), TAWI-TAWI, MINDANAO: Lanao del Sur (Camp Keithley), South Cotabato (Nutol; Buayan), Agusan del Norte (Jabonga: Kitsarao), Surigao del Norte (Placer), Davao Oriental (Mati).
874	Davalliaceae	Davallia	denticulata (Burm.f.) Mett. ex Kuhn	\N	\N	\N	Pteridophyte	Other Threatened Species	Indigenous	PALAWAN.
875	Davalliaceae	Davallia	embolostegia Copel.	\N	\N	\N	Pteridophyte	Other Threatened Species	Indigenous	No available information.
876	Davalliaceae	Davallia	lorrainii Hance	\N	\N	\N	Pteridophyte	Other Threatened Species	Indigenous	No available information.
877	Davalliaceae	Davallia	solida (G.Forst.) Sw.	\N	var. solida	\N	Pteridophyte	Other Threatened Species	Indigenous	No available information.
878	Dilleniaceae	Dillenia	marsupialis Hoogland	\N	\N	paláli	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Ilocos Norte (Mt Palimlim), Cagayan, Nueva Vizcaya (Caraballo Mtns), Rizal (Montalban), Quezon (Mt Banahaw; Lucban), Camarines Norte, Camarines Sur, CATANDUANES, PANAY: Aklan (Libacao).
879	Dilleniaceae	Dillenia	reifferscheidia Fern.-Villar	\N	\N	Katmon-kalabau	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Cagayan, Isabela (Palanan), Rizal, Laguna (Mt Makiling; San Antonio), Quezon (Mt Tulaog), Albay, Sorsogon (Mt Bulusan), CATANDUANES (Mt Pagmasuso), NEGROS: Negros Occidental (Mt Kanlaon), PANAY: Iloilo (Leon), Capiz (Agsabay; Pilar; Mt Upao), MINDANAO: Davao Oriental (Mt Mayo), Surigao del Norte (Tubud; Placer).
880	Dryopteridaceae	Stenolepia	tristis (Blume) Alderw.	\N	\N	\N	Pteridophyte	Other Threatened Species	Indigenous	MINDANAO: Bukidnon, North Cotabato.
881	Ebenaceae	Diospyros	calcicola Merr.	\N	\N	ánang-apógan	Angiosperm (Tree)	Other Threatened Species	Endemic	CORON.
882	Ebenaceae	Diospyros	curranii Merr.	\N	\N	malagaitmon	Angiosperm (Tree)	Other Threatened Species	Indigenous	No available information.
883	Ebenaceae	Diospyros	mindanaensis Merr.	\N	\N	ata-ata	Angiosperm (Tree)	Other Threatened Species	Indigenous	LUZON: Quezon (Guinayangan), Laguna, Camarines, SIBUYAN, PANAY, NEGROS: Gimagaan River; Negros Occidental (Cadiz), BILIRAN, LEYTE, SAMAR, BASILAN, MINDANAO: Zamboanga del Sur, Lanao, Agusan.
884	Ebenaceae	Diospyros	transita (Bakh.) Kosterm	\N	\N	\N	Angiosperm (Tree)	Other Threatened Species	Endemic	Palawan: Mt Pulgar.
885	Ebenaceae	Diospyros	wrayi King & Gamble	\N	\N	tandikan	Angiosperm (Tree)	Other Threatened Species	Indigenous	PALAWAN (Mt Pulgar, Bacungan, Aborlan).
886	Elaeocarpaceae	Elaeocarpus	dinagatensis Merr.	\N	\N	Dinagat konakan	Angiosperm (Tree)	Other Threatened Species	Endemic	 DINAGAT, BUCAS GRANDE. Low elevation. 
887	Elaeocarpaceae	Elaeocarpus	gigantifolius Elmer	\N	\N	Nabol	Angiosperm (Tree)	Other Threatened Species	Endemic	LEYTE; MINDANAO: Davao (Mt Apo).
888	Escalloniaceae	Polyosma	pulgarensis Elmer	\N	\N	\N	Angiosperm	Other Threatened Species	Endemic	PALAWAN: Puerto Princesa (Thumb Peak).
889	Euphorbiaceae	Dimorphocalyx	denticulatus Merr.	\N	\N	kulis-daga	Angiosperm (Tree)	Other Threatened Species	Indigenous	LUZON, MINDANAO, PALAWAN.
890	Euphorbiaceae	Macaranga	congestiflora Merr.	\N	\N	Amublit	Angiosperm (Tree)	Other Threatened Species	Endemic	PALAWAN. Old clearings at low elevation
891	Fabaceae	Adenanthera	intermedia Merr.	\N	\N	Tanglin	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON, PALAWAN, MINDANAO.
892	Fabaceae	Entada	parvifolia Merr.	\N	\N	dalidigan	Angiosperm	Other Threatened Species	Endemic	LUZON: La Union, Zambales, Bataan, GOLO, BUSUANGA, CUYO.
893	Fabaceae	Entada	phaseoloides (L.) Merr.	\N	\N	gugo	Angiosperm	Other Threatened Species	Indigenous	No available information.
894	Fabaceae	Entada	rheedii Sprengel	\N	\N	\N	Angiosperm	Other Threatened Species	Indigenous	LUZON, MINDANAO.
895	Fabaceae	Luzonia	purpurea Elmer	\N	\N	Baloktot	Angiosperm	Other Threatened Species	Endemic	LUZON: Benguet, Bataan, Quezon, LEYTE.
896	Fabaceae	Millettia	merrillii Perkins	\N	\N	balók	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Cagayan to Bataan, Bulacan, Rizal, Laguna (Mt Makiling), MINDORO, PALAWAN, NEGROS.
897	Fabaceae	Parkia	speciosa Hassk.	\N	\N	butad	Angiosperm (Tree)	Other Threatened Species	Indigenous	PALAWAN: Taytay; Lake Manguao; Puerto Princesa (Mt Pulgar = Thumb Peak; Mt Beaufort; Mt Iraan; Irawan, Impapan), Aborlan (Sagpangan).
898	Fagaceae	Lithocarpus	luzoniensis (Merr.) Rehd.	\N	\N	Kilog	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Mountain Province (Mt Data), Benguet (Mt Pulag, Pauai, Mt Nangaoto, Mt Sto Tomas), Zambales (Mt Tapulao = High Peak). Mossy forests, 1500-2700m.
899	Fagaceae	Lithocarpus	ovalis (Blanco) Rehd.	\N	\N	Mangasiriki	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Cagayan, Zambales, Pampanga (Mt Abu), Bulacan (Angat), Rizal (Bosoboso), Batangas (Mt Malarayat), Camarines. Low elevation forests. 
900	Fagaceae	Quercus	merrillii Seem.	\N	\N	pungo-pungo	Angiosperm (Tree)	Other Threatened Species	Indigenous	PALAWAN: Mt Pulgar (Thumb Peak).
901	Fagaceae	Quercus	subsericea A.Camus	\N	\N	\N	Angiosperm (Tree)	Other Threatened Species	Indigenous	PALAWAN.
902	Gesneriaceae	Monophyllaea	longipes Kraenzl.	\N	\N	\N	Angiosperm	Other Threatened Species	Endemic	LUZON: Apayao, Cagayan, Isabela (Palanan). On cliff in damp shaded ravines at low elevation, on damp limestone ledge along a stream, 40m in Palanan
903	Gesneriaceae	Monophyllaea	merrilliana Kraenzl.	\N	\N	Sabongaiahon	Angiosperm	Other Threatened Species	Endemic	SAMAR, BOHOL (Pilar, Lundag Cave), MINDANAO: Zamboanga, Agusan, Surigao. On damp cliff along small streams in forested ravines at low and medium elevation, ascending to 800m.
904	Hernandiaceae	Hernandia	ovigera L.	\N	\N	koron-koron	Angiosperm (Tree)	Other Threatened Species	Indigenous	No available information.
905	Lamiaceae	Plectranthus	apoensis (Elmer) H.Keng	\N	\N	kalalapo-bulan	Angiosperm	Other Threatened Species	Indigenous	MINDANAO: Davao (Mt Apo).
906	Lamiaceae	Plectranthus	merrillii H.Keng	\N	\N	bungbungtid	Angiosperm	Other Threatened Species	Indigenous	LUZON: Mountain Province. Benguet Prov, Mt Pulag.
907	Lauraceae	Cinnamomum	mercadoi Vidal	\N	\N	Kalingag	Angiosperm (Tree)	Other Threatened Species	Endemic	BABUYAN ISLS and N LUZON to MINDANAO. Common in lowland and medium elevation forests, with some forms ascending to 2000m.
908	Lauraceae	Eusideroxylon	zwageri Teijsm. & Binn.	\N	\N	tambulian	Angiosperm (Tree)	Other Threatened Species	Indigenous	TAWI-TAWI.
909	Lauraceae	Litsea	varians (Blume) Boerl.	\N	\N	\N	Angiosperm (Tree)	Other Threatened Species	Endemic	PALAWAN, LEYTE.
910	Lauraceae	Neolitsea	incana Elmer	\N	\N	patúgau	Angiosperm (Tree)	Other Threatened Species	Endemic	PALAWAN (Mt Pulgar = Thumb Peak).
911	Lauraceae	Persea	philippinensis (Merr.) Elmer	\N	\N	kulilísiau	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Mountain Province, Cagayan, Bataan, Laguna, Batangas, Quezon, MINDORO.
912	Marattiaceae	Angiopteris	palmiformis(Cav.) C. Chr.	\N	\N	pakong kalabaw	Pteridophyte	Other Threatened Species	Indigenous	No available information.
913	Meliaceae	Aglaia	cumingiana Turcz.	\N	\N	alauihau	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Ilocos Norte, Benguet, Cagayan, Isabela (Palanan), Nueva Vizcaya, Pangasinan, Nueva Ecija, Bulacan, Rizal, BANCALAN, PANAY, NEGROS, MINDANAO: Davao (Mt Apo, Todaya).
914	Meliaceae	Aglaia	edulis (Roxb.) Wall.	\N	\N	malasaging	Angiosperm (Tree)	Other Threatened Species	Indigenous	LUZON: Cagayan to Sorsogon, MINDORO, MASBATE, BURIAS, NEGROS, LEYTE, SAMAR, MINDANAO: Davao del Sur (Mt Apo), BASILAN.
979	Thelypteridaceae	Sphaerostephanos	stenodontus (Copel.) Holttum	\N	\N	\N	Pteridophyte	Other Threatened Species	Endemic	PANAY.
980	Thelypteridaceae	Sphaerostephanos	tephrophyllus (Copel.) Holttum	\N	\N	\N	Pteridophyte	Other Threatened Species	Endemic	MINDANAO.
915	Meliaceae	Aglaia	rimosa (Blanco) Merr.	\N	\N	balubar	Angiosperm (Tree)	Other Threatened Species	Indigenous	Y’AMI, BATAN, BABUYAN ISLS, LUZON: Ilocos Norte, Benguet, Pangasinan, Cagayan, Isabela, Nueva Vizcaya, Aurora, Nueva Ecija, Bataan, Rizal, Laguna, Quezon, Cavite, Batangas, Camarines, Albay, Sorsogon, ALABAT, MINDORO, PALAWAN, ROMBLON, SIBUYAN, TICAO, PANAY, GUIMARAS, NEGROS, SIBUTU, MINDANAO (Davao, Agusan).
916	Meliaceae	Aglaia	smithii Koord.	\N	\N	batukanag	Angiosperm (Tree)	Other Threatened Species	Indigenous	LUZON: Ilocos Sur, Pangasinan, Cagayan, Pampanga, Aurora, Rizal, PALAWAN, NEGROS, LEYTE, BASILAN, MINDANAO.
917	Meliaceae	Aglaia	aherniana Perkins	\N	\N	Alamag	Angiosperm (Tree)	Other Threatened Species	Endemic	 LUZON: Aurora (Mt Dingalan), Quezon, Camarines, Albay, Sorsogon (Mt Bulusan), POLILLO, SIBUYAN, DINAGAT. Primary forests at low and medium elevation.
918	Meliaceae	Aglaia	costata Elmer ex Merr.	\N	\N	Manabiog	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Camarines, SAMAR, MINDANAO: Lanao (Camp Keithley), Agusan del Norte (Mt Urdaneta). Forests at low and medium elevation
919	Meliaceae	Aphanamixis	polystachya (Wall.) R.Parker	\N	\N	kangko	Angiosperm (Tree)	Other Threatened Species	Indigenous	LUZON: Ilocos Norte, Benguet (Sablan), Cagayan, Isabela, Pampanga (Mt Pinatubo), Bataan (Lamao), Laguna (Mt Makiling), Sorsogon (Mt Pocdal), POLILLO, MINDORO, PALAWAN (Irawan), LEYTE, SAMAR, BASILAN, MINDANAO: Davao del Sur (Mt Apo, Todaya), Agusan del Norte (Mt Urdaneta), Surigao.
920	Meliaceae	Dysoxylum	oppositifolium F.Muell.	\N	\N	paluahan, kayatau	Angiosperm (Tree)	Other Threatened Species	Indigenous	LUZON: Ilocos Norte, Ilocos Sur, Cagayan, Isabela, Nueva Vizcaya, Pangasinan, Zambales, Rizal, Laguna, Batangas, POLILLO, MINDORO, PALAWAN, PANAY, NEGROS, LEYTE, MINDANAO.
921	Menispermaceae	Pycnarrhena	manillensis S.Vidal	\N	\N	ambal	Angiosperm	Other Threatened Species	Endemic	LUZON, ALABAT, PANAY, NEGROS, LEYTE, CAMOTES, SAMAR, BASILAN, MINDANAO
922	Moraceae	Artocarpus	rubrovenius Warb.	\N	\N	Kalulot	Angiosperm (Tree)	Other Threatened Species	Endemic	BATAN (Basco), LUZON: Isabela (Palanan), Aurora (Casiguran, Baler), Bataan (Lamao, Mt Mariveles), Pampanga (Mt Pinatubo), Rizal (San Mateo, Bosoboso), Laguna (Mt Makiling), Batangas, Quezon (Laguimanoc = Padre Burgos, Lucban, Sampaloc), Camarines, Albay (Guinobatan, Banao), Sorsogon (Mt Bulusan), ?MINDORO. Lowland forests to 360m. 
923	Myristicaceae	Knema	alvarezii Merr.	\N	\N	Duhao	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Nueva Ecija (Mt Macasandal). Lower and montane forests, possibly on ultramafics, up to 850m.
924	Myristicaceae	Knema	stenocarpa Warb.	\N	\N	Libago	Angiosperm (Tree)	Other Threatened Species	Endemic	BASILAN, MINDANAO: Zamboanga, Lanao, Davao. Primary and degraded forests, 300-500m
925	Myristicaceae	Myristica	basilanica de Wilde	\N	\N	Basilan duguan	Angiosperm (Tree)	Other Threatened Species	Endemic	BASILAN
926	Myristicaceae	Myristica	frugifera de Wilde	\N	\N	\N	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON, MINDORO, LEYTE. Understorey tree of primary and disturbed lowland forest, 0-500m
927	Myristicaceae	Myristica	longipetiolata de Wilde	\N	\N	\N	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Camarines, Sorsogon, BILIRAN (Mt Suiro). Sloping forests, c. 800m.
928	Myristicaceae	Myristica	philippensis Lam.	\N	\N	Duguan	Angiosperm (Tree)	Other Threatened Species	Endemic	Throughout the Philippines (except Palawan). Primary lowland forests up to c. 400m. Batanes.
929	Myristicaceae	Myristica	pilosigemma de Wilde	\N	\N	\N	Angiosperm (Tree)	Other Threatened Species	Endemic	SAMAR: Western Samar (Mt Sohoton), MINDANAO. c. 600m
930	Myrtaceae	Kania	microphylla (Quisumb. & Merr.) Peter G Wilson	\N	\N	Tigang-liitan	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Quirino (Mt Alzapan). In mossy forest, 1700m.
931	Myrtaceae	Kania	urdanetensis (Elmer) Peter G Wilson	\N	\N	Sambulanan	Angiosperm (Tree)	Other Threatened Species	Endemic	MINDANAO: Agusan del Norte
932	Myrtaceae	Metrosideros	halconensis (Merr.) Dawson	\N	\N	Magadhan	Angiosperm	Other Threatened Species	Endemic	MINDORO: Mindoro Occidental (Mt Halcon), MINDANAO: Agusan del Norte (Mt Urdaneta). Mossy forests on exposed ridges, 1200-1500m
933	Myrtaceae	Syzygium	cagayanense (Merr.) Merr.	\N	\N	Amtuk	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Cagayan. Forests, c. 300m. 
934	Myrtaceae	Syzygium	capoasense (Merr.) Merr.	\N	\N	Capoas lamuto	Angiosperm (Tree)	Other Threatened Species	Endemic	PALAWAN (Mt Capoas). Exposed ridge-summit mossy forest, c. 1000m.
935	Myrtaceae	Syzygium	ciliato-setosum (Merr.) Merr.	\N	\N	Lakangan	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Cagayan, Isabela, Quezon. Usually along streams in lowland primary forests. 
936	Myrtaceae	Syzygium	densinervium (Merr.) Merr.	\N	\N	Salakadan	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Nueva Ecija, Bataan, Laguna, Batangas, Quezon, Camarines, Sorsogon, MINDORO, PANAY, SAMAR. Primary forests, 100-600m. 
937	Myrtaceae	Syzygium	longissimum (Merr.) Merr.	\N	\N	tuál	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Isabela, Benguet, Zambales.
938	Myrtaceae	Syzygium	subrotundifolium (C Robinson) Merr.	\N	\N	kalógkog-dágat	Angiosperm (Tree)	Other Threatened Species	Endemic	BATAN ISLS, LUZON: Ilocos Norte, Cagayan, Isabela, Aurora, Quezon, Albay, Sorsogon, POLILLO. Thickets and secondary forests, especially along the seashore.
939	Myrtaceae	Syzygium	confertum (Korth.) Merr. & L.M.Perry	\N	\N	tamo	Angiosperm (Tree)	Other Threatened Species	Indigenous	PALAWAN.
940	Myrtaceae	Syzygium	panduriforme (Elmer) Merr.	\N	\N	lauig-lauigan	Angiosperm (Tree)	Other Threatened Species	Indigenous	MINDANAO: Bukidnon, Davao del Sur (Mt Apo).
941	Myrtaceae	Tristaniopsis	oblongifolia (Merr.) Peter G. Wilson & Waterhouse	\N	\N	tígang-habá	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Isabela (Divilacan), Quezon (Mt Binuang), PALAWAN (Brookes Point, Infanta Mine).
942	Osmundaceae	Osmunda	banksiifolia (C.Presl) Kuhn	\N	\N	\N	Pteridophyte	Other Threatened Species	Indigenous	LUZON, MINDANAO, MINDORO, PANAY.
943	Pandanaceae	Benstonea	affinis (Kurz) Callm. & Buerki	\N	\N	pandan	Angiosperm (Tree)	Other Threatened Species	Indigenous	PALAWAN.
944	Pandanaceae	Pandanus	basilocularis Martelli	\N	\N	Olango	Angiosperm (Tree)	Other Threatened Species	Endemic	PALAWAN. Low elevation forests and thickets, often behind mangroves. 
945	Pentaphragmataceae	Pentaphragma	grandiflorum Kurz	\N	\N	\N	Angiosperm	Other Threatened Species	Indigenous	LUZON: Quirino, Laguna, Quezon, Camarines, Albay, Sorsogon, POLILLO, PANAY, LEYTE, SAMAR, MINDANAO, JOLO.
946	Phyllanthaceae	Flueggea	flexuosa Müll.Arg.	\N	\N	anislag	Angiosperm (Tree)	Other Threatened Species	Indigenous	CATANDUANES, LUZON: Quezon, Camarines, Sorsogon, NEGROS, CEBU, BOHOL, LEYTE, SAMAR, CAMIGUIN, MINDANAO: Misamis, Bukidnon, Davao, Agusan, Surigao.
947	Piperaceae	Piper	caninum Blume	\N	\N	\N	Angiosperm	Other Threatened Species	Indigenous	LUZON: Pangasinan (Mt San Isidro Labrador), Abra (Mt Posuey), Benguet (Baguio; Sablan), Cagayan (Peñablanca), Isabela (San Mariano), Aurora (Casiguran), Nueva Ecija (Mt Umingan = Mt Mingan), Zambales (Subic), Pampanga (Mt Pinatubo), Bataan (Dinalupihan; Limay; Mt Mariveles), Bulacan (Angat), Rizal (Binangonan; Bosoboso), Laguna (near Famy; Siniloan-Infanta Road; San Antonio; Paete), Quezon (Mt Tulaog; Dolores; Lucban; Lucban-Mauban Road; Tagkawayan), Camarines Norte (Niog, Sagnay; Paracale), Camarines Sur (Maagnas; Mt Isarog), Sorsogon (Mt Bulusan; Mt Labao), POLILLO (Mt Malulud; Barrio Saloang), CATANDUANES (Mt Mariguidon; Sto Domingo River), MINDORO: Mindoro Occidental (Mt Calavite; Paluan), Mindoro Oriental (Balete; Baco River; Mt Halcon; Naujan; Pinamalayan; Bongabong River; Camantigue), BUSUANGA, PALAWAN (Malampaya; Lake Manguao), SIBUYAN (Mt Giting-giting, Magallanes), PANAY: Antique (Culasi), Capiz (Jamindan; Galecia; Mt Kinablangan), Aklan (Libacao), NEGROS: Negros Oriental (Cuernos Mtns), BOHOL (Kalingohan; Bilar), LEYTE: Leyte (Dagami; Tacloban, Tigbao; Jaro, Buenavista), SAMAR (Cauayan Valley; Mt Canislagan; Camaniwan, Catubig River), CAMIGUIN (Mambajao; Mt Hibok-hibok; Mt Mahilog), JOLO (Bud-wak), BASILAN, MINDANAO: Zamboanga (San Ramon), Zamboanga del Sur (Malangas), Lanao del Sur (Camp Keithley), Bukidnon (Tangkulan), Davao, Davao del Sur (Mt Apo; Mt Dagatpan; Malalag), Agusan del Norte (Mt Hilong-hilong), Agusan del Sur (Talicogon), Surigao del Norte (Surigao; Placer), SIARGAO (Dapa), BUCAS GRANDE.
948	Piperaceae	Piper	retrofractum Vahl	\N	\N	\N	Angiosperm	Other Threatened Species	Indigenous	BABUYAN ISLS GROUP (DALUPIRI; CAMIGUIN), LUZON: Ilocos Norte (Burgos), La Union (San Fernando), Pangasinan (Rosales; Umingan), Kalinga (Tabuk), Abra (Caburao), Cagayan (Buguey), Nueva Vizcaya (Dupax), Nueva Ecija (Cabanatuan), Bataan (Mt Mariveles; Duale), Bulacan (Angat), Rizal (Mt Lumutan; Montalban; Masambong; Parañaque; Baras; Pililla; Jalajala; Malapad na Bato), Cavite, Laguna (Los Baños; Galas; Pagsanjan), MINDORO: Mindoro Oriental (Puerto Galera; Baco; Pinamalayan), PALAWAN (Babuyan; Ulugan Bay; Taytay; Puerto Princesa; Iwahig; Alfonso XIII = Quezon); PANAY: Antique (Lipata), Capiz (Mt Timbaban), Iloilo, GUIMARAS.
949	Pittosporaceae	Pittosporum	ramosii Merr.	\N	\N	albón	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Abra, Mountain Province.
950	Pittosporaceae	Pittosporum	resiniferum Hemsl.	\N	\N	abkel	Angiosperm (Tree)	Other Threatened Species	Indigenous	LUZON (widespread), MINDORO, CATANDUANES, PANAY, LEYTE, MINDANAO.
951	Poaceae	Dinochloa	acutiflora (Munro) S.Dransf.	\N	\N	bikal	Angiosperm	Other Threatened Species	Indigenous	BABUYAN ISLS, LUZON: Ilocos Norte, Ilocos Sur, Apayao, Benguet, Cagayan, Isabela, Nueva Vizcaya, Pangasinan, Zambales, Bulacan, Nueva Ecija, Pampanga, Rizal, Bataan, Laguna, Quezon, Camarines, MINDORO, ?PALAWAN, LEYTE.
952	Podocarpaceae	Dacrycarpus	imbricatus (Blume) de Laub.	\N	\N	igem	Gymnosperm (Tree)	Other Threatened Species	Indigenous	LUZON: Abra, Mountain Province, Benguet, Zambales, Quezon (Mt Banahaw), MINDORO: Mindoro Oriental (Mt Halcon), PANAY, NEGROS, MINDANAO.
953	Podocarpaceae	Dacrydium	pectinatum de Laub.	\N	\N	malasuklai	Gymnosperm (Tree)	Other Threatened Species	Indigenous	LUZON: Sierra Madre, MINDANAO: Zamboanga.
954	Podocarpaceae	Nageia	wallichiana (C.Presl) Kuntze	\N	\N	malaalmaciga	Gymnosperm (Tree)	Other Threatened Species	Indigenous	LUZON, MINDORO, SIBUYAN, PANAY, SAMAR.
955	Polypodiaceae	Arthromeris	mairei (Brause) Ching	\N	\N	\N	Pteridophyte	Other Threatened Species	Indigenous	LUZON.
956	Primulaceae	Discocalyx	palawanensis Elmer ex Merr.	\N	\N	ginárai	Angiosperm (Tree)	Other Threatened Species	Endemic	MINDORO, PALAWAN: Mt. Pulgar, BANCALAN.
957	Putranjivaceae	Drypetes	falcata (Merr.) Pax & K.Hoffm.	\N	\N	gakákan	Angiosperm (Tree)	Other Threatened Species	Endemic	BABUYAN ISLS (CAMIGUIN).
958	Putranjivaceae	Drypetes	rhakodiskos (Hassk.) Airy Shaw	\N	\N	tombong-uak	Angiosperm (Tree)	Other Threatened Species	Indigenous	PALAWAN.
959	Rhamnaceae	Ziziphus	hutchinsonii Merr.	\N	\N	Lumuluas	Angiosperm (Tree)	Other Threatened Species	Endemic	MINDANAO: Zamboanga, Davao. Low elevation forests.
960	Rhamnaceae	Ziziphus	talanai (Blanco) Merr.	\N	\N	Balakat	Angiosperm (Tree)	Other Threatened Species	Endemic	N LUZON to PALAWAN and MINDANAO. Common in lowland forests.
961	Rhizophoraceae	Carallia	brachiata (Lour.) Merr.	\N	\N	bakauan-gubat	Angiosperm (Tree)	Other Threatened Species	Indigenous	N LUZON to PALAWAN and MINDANAO.
962	Rosaceae	Rosa	luciae Franch. & Rochebr. ex Crépin	\N	\N	kuyaob	Angiosperm	Other Threatened Species	Indigenous	LUZON.
963	Rosaceae	Rosa	transmorrisonensis Hayata	\N	\N	pauikan	Angiosperm	Other Threatened Species	Indigenous	LUZON: Mountain Province, Benguet.
964	Rosaceae	Rubus	heterosepalus Merr.	\N	\N	Tukong	Angiosperm	Other Threatened Species	Endemic	LUZON: Mountain Province-Ifugao border (Mt Polis), Ifugao (Banawe). Mossy forest and associated thickets, 1800-1900m
965	Rubiaceae	Hydnophytum	leytense Merr.	\N	\N	pugaru	Angiosperm	Other Threatened Species	Endemic	DINAGAT, LEYTE, LUZON: Bataan, Laguna, Quezon, Sorsogon, POLILLO, MINDANAO: Agusan del Norte, Davao del Sur (Mt Apo), MINDORO.
966	Rubiaceae	Hydnophytum	philippinense Becc.	\N	\N	\N	Angiosperm	Other Threatened Species	Endemic	LUZON: Camarines, MINDANAO: Agusan del Norte, Davao, Cotabato, Surigao del Norte, Zamboanga, MINDORO.
967	Rubiaceae	Mussaenda	palawanensis Merr.	\N	\N	malabúyon	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Quezon, MINDANAO: Maguindanao, PALAWAN.
968	Rutaceae	Clausena	brevistyla Oliv.	\N	\N	kalomata	Angiosperm (Tree)	Other Threatened Species	Indigenous	No available information.
969	Salicaceae	Hydnocarpus	alcalae C DC	\N	\N	Dudua	Angiosperm (Tree)	Other Threatened Species	Endemic	LUZON: Albay.
970	Salicaceae	Xylosma	palawanensis DM Mendoza	\N	\N	Mansalay	Angiosperm (Tree)	Other Threatened Species	Endemic	PALAWAN: Quezon, Lipuun Point.
971	Sapindaceae	Guioa	bicolor Merr.	\N	\N	Kaninging	Angiosperm (Tree)	Other Threatened Species	Endemic	SABTANG, LUZON, MINDANAO. On ridges, woods, cut forest. Soil: iron deposit present, 130-850m
972	Sapotaceae	Palaquium	bataanense Merr.	\N	\N	Bataan tagátoi	Angiosperm (Tree)	Other Threatened Species	Endemic	BATANES. LUZON: Bataan, SIBUYAN, PALAWAN, CAMIGUIN, MINDANAO: Lanao (Butig).
973	Tectariaceae	Tectaria	adenophora Copel.	\N	\N	\N	Pteridophyte	Other Threatened Species	Endemic	LUZON, SIBUYAN.
974	Tectariaceae	Tectaria	tabonensis M.G.Price	\N	\N	\N	Pteridophyte	Other Threatened Species	Endemic	MINDANAO, PALAWAN.
975	Thelypteridaceae	Sphaerostephanos	cartilagidens P Zamora & Co	\N	\N	\N	Pteridophyte	Other Threatened Species	Endemic	PALAWAN.
976	Thelypteridaceae	Sphaerostephanos	dichrotrichoides (Alderw.) Holttum	\N	\N	\N	Pteridophyte	Other Threatened Species	Endemic	MINDANAO, PANAY.
977	Thelypteridaceae	Sphaerostephanos	irayensis (Copel.) Holttum	\N	\N	\N	Pteridophyte	Other Threatened Species	Endemic	BATANES.
981	Thelypteridaceae	Sphaerostephanos	williamsii (Copel.) Holttum	\N	\N	\N	Pteridophyte	Other Threatened Species	Endemic	MINDANAO.
982	Thymelaeaceae	Wikstroemia	retusa A.Gray	\N	\N	palupo	Angiosperm (Tree)	Other Threatened Species	Indigenous	BATAN.
983	Urticaceae	Astrothalamus	reticulatus (Wedd.) C.B.Rob.	\N	\N	lapnai	Angiosperm	Other Threatened Species	Indigenous	MINDANAO: Zamboanga (San Ramon; Sax River).
984	Zingiberaceae	Vanoverberghia	sepulchrei Merr.	\N	\N	Agbab	Angiosperm	Other Threatened Species	Endemic	LUZON: Benguet, Ifugao, Mountain Province, Sorsogon (Mt Bulusan). Steep slopes along stream gullies, medium elevation to 1500m.
\.


--
-- Name: threatened_flora_dao_2017_11_id_seq; Type: SEQUENCE SET; Schema: staging; Owner: postgres
--

SELECT pg_catalog.setval('staging.threatened_flora_dao_2017_11_id_seq', 1, false);


--
-- Name: threatened_flora_dao_2017_11 threatened_flora_dao_2017_11_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.threatened_flora_dao_2017_11
    ADD CONSTRAINT threatened_flora_dao_2017_11_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

